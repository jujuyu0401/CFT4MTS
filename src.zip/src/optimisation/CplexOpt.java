package optimisation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import output.ExcelWriter;
import services.AggregateService;
import services.Service;
import ilog.concert.IloException;
import ilog.concert.IloIntVar;
import ilog.concert.IloLinearNumExpr;
import ilog.concert.IloNumExpr;
import ilog.cplex.IloCplex;
import ilog.cplex.IloCplex.UnknownObjectException;
import composition.CompositionScheme;
import composition.ServiceComposition;
import config.Config;
import log.LogInfo;

public class CplexOpt {
	ServiceComposition composition;
	boolean isHaveSolution = false;
	//MyFileWriter writer = new MyFileWriter("output.txt");
	double originalRt;
	double originalTp;
	double originalRe;
	double criRt;
	double wcriRt;
	double randomRt;
	double ftCloudRt;
	
	public double getCriSso() {
		return criSso;
	}
	public void setCriSso(double criSso) {
		this.criSso = criSso;
	}
	public double getWcriSso() {
		return wcriSso;
	}
	public void setWcriSso(double wcriSso) {
		this.wcriSso = wcriSso;
	}
	public double getRandomSso() {
		return randomSso;
	}
	public void setRandomSso(double randomSso) {
		this.randomSso = randomSso;
	}
	public double getFtcSso() {
		return ftcSso;
	}
	public void setFtcSso(double ftcSso) {
		this.ftcSso = ftcSso;
	}
	double criSso = 0;
	double wcriSso = 0;
	double randomSso = 0;
	double ftcSso = 0;
	
	public double getCriCost() {
		return criCost;
	}
	public void setCriCost(double criCost) {
		this.criCost = criCost;
	}
	public double getWcriCost() {
		return wcriCost;
	}
	public void setWcriCost(double wcriCost) {
		this.wcriCost = wcriCost;
	}
	public double getFtcCost() {
		return ftcCost;
	}
	public void setFtcCost(double ftcCost) {
		this.ftcCost = ftcCost;
	}
	public double getRandomCost() {
		return randomCost;
	}
	public void setRandomCost(double randomCost) {
		this.randomCost = randomCost;
	}
	double criCost;
	double wcriCost;
	double ftcCost;
	double randomCost;

	public double getCriFtCostEffi() {
		return criFtCostEffi;
	}
	public void setCriFtCostEffi(double criFtCostEffi) {
		this.criFtCostEffi = criFtCostEffi;
	}
	public double getWcriFtCostEffi() {
		return wcriFtCostEffi;
	}
	public void setWcriFtCostEffi(double wcriFtCostEffi) {
		this.wcriFtCostEffi = wcriFtCostEffi;
	}
	public double getFtcFtCostEffi() {
		return ftcFtCostEffi;
	}
	public void setFtcFtCostEffi(double ftcFtCostEffi) {
		this.ftcFtCostEffi = ftcFtCostEffi;
	}
	public double getRandomFtCostEffi() {
		return randomFtCostEffi;
	}
	public void setRandomFtCostEffi(double randomFtCostEffi) {
		this.randomFtCostEffi = randomFtCostEffi;
	}
	double criFtCostEffi;
	double wcriFtCostEffi;
	double ftcFtCostEffi;
	double randomFtCostEffi;
	
	public double getCriRedundantPercentage() {
		return criRedundantPercentage;
	}
	public void setCriRedundantPercentage(double criRedundantPercentage) {
		this.criRedundantPercentage = criRedundantPercentage;
	}
	public double getWcriRedundantPercentage() {
		return wcriRedundantPercentage;
	}
	public void setWcriRedundantPercentage(double wcriRedundantPercentage) {
		this.wcriRedundantPercentage = wcriRedundantPercentage;
	}
	public double getFtcRedundantPercentage() {
		return ftcRedundantPercentage;
	}
	public void setFtcRedundantPercentage(double ftcRedundantPercentage) {
		this.ftcRedundantPercentage = ftcRedundantPercentage;
	}
	public double getRandomRedundantPercentage() {
		return randomRedundantPercentage;
	}
	public void setRandomRedundantPercentage(double randomRedundantPercentage) {
		this.randomRedundantPercentage = randomRedundantPercentage;
	}
	double criRedundantPercentage = 0;
	double wcriRedundantPercentage = 0;
	double ftcRedundantPercentage = 0;
	double randomRedundantPercentage = 0;
	
    int criSucc;
    int wcriSucc;
    int randomSucc;
    int ftCloudSucc;
 
    int criSuccTotal;
    int wcriSuccTotal;
    int randomSuccTotal;
    int ftCloudSuccTotal;
    
    public int getFtCloudSucc() {
		return ftCloudSucc;
	}
	public void setFtCloudSucc(int ftCloudSucc) {
		this.ftCloudSucc = ftCloudSucc;
	}
	double criRtIncr;
    double wcriRtIncr;
    double randomRtIncr;
    double ftCloudRtIncr;
    
    public double getFtCloudRt() {
		return ftCloudRt;
	}
	public void setFtCloudRt(double ftCloudRt) {
		this.ftCloudRt = ftCloudRt;
	}
	public double getFtCloudRtIncr() {
		return ftCloudRtIncr;
	}
	public void setFtCloudRtIncr(double ftCloudRtIncr) {
		this.ftCloudRtIncr = ftCloudRtIncr;
	}
	public double getFtCloudRtIncrP() {
		return ftCloudRtIncrP;
	}
	public void setFtCloudRtIncrP(double ftCloudRtIncrP) {
		this.ftCloudRtIncrP = ftCloudRtIncrP;
	}
	public double getNewFtCloudRT() {
		return newFtCloudRT;
	}
	public void setNewFtCloudRT(double newFtCloudRT) {
		this.newFtCloudRT = newFtCloudRT;
	}
	public double getNewFtCloudRE() {
		return newFtCloudRE;
	}
	public void setNewFtCloudRE(double newFtCloudRE) {
		this.newFtCloudRE = newFtCloudRE;
	}
	public double getNewFtCloudTP() {
		return newFtCloudTP;
	}
	public void setNewFtCloudTP(double newFtCloudTP) {
		this.newFtCloudTP = newFtCloudTP;
	}
	public double getFtCloudTpDecr() {
		return ftCloudTpDecr;
	}
	public void setFtCloudTpDecr(double ftCloudTpDecr) {
		this.ftCloudTpDecr = ftCloudTpDecr;
	}
	public double getFtCloudTpDecrP() {
		return ftCloudTpDecrP;
	}
	public void setFtCloudTpDecrP(double ftCloudTpDecrP) {
		this.ftCloudTpDecrP = ftCloudTpDecrP;
	}
	public double getFtCloudReIncr() {
		return ftCloudReIncr;
	}
	public void setFtCloudReIncr(double ftCloudReIncr) {
		this.ftCloudReIncr = ftCloudReIncr;
	}
	public double getFtCloudReIncrP() {
		return ftCloudReIncrP;
	}
	public void setFtCloudReIncrP(double ftCloudReIncrP) {
		this.ftCloudReIncrP = ftCloudReIncrP;
	}
	public double getFtcloudUtility() {
		return ftcloudUtility;
	}
	public void setFtcloudUtility(double ftcloudUtility) {
		this.ftcloudUtility = ftcloudUtility;
	}
	public double[] getFtcloudSolutionArray() {
		return ftcloudSolutionArray;
	}
	public void setFtcloudSolutionArray(double[] ftcloudSolutionArray) {
		this.ftcloudSolutionArray = ftcloudSolutionArray;
	}
	double criRtIncrP;
    double wcriRtIncrP;
    double randomRtIncrP;
    double ftCloudRtIncrP;
    
    double newCriRT;
    double newWcriRT;
    double newRandomRT;
    double newFtCloudRT;
    
    double newCriRE;
    double newWcriRE;
    double newRandomRE;
    double newFtCloudRE;
    
    double newCriTP;
    double newWcriTP;
    double newRandomTP;
    double newFtCloudTP;
    
    double criTpDecr;
    double wcriTpDecr;
    double randomTpDecr;
    double ftCloudTpDecr;
    
    double criTpDecrP;
    double wcriTpDecrP;
    double randomTpDecrP;
    double ftCloudTpDecrP;
    
    double criReIncr;
    double wcriReIncr;
    double randomReIncr;
    double ftCloudReIncr;
    
    double criReIncrP;
    double wcriReIncrP;
    double randomReIncrP;
    double ftCloudReIncrP;
    
    int newTP;
    String criSolution;
    String wcriSolution;
    String randomSolution;
    
    double criUtility;
    double wcriUtility;
    double randomUtility;
    double ftcloudUtility;
    
    int failedId;
    double delay;
    double[] criSolutionArray;
    double[] wcriSolutionArray;
    double[] randomSolutionArray;
    double[] ftcloudSolutionArray;
    AggregateService[] criFtStrategyArray;
    AggregateService[] wcriFtStrategyArray;
    AggregateService[] randomFtStrategyArray;
    AggregateService[] ftcFtStrategyArray;
    
    public double ftcFb = 0;
  
    public int getCriAffectedTenantPercentage() {
		return criAffectedTenant/Config.NUM_TENANTS;
	}
    
    public int getCriAffectedTenant() {
		return criAffectedTenant;
	}
    
	public void setCriAffectedTenant(int criAffectedTenant) {
		this.criAffectedTenant = criAffectedTenant;
	}
	
	public int getWcriAffectedTenantPercentage() {
		return wcriAffectedTenant/Config.NUM_TENANTS;
	}
	
	public int getWcriAffectedTenant() {
		return wcriAffectedTenant;
	}
	public void setWcriAffectedTenant(int wcriAffectedTenant) {
		this.wcriAffectedTenant = wcriAffectedTenant;
	}
	
	public int getRandomAffectedTenantPercentage() {
		return randomAffectedTenant/Config.NUM_TENANTS;
	}
	
	public int getRandomAffectedTenant() {
		return randomAffectedTenant;
	}
	public void setRandomAffectedTenant(int randomAffectedTenant) {
		this.randomAffectedTenant = randomAffectedTenant;
	}
	public int getFtcAffectedTenantPercentage() {
		return ftcAffectedTenant/Config.NUM_TENANTS;
	}	
	public int getFtcAffectedTenant() {
		return ftcAffectedTenant;
	}
	public void setFtcAffectedTenant(int ftcAffectedTenant) {
		this.ftcAffectedTenant = ftcAffectedTenant;
	}
	int criAffectedTenant;
    int wcriAffectedTenant;
    int randomAffectedTenant;
    int ftcAffectedTenant;

	public CplexOpt(ServiceComposition composition) {
		this.composition = composition;
		criSolutionArray = new double[Config.NUM_SERVICE_CLASSES];
		wcriSolutionArray = new double[Config.NUM_SERVICE_CLASSES];
		randomSolutionArray = new double[Config.NUM_SERVICE_CLASSES];
		ftcloudSolutionArray = new double[Config.NUM_SERVICE_CLASSES];
		
	    criFtStrategyArray = new AggregateService[Config.NUM_SERVICE_CLASSES];
	    wcriFtStrategyArray = new AggregateService[Config.NUM_SERVICE_CLASSES];
	    randomFtStrategyArray = new AggregateService[Config.NUM_SERVICE_CLASSES];
	    ftcFtStrategyArray = new AggregateService[Config.NUM_SERVICE_CLASSES];
	    
	}
	public void sloveByCriticalityTopK(int k) throws IloException {
		double timeStamp;
		double totalTime = 0;
		double objective = 0;
		
		double currTime = System.currentTimeMillis();
		
		composition.compScheme.calculateQos();
		
		originalRt = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];
		originalTp = composition.compScheme.getQosValues()[Config.QOS_INDEX_THROUGHPUT];
		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Original throughput is " + originalTp);
		originalRe = composition.compScheme.getQosValues()[Config.QOS_INDEX_RELIABLITY];

		//writer.writeFile2("\r\nFind backup services with criticality begin...");
		
		IloCplex cplex = new IloCplex();
		
		int candidateAggServiceNum = composition.aggregateServiceNumPerClass;
		//System.out.println("Inspection: CRI Number of composition.aggregateServiceNumPerClass is " + composition.aggregateServiceNumPerClass);

		
		//initialise x matrix
		String[][] indexesX = new String[Config.NUM_SERVICE_CLASSES][candidateAggServiceNum];
		String[] indexesY = new String[Config.NUM_SERVICE_CLASSES];

		for (int i = 0; i < Config.NUM_SERVICE_CLASSES; ++i) {
			for (int j = 0; j < candidateAggServiceNum; ++j) {
				indexesX[i][j] = "x[" + i + "][" + j + "]";
			}
			indexesY[i] = "y[" + i + "]";
		}
	
		IloIntVar[][] x = new IloIntVar[Config.NUM_SERVICE_CLASSES][candidateAggServiceNum];
		IloIntVar[] y = new IloIntVar[Config.NUM_SERVICE_CLASSES];
		//IloIntVar k = cplex.intVar(0, Config.NUM_SERVICE_CLASSES, "k");
		
		for (int i = 0; i < Config.NUM_SERVICE_CLASSES; ++i) {
			x[i] = new IloIntVar[candidateAggServiceNum];
		}


		for (int i = 0; i < Config.NUM_SERVICE_CLASSES; ++i) {
			for (int j = 0; j < candidateAggServiceNum; ++j) {
				x[i][j] = cplex.intVar(0, 1, indexesX[i][j]);
			}
			y[i] = cplex.intVar(0, 1, indexesY[i]);
		}

		
		//add constraints (1): a maximum of one candidate service is selected in each class

		for (int i = 0; i < Config.NUM_SERVICE_CLASSES; ++i) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			for (int j = 0; j < candidateAggServiceNum; ++j) {
				expr.addTerm(1.0, x[i][j]);
			}			
			cplex.addEq(cplex.sum(cplex.sum(1.0, cplex.prod(-1.0, y[i])), expr), 1, "C1@" + i);
		}

		// top k constraints
		for (int i=0; i<Config.NUM_SERVICE_CLASSES-1; i++) {	
			cplex.addLe(y[composition.atomicCompSchemes.get(i+1).getId()], 
					y[composition.atomicCompSchemes.get(i).getId()], "C@TopK@1@"+i);
		}
		
		IloLinearNumExpr expr = cplex.linearNumExpr();
		for (int i=0; i<Config.NUM_SERVICE_CLASSES; i++) {
			expr.addTerm(1.0, y[i]);
		}
		cplex.addEq(expr, k, "C@TopK@2");
		for (int i=0; i<Config.NUM_SERVICE_CLASSES-1; i++) {
			cplex.addEq(y[i], cplex.max(x[i]));
		}
				
		/* Add objective */	
		IloNumExpr exprObj = composition.compScheme.getNumExprOfQoS(Config.QOS_INDEX_UTILITY, cplex, x, y);
		cplex.addMaximize(exprObj);
		//IloNumExpr exprObj = composition.compScheme.getNumExprOfQoS(Config.QOS_INDEX_COST, cplex, x, y);
		//cplex.addMinimize(exprObj);
		
		IloNumExpr exprCt = composition.compScheme.getNumExprOfQoS(Config.QOS_INDEX_COST, cplex, x, y);	
		double costConstraints = composition.getConstraints().constraints[Config.QOS_INDEX_COST];
		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Cost constraints: " + costConstraints);
		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Cost numeric expressions: " + exprCt.toString());
		cplex.addGe(costConstraints, exprCt, "C@Cost");
		//cplex.addMinimize(exprCt);

		IloNumExpr exprRe = composition.compScheme.getNumExprOfQoS(Config.QOS_INDEX_RELIABLITY, cplex, x, y);		
		double reliabilityConstraints = composition.getConstraints().constraints[Config.QOS_INDEX_RELIABLITY];
		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Reliability constraints: " + reliabilityConstraints);
		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Reliability numeric expressions: " + exprRe.toString());
		cplex.addLe(Math.log(reliabilityConstraints), exprRe, "C@Reliability");

		IloNumExpr exprTp = composition.compScheme.getNumExprOfQoS(Config.QOS_INDEX_THROUGHPUT, cplex, x, y);
		double throughputConstraints = composition.getConstraints().constraints[Config.QOS_INDEX_THROUGHPUT];
		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Throughput constraints: " + throughputConstraints);
		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Throughput numeric expressions: " + exprTp.toString());
		cplex.addLe(throughputConstraints, exprTp, "C@Throughput");
		
		IloNumExpr exprRt = composition.compScheme.getNumExprOfQoS(Config.QOS_INDEX_RESPONSETIME, cplex, x, y);
		double responseTimeConstraints = composition.getConstraints().constraints[Config.QOS_INDEX_RESPONSETIME];
		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Responsetime constraints: " + responseTimeConstraints);
		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Responsetime numeric expressions: " + exprRt.toString());
		cplex.addGe(responseTimeConstraints, exprRt, "C@Responsetime");
				
		timeStamp = System.currentTimeMillis() - currTime;
		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "TimeStamp: Adding constraints consumed time: " + timeStamp + " ms");
		//totalTime += timeStamp;
		currTime = System.currentTimeMillis();
		//cplex.exportModel("Model.lp");
		/* Solve the optimization problem in optimized search space */
		try {
			if ( cplex.solve() ) {
				//cplex.exportModel("scheduler.lp");
				timeStamp = System.currentTimeMillis() - currTime;
				if (IloCplex.Status.Optimal != cplex.getStatus()) {
					System.out.println("Cannot get optimal solution in specified time limit, then return");
					return;
				}

			    
				//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "TimeStamp: Solving with solution consumed time: " + timeStamp + " ms");
				totalTime += timeStamp;

			    //LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Solution status = " + cplex.getStatus());
			    //LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Solution value  = " + cplex.getObjValue());
			    objective = cplex.getObjValue();

			    //LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Qos Constraints: " + Arrays.toString(composition.getConstraints().constraints));
			    //writer.writeFile2("Qos Constraints: " + Arrays.toString(composition.getConstraints().constraints));
			    criSolution = new String("");
			    double[] varY = cplex.getValues(y);
				for (int i = 0; i < composition.atomicCompSchemes.size(); i++) {
					if (Math.abs(varY[composition.atomicCompSchemes.get(i).getId()] - 1.0) <= 0.001f) {
						composition.atomicCompSchemes.get(i).setRedundant(true);
						criSolution = criSolution.concat("S" + composition.atomicCompSchemes.get(i).getId() + " ");
						criSolutionArray[composition.atomicCompSchemes.get(i).getId()] = 1.0;
						//System.out.println("CRI: Variable Y[" + composition.atomicCompSchemes.get(i).getId() + "] = " + varY[composition.atomicCompSchemes.get(i).getId()]);					
					}
				}	
				
				for (int i = 0; i < composition.atomicCompSchemes.size(); i++) {
					
					double[] varX = cplex.getValues(x[composition.atomicCompSchemes.get(i).getId()]);
					for (int j = 0; j < varX.length; j++) {
						if (Math.abs(varX[j] - 1.0) <= 0.001f) {
//							System.out.println("X[" + composition.atomicCompSchemes.get(i).getId() + "][" + j + "] = 1");
//							System.out.println("Service " + composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j).servicdId
//									+ ", qos = " + Arrays.toString(composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j).qos)
//									+ ", utility = " + composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j).utility);
//							//composition.atomicCompSchemes.get(i).setServiceInstance(composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j));
//							//composition.atomicCompSchemes.get(i).setRedundant(true);
							composition.atomicCompSchemes.get(i).isRedundantArray[0] = true;
							criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()] = composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j);
							//writer.writeFile2("Find backup service for S" + composition.atomicCompSchemes.get(i).getId());
							System.out.println("CRI: Backup Service[" + composition.atomicCompSchemes.get(i).getId() + "][" + j + "]: " + 
								Arrays.toString(composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j).qos));
						}
					}

				}
				
				composition.compScheme.calculateQos();
				this.isHaveSolution = true;
				for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
					if ((composition.atomicCompSchemes.get(i).isFailed == true) && (composition.atomicCompSchemes.get(i).isRedundant == false)) {
						//criRt = (double)(composition.executionPaths.size() - composition.atomicCompSchemes.get(i).rank[Config.QOS_INDEX_RESPONSETIME] + 1) / composition.executionPaths.size();
						//criRt = (double)composition.atomicCompSchemes.get(i).getTenantsNum() / Config.NUM_TENANTS;
						criRt = composition.atomicCompSchemes.get(i).criticality[Config.QOS_INDEX_RESPONSETIME];
						//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Found failed service without redundancy: S" + composition.atomicCompSchemes.get(i).getId());
						//System.exit(0);
					}
				}
				//criRt = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];
				
				//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Backup Solution 1 Qos: " + Arrays.toString(composition.compScheme.getQosValues()));
				//writer.writeFile2("Qos of Solution with criticality: " + Arrays.toString(composition.compScheme.getQosValues()));
				
//				for (int i = 0; i < Config.NUM_SERVICE_CLASSES; i++) {
//					double[] varX = cplex.getValues(x[i]);
//					for (int j = 0; j < varX.length; j++) {
//						LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Variable X[" + i + "][" + j
//								+ "] = " + varX[j]);
//					}
//
//				}
				
				//collectDataCri();
							
				//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Variable K = " + cplex.getValue(k));	
				
				objective = cplex.getObjValue();
				criUtility = objective;
//				System.out.println("CRI: Objective  = " + objective);
				
				//writer.writeFile2("Find backup services with criticality end...");
			} else {
				/* Reach time limit */
				timeStamp = System.currentTimeMillis() - currTime;
				
				if (IloCplex.Status.Unknown == cplex.getStatus()) {
					LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Cannot get solution in specified time limit, then return");
					return;
				}
				
				
				//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "TimeStamp: Solving without solution consumed time: " + timeStamp + " ms");
				totalTime += timeStamp;
				
				objective = 0;
			}
		} catch (UnknownObjectException e) {
			return;
		} catch (IloException e) {
			return;
		}
		currTime = System.currentTimeMillis();
		cplex.end();
		timeStamp = System.currentTimeMillis() - currTime;
		//totalTime += timeStamp;
		
		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "TimeStamp: consumed time: " + totalTime + "ms");
		
		//rst.addRecordOfClassicModel(foundSolution, totalTime, objective);
	}
	
	public void sloveByCriCostConstrainted(double ftBudget) throws IloException {
		double timeStamp;
		double totalTime = 0;
		double objective = 0;
		
		double currTime = System.currentTimeMillis();
		
		//这里面的cost有可能是用于FT的cost而非System Cost
		composition.compScheme.calculateQos();
		
		originalRt = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];
		originalTp = composition.compScheme.getQosValues()[Config.QOS_INDEX_THROUGHPUT];
		originalRe = composition.compScheme.getQosValues()[Config.QOS_INDEX_RELIABLITY];

		IloCplex cplex = new IloCplex();
		cplex.setParam(IloCplex.DoubleParam.TiLim, 60);
		int candidateAggServiceNum = composition.aggregateServiceNumPerClass;

		String[][] indexesX = new String[Config.NUM_SERVICE_CLASSES][candidateAggServiceNum];
		String[] indexesY = new String[Config.NUM_SERVICE_CLASSES];

		//formulating the name of constraints
		for (int i = 0; i < Config.NUM_SERVICE_CLASSES; ++i) {
			for (int j = 0; j < candidateAggServiceNum; ++j) {
				indexesX[i][j] = "x[" + i + "][" + j + "]";
			}
			indexesY[i] = "y[" + i + "]";
		}
	
		//Array x is used for services, Array y is used for service class (top k)
		IloIntVar[][] x = new IloIntVar[Config.NUM_SERVICE_CLASSES][candidateAggServiceNum];
		IloIntVar[] y = new IloIntVar[Config.NUM_SERVICE_CLASSES];
		
		for (int i = 0; i < Config.NUM_SERVICE_CLASSES; ++i) {
			x[i] = new IloIntVar[candidateAggServiceNum];
		}


		for (int i = 0; i < Config.NUM_SERVICE_CLASSES; ++i) {
			for (int j = 0; j < candidateAggServiceNum; ++j) {
				x[i][j] = cplex.intVar(0, 1, indexesX[i][j]);
			}
			y[i] = cplex.intVar(0, 1, indexesY[i]);
		}

		
		//add constraints (1): a maximum of one candidate service is selected in each class
		for (int i = 0; i < Config.NUM_SERVICE_CLASSES; ++i) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			for (int j = 0; j < candidateAggServiceNum; ++j) {
				expr.addTerm(1.0, x[i][j]);
			}		
			//Array sum (x[i]) + (1-y[i]) = 1, means if y[i] is 1 then there must be (only) one 
			//candidate service will be selected, i.e., sum(x[i]) = 1
			cplex.addEq(cplex.sum(cplex.sum(1.0, cplex.prod(-1.0, y[i])), expr), 1, "C1@" + i);
		}

		// top k constraints, from most critical to the least critical
		for (int i=0; i<Config.NUM_SERVICE_CLASSES-1; i++) {	
			cplex.addLe(y[composition.atomicCompSchemes.get(i+1).getId()], 
					y[composition.atomicCompSchemes.get(i).getId()], "C@TopK@1@"+i);
		}
		
		IloLinearNumExpr expr = cplex.linearNumExpr();
		for (int i=0; i<Config.NUM_SERVICE_CLASSES; i++) {
			expr.addTerm(1.0, y[i]);
		}
		cplex.addMaximize(expr);
		//貌似是多余的限制
//		for (int i=0; i<Config.NUM_SERVICE_CLASSES; i++) {
//			cplex.addEq(y[i], cplex.max(x[i]));
//		}
				
//		/* Add objective */	
//		IloNumExpr exprObj = composition.compScheme.getNumExprOfQoS(Config.QOS_INDEX_UTILITY, cplex, x, y);
//		cplex.addMaximize(exprObj);
		//IloNumExpr exprObj = composition.compScheme.getNumExprOfQoS(Config.QOS_INDEX_COST, cplex, x, y);
		//cplex.addMinimize(exprObj);
		
		IloNumExpr exprCt = composition.compScheme.getNumExprOfQoS(Config.QOS_INDEX_FTCOST, cplex, x, y);	
		//double costConstraints = composition.getConstraints().constraints[Config.QOS_INDEX_COST];
		//System.out.println("Cost constraints: " + ftCost);
		cplex.addGe(ftBudget, exprCt, "C@Cost");
		//System.out.println(exprCt.toString());

//		IloNumExpr exprRe = composition.compScheme.getNumExprOfQoS(Config.QOS_INDEX_RELIABLITY, cplex, x, y);		
//		double reliabilityConstraints = composition.getConstraints().constraints[Config.QOS_INDEX_RELIABLITY];
//		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Reliability constraints: " + reliabilityConstraints);
//		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Reliability numeric expressions: " + exprRe.toString());
//		cplex.addLe(Math.log(reliabilityConstraints), exprRe, "C@Reliability");
//		
//
//		IloNumExpr exprTp = composition.compScheme.getNumExprOfQoS(Config.QOS_INDEX_THROUGHPUT, cplex, x, y);
//		double throughputConstraints = composition.getConstraints().constraints[Config.QOS_INDEX_THROUGHPUT];
//		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Throughput constraints: " + throughputConstraints);
//		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Throughput numeric expressions: " + exprTp.toString());
//		cplex.addLe(throughputConstraints, exprTp, "C@Throughput");
//		
//		IloNumExpr exprRt = composition.compScheme.getNumExprOfQoS(Config.QOS_INDEX_RESPONSETIME, cplex, x, y);
//		double responseTimeConstraints = composition.getConstraints().constraints[Config.QOS_INDEX_RESPONSETIME];
//		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Responsetime constraints: " + responseTimeConstraints);
//		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Responsetime numeric expressions: " + exprRt.toString());
//		cplex.addGe(responseTimeConstraints, exprRt, "C@Responsetime");
				
		timeStamp = System.currentTimeMillis() - currTime;
		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "TimeStamp: Adding constraints consumed time: " + timeStamp + " ms");
		//totalTime += timeStamp;
		currTime = System.currentTimeMillis();
		//cplex.exportModel("Model.lp");
		/* Solve the optimization problem in optimized search space */
		try {
			if ( cplex.solve() ) {
				//cplex.exportModel("scheduler.lp");
				timeStamp = System.currentTimeMillis() - currTime;
				
				this.criSso = timeStamp;
				
				if (IloCplex.Status.Optimal != cplex.getStatus()) {
					System.out.println("Cannot get optimal solution in specified time limit, then return");
					return;
				}
				
				totalTime += timeStamp;

			    objective = cplex.getObjValue();

			    criSolution = new String("");
			    double[] varY = cplex.getValues(y);
			    int ftscy = 0;
				for (int i = 0; i < composition.atomicCompSchemes.size(); i++) {
					if (Math.abs(varY[composition.atomicCompSchemes.get(i).getId()] - 1.0) <= 0.001f) {
						criSolution = criSolution.concat("S" + composition.atomicCompSchemes.get(i).getId() + " ");
						criSolutionArray[composition.atomicCompSchemes.get(i).getId()] = 1.0;
						ftscy++;
					}
				}	
				
				int ftscx = 0;
				double criUsedBudget = 0;
				for (int i = 0; i < composition.atomicCompSchemes.size(); i++) {
					double[] varX = cplex.getValues(x[composition.atomicCompSchemes.get(i).getId()]);
					for (int j = 0; j < varX.length; j++) {
						if (Math.abs(varX[j] - 1.0) <= 0.001f) {
//							System.out.println("X[" + composition.atomicCompSchemes.get(i).getId() + "][" + j + "] = 1");
//							System.out.println("Service " + composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j).servicdId
//									+ ", qos = " + Arrays.toString(composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j).qos)
//									+ ", utility = " + composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j).utility);
							criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()] = composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j);
							criUsedBudget += composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j).qos[Config.QOS_INDEX_COST] - 
									composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_COST];
//							System.out.println("CRI: Backup Service[" + composition.atomicCompSchemes.get(i).getId() + "][" + j + "]: " + 
//								Arrays.toString(composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j).qos)
//								+ ", instance cost is " + composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_COST]
//								+ ", total used budget is " + criUsedBudget);
							ftscx++;
						}
					}

				}
				
				composition.compScheme.calculateQos();
				this.isHaveSolution = true;

				objective = cplex.getObjValue();
				criUtility = objective;
				this.criFtCostEffi = criUsedBudget / ftBudget;
				this.criRedundantPercentage = ftscy / Config.NUM_SERVICE_CLASSES;
//				System.out.println("CRI: FTSC[y] is " + ftscy + ", FTSC[x] is " + ftscx + ", Objective  = " + objective + 
//						", ft cost effi is " + this.criFtCostEffi);
			} else {
				/* Reach time limit */
				timeStamp = System.currentTimeMillis() - currTime;
				
				if (IloCplex.Status.Unknown == cplex.getStatus()) {
					LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Cannot get solution in specified time limit, then return");
					return;
				}
				
				
				//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "TimeStamp: Solving without solution consumed time: " + timeStamp + " ms");
				totalTime += timeStamp;
				
				objective = 0;
			}
		} catch (UnknownObjectException e) {
			return;
		} catch (IloException e) {
			return;
		}
		currTime = System.currentTimeMillis();
		cplex.end();
		timeStamp = System.currentTimeMillis() - currTime;
		//totalTime += timeStamp;
		
		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "TimeStamp: consumed time: " + totalTime + "ms");
		
		//rst.addRecordOfClassicModel(foundSolution, totalTime, objective);
	}	
	public void sloveByFtcCostConstrainted(double ftBudget) throws IloException {
		double timeStamp;
		double totalTime = 0;
		double objective = 0;
		
		double currTime = System.currentTimeMillis();
		
		//这里面的cost有可能是用于FT的cost而非System Cost
		composition.compScheme.calculateQos();
		
		originalRt = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];
		originalTp = composition.compScheme.getQosValues()[Config.QOS_INDEX_THROUGHPUT];
		originalRe = composition.compScheme.getQosValues()[Config.QOS_INDEX_RELIABLITY];

		for (int i=0; i<this.ftcloudSolutionArray.length; i++) {
			this.ftcloudSolutionArray[i] = 0.0;
			this.ftcFtStrategyArray[i] = null;
		}
		
		composition.sortServicesByV();

		
		IloCplex cplex = new IloCplex();
		cplex.setParam(IloCplex.DoubleParam.TiLim, 60);
		int candidateAggServiceNum = composition.aggregateServiceNumPerClass;

		String[][] indexesX = new String[Config.NUM_SERVICE_CLASSES][candidateAggServiceNum];
		String[] indexesY = new String[Config.NUM_SERVICE_CLASSES];

		//formulating the name of constraints
		for (int i = 0; i < Config.NUM_SERVICE_CLASSES; ++i) {
			for (int j = 0; j < candidateAggServiceNum; ++j) {
				indexesX[i][j] = "x[" + i + "][" + j + "]";
			}
			indexesY[i] = "y[" + i + "]";
		}
	
		//Array x is used for services, Array y is used for service class (top k)
		IloIntVar[][] x = new IloIntVar[Config.NUM_SERVICE_CLASSES][candidateAggServiceNum];
		IloIntVar[] y = new IloIntVar[Config.NUM_SERVICE_CLASSES];
		
		for (int i = 0; i < Config.NUM_SERVICE_CLASSES; ++i) {
			x[i] = new IloIntVar[candidateAggServiceNum];
		}


		for (int i = 0; i < Config.NUM_SERVICE_CLASSES; ++i) {
			for (int j = 0; j < candidateAggServiceNum; ++j) {
				x[i][j] = cplex.intVar(0, 1, indexesX[i][j]);
			}
			y[i] = cplex.intVar(0, 1, indexesY[i]);
		}

		
		//add constraints (1): a maximum of one candidate service is selected in each class
		for (int i = 0; i < Config.NUM_SERVICE_CLASSES; ++i) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			for (int j = 0; j < candidateAggServiceNum; ++j) {
				expr.addTerm(1.0, x[i][j]);
			}		
			//Array sum (x[i]) + (1-y[i]) = 1, means if y[i] is 1 then there must be (only) one 
			//candidate service will be selected, i.e., sum(x[i]) = 1
			cplex.addEq(cplex.sum(cplex.sum(1.0, cplex.prod(-1.0, y[i])), expr), 1, "C1@" + i);
		}

		// top k constraints, from most critical to the least critical
		for (int i=0; i<Config.NUM_SERVICE_CLASSES-1; i++) {	
			cplex.addLe(y[composition.atomicCompSchemes.get(i+1).getId()], 
					y[composition.atomicCompSchemes.get(i).getId()], "C@TopK@1@"+i);
		}
		
//		IloLinearNumExpr expr = cplex.linearNumExpr();
//		for (int i=0; i<Config.NUM_SERVICE_CLASSES; i++) {
//			expr.addTerm(1.0, y[i]);
//		}
//		cplex.addMaximize(expr);
		//貌似是多余的限制
//		for (int i=0; i<Config.NUM_SERVICE_CLASSES; i++) {
//			cplex.addEq(y[i], cplex.max(x[i]));
//		}
//				
//		/* Add objective */	
//		IloNumExpr exprObj = composition.compScheme.getNumExprOfQoS(Config.QOS_INDEX_UTILITY, cplex, x, y);
//		cplex.addMaximize(exprObj);
		//IloNumExpr exprObj = composition.compScheme.getNumExprOfQoS(Config.QOS_INDEX_COST, cplex, x, y);
		//cplex.addMinimize(exprObj);
		
		IloNumExpr exprObj = composition.compScheme.getNumExprOfQoS(Config.QOS_INDEX_FB, cplex, x, y);
		cplex.addMinimize(exprObj);
		
		IloNumExpr exprCt = composition.compScheme.getNumExprOfQoS(Config.QOS_INDEX_FTCOST, cplex, x, y);	
		//double costConstraints = composition.getConstraints().constraints[Config.QOS_INDEX_COST];
		//System.out.println("Cost constraints: " + ftCost);
		cplex.addGe(ftBudget, exprCt, "C@Cost");
		//System.out.println(exprCt.toString());

//		IloNumExpr exprRe = composition.compScheme.getNumExprOfQoS(Config.QOS_INDEX_RELIABLITY, cplex, x, y);		
//		double reliabilityConstraints = composition.getConstraints().constraints[Config.QOS_INDEX_RELIABLITY];
//		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Reliability constraints: " + reliabilityConstraints);
//		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Reliability numeric expressions: " + exprRe.toString());
//		cplex.addLe(Math.log(reliabilityConstraints), exprRe, "C@Reliability");
//		
//
//		IloNumExpr exprTp = composition.compScheme.getNumExprOfQoS(Config.QOS_INDEX_THROUGHPUT, cplex, x, y);
//		double throughputConstraints = composition.getConstraints().constraints[Config.QOS_INDEX_THROUGHPUT];
//		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Throughput constraints: " + throughputConstraints);
//		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Throughput numeric expressions: " + exprTp.toString());
//		cplex.addLe(throughputConstraints, exprTp, "C@Throughput");
//		
//		IloNumExpr exprRt = composition.compScheme.getNumExprOfQoS(Config.QOS_INDEX_RESPONSETIME, cplex, x, y);
//		double responseTimeConstraints = composition.getConstraints().constraints[Config.QOS_INDEX_RESPONSETIME];
//		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Responsetime constraints: " + responseTimeConstraints);
//		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Responsetime numeric expressions: " + exprRt.toString());
//		cplex.addGe(responseTimeConstraints, exprRt, "C@Responsetime");
				
		timeStamp = System.currentTimeMillis() - currTime;
		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "TimeStamp: Adding constraints consumed time: " + timeStamp + " ms");
		//totalTime += timeStamp;
		currTime = System.currentTimeMillis();
		//cplex.exportModel("Model.lp");
		/* Solve the optimization problem in optimized search space */
		try {
			if ( cplex.solve() ) {
				//cplex.exportModel("scheduler.lp");
				timeStamp = System.currentTimeMillis() - currTime;
				
				this.ftcSso = timeStamp;
				
				if (IloCplex.Status.Optimal != cplex.getStatus()) {
					System.out.println("FTCloud: Cannot get optimal solution in specified time limit, then return");
					return;
				}
				
				totalTime += timeStamp;

			    objective = cplex.getObjValue();

			    //System.out.println("FTCloud Global Optimisation Results: ");

			    double[] varY = cplex.getValues(y);
			    int ftscy = 0;
				for (int i = 0; i < composition.atomicCompSchemes.size(); i++) {
					if (Math.abs(varY[composition.atomicCompSchemes.get(i).getId()] - 1.0) <= 0.001f) {
						ftcloudSolutionArray[composition.atomicCompSchemes.get(i).getId()] = 1.0;
						ftscy++;
					}
				}	
				
				int ftscx = 0;
				double ftcUsedBudget = 0;
				for (int i = 0; i < composition.atomicCompSchemes.size(); i++) {
					double[] varX = cplex.getValues(x[composition.atomicCompSchemes.get(i).getId()]);
					for (int j = 0; j < varX.length; j++) {
						if (Math.abs(varX[j] - 1.0) <= 0.001f) {
//							System.out.println("X[" + composition.atomicCompSchemes.get(i).getId() + "][" + j + "] = 1");
//							System.out.println("Service " + composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j).servicdId
//									+ ", qos = " + Arrays.toString(composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j).qos)
//									+ ", utility = " + composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j).utility);
//							System.out.println("Failure Probability: " + composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j).failureProbability);
							ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()] = composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j);
							//ftcloudSolutionArray[composition.atomicCompSchemes.get(i).getId()] = 1.0;
							ftcUsedBudget += composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j).qos[Config.QOS_INDEX_COST] - 
									composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_COST];
//							System.out.println("CRI: Backup Service[" + composition.atomicCompSchemes.get(i).getId() + "][" + j + "]: " + 
//								Arrays.toString(composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j).qos)
//								+ ", redundancy mode is " + composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j).getRedundantMode()
//								+ ", instance cost is " + composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_COST]
//								+ ", total used budget is " + ftcUsedBudget 
//								+ ", failure probability is " + composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j).failureProbability);
							ftscx++;
						}
					}

				}
				
				composition.compScheme.calculateQos();
				//this.isHaveSolution = true;

				objective = cplex.getObjValue();
				ftcFb = objective;
				this.ftcFtCostEffi = ftcUsedBudget / ftBudget;
				this.ftcRedundantPercentage = ftscy / Config.NUM_SERVICE_CLASSES;
//				System.out.println("CRI: FTSC[y] is " + ftscy + ", FTSC[x] is " + ftscx + ", Objective  = " + objective + 
//						", ft cost effi is " + this.criFtCostEffi);
			} else {
				/* Reach time limit */
				timeStamp = System.currentTimeMillis() - currTime;
				
				if (IloCplex.Status.Unknown == cplex.getStatus()) {
					LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Cannot get solution in specified time limit, then return");
					return;
				}
				
				
				//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "TimeStamp: Solving without solution consumed time: " + timeStamp + " ms");
				totalTime += timeStamp;
				
				objective = 0;
			}
		} catch (UnknownObjectException e) {
			return;
		} catch (IloException e) {
			return;
		}
		currTime = System.currentTimeMillis();
		cplex.end();
		timeStamp = System.currentTimeMillis() - currTime;
		
		composition.sortCompSchemesById();
		
		//totalTime += timeStamp;
		
		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "TimeStamp: consumed time: " + totalTime + "ms");
		
		//rst.addRecordOfClassicModel(foundSolution, totalTime, objective);
	}	
	public void sloveWithoutCriticality(int k) throws IloException {
		double timeStamp;
		double totalTime = 0;
		double objective = 0;
		
		double currTime = System.currentTimeMillis();
		composition.compScheme.calculateQos();
		
		//originalRt = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];
		
		//writer.writeFile2("\r\nFind backup services without criticality begin...");
		
		IloCplex cplex = new IloCplex();
		
		int candidateAggServiceNum = composition.aggregateServiceNumPerClass;
		//System.out.println("Inspection: WCRI Number of composition.aggregateServiceNumPerClass is " + composition.aggregateServiceNumPerClass);

		//initialise x matrix
		String[][] indexesX = new String[Config.NUM_SERVICE_CLASSES][candidateAggServiceNum + 1];
		for (int i = 0; i < Config.NUM_SERVICE_CLASSES; ++i) {
			for (int j = 0; j < candidateAggServiceNum; ++j) {
				indexesX[i][j] = "x[" + i + "][" + j + "]";
			}
		}
	
		IloIntVar[][] x = new IloIntVar[Config.NUM_SERVICE_CLASSES][candidateAggServiceNum+1];
		
		for (int i = 0; i < Config.NUM_SERVICE_CLASSES; ++i) {
			x[i] = new IloIntVar[candidateAggServiceNum+1];
		}


		for (int i = 0; i < Config.NUM_SERVICE_CLASSES; ++i) {
			for (int j = 0; j < candidateAggServiceNum+1; ++j) {
				x[i][j] = cplex.intVar(0, 1, indexesX[i][j]);
			}
		}

		
		//add constraints (1): a maximum of one candidate service is selected in each class
		IloLinearNumExpr exprK = cplex.linearNumExpr();
		for (int i = 0; i < Config.NUM_SERVICE_CLASSES; ++i) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			for (int j = 0; j < candidateAggServiceNum+1; ++j) {
				expr.addTerm(1.0, x[i][j]);
			}			
			cplex.addEq(expr, 1, "C1@" + i);
			exprK.addTerm(1.0, x[i][0]);
		}
		
		cplex.addEq(exprK, Config.NUM_SERVICE_CLASSES-k, "Ck");
		
		/* Add objective */	
		IloNumExpr exprObj = composition.compScheme.getNumExprOfQoS2(Config.QOS_INDEX_UTILITY, cplex, x);
		cplex.addMaximize(exprObj);
		//IloNumExpr exprObj = composition.compScheme.getNumExprOfQoS2(Config.QOS_INDEX_COST, cplex, x);
		//cplex.addMinimize(exprObj);

		IloNumExpr exprCt = composition.compScheme.getNumExprOfQoS2(Config.QOS_INDEX_COST, cplex, x);
		double costConstraints = composition.getConstraints().constraints[Config.QOS_INDEX_COST];
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Cost constraints: " + costConstraints);
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Cost numeric expressions: " + exprCt.toString());
		cplex.addGe(costConstraints, exprCt, "C@Cost");

		//cplex.addMinimize(exprCt);
		
		IloNumExpr exprRe = composition.compScheme.getNumExprOfQoS2(Config.QOS_INDEX_RELIABLITY, cplex, x);		
		double reliabilityConstraints = composition.getConstraints().constraints[Config.QOS_INDEX_RELIABLITY];
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Reliability constraints: " + reliabilityConstraints);
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Reliability numeric expressions: " + exprRe.toString());
		cplex.addLe(Math.log(reliabilityConstraints), exprRe, "C@Reliability");

		IloNumExpr exprTp = composition.compScheme.getNumExprOfQoS2(Config.QOS_INDEX_THROUGHPUT, cplex, x);
		double throughputConstraints = composition.getConstraints().constraints[Config.QOS_INDEX_THROUGHPUT];
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Throughput constraints: " + throughputConstraints);
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Throughput numeric expressions: " + exprTp.toString());
		cplex.addLe(throughputConstraints, exprTp, "C@Throughput");
		
		IloNumExpr exprRt = composition.compScheme.getNumExprOfQoS2(Config.QOS_INDEX_RESPONSETIME, cplex, x);
		double responseTimeConstraints = composition.getConstraints().constraints[Config.QOS_INDEX_RESPONSETIME];
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Responsetime constraints: " + responseTimeConstraints);
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Responsetime numeric expressions: " + exprRt.toString());
		cplex.addGe(responseTimeConstraints, exprRt, "C@Responsetime");
				
		timeStamp = System.currentTimeMillis() - currTime;
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "TimeStamp: Adding constraints consumed time: " + timeStamp + " ms");
		//totalTime += timeStamp;
		currTime = System.currentTimeMillis();
		//cplex.exportModel("Model.lp");
		/* Solve the optimization problem in optimized search space */
		try {
			if ( cplex.solve() ) {
				//cplex.exportModel("scheduler.lp");
				timeStamp = System.currentTimeMillis() - currTime;
				if (IloCplex.Status.Optimal != cplex.getStatus()) {
					LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Cannot get optimal solution in specified time limit, then return");
					return;
				}

			    
				LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "TimeStamp: Solving with solution consumed time: " + timeStamp + " ms");
				totalTime += timeStamp;

			    objective = cplex.getObjValue();

			    LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Qos Constraints: " + Arrays.toString(composition.getConstraints().constraints));
			    wcriSolution = new String("");
			    for (int i = 0; i < composition.atomicCompSchemes.size(); i++) {
					double[] varX = cplex.getValues(x[composition.atomicCompSchemes.get(i).getId()]);
					for (int j = 0; j < varX.length; j++) {
						if (Math.abs(varX[j] - 1.0) <= 0.001f) {
							if (j != 0) {
//								System.out.println("X[" + composition.atomicCompSchemes.get(i).getId() + "][" + j + "] = 1");
//								System.out.println("Service " + composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j-1).servicdId
//										+ ", qos = " + Arrays.toString(composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j-1).qos)
//										+ ", utility = " + composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j-1).utility);

								//composition.atomicCompSchemes.get(i).setServiceInstance(composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j-1));
								//composition.atomicCompSchemes.get(i).setRedundant(true);
								//composition.atomicCompSchemes.get(i).setFtStrategy(composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j));
								wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()] = composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j-1);
								wcriSolutionArray[composition.atomicCompSchemes.get(i).getId()] = 1.0;
								wcriSolution = wcriSolution.concat("S" + composition.atomicCompSchemes.get(i).getId() + " ");
								composition.atomicCompSchemes.get(i).isRedundantArray[1] = true;
								//writer.writeFile2("Find backup service for S" + composition.atomicCompSchemes.get(i).getId());
								System.out.println("WCRI: Backup Service[" + composition.atomicCompSchemes.get(i).getId() + "][" + j + "]: " + 
										Arrays.toString(composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j-1).qos));								
							} else {
								LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "No Backup Original Service[" + i + "][0]: " + 
										Arrays.toString(composition.atomicCompSchemes.get(i).getServiceInstance().qos));
								//System.out.println("X[" + composition.atomicCompSchemes.get(i).getId() + "] = 1");
							}
						}
					}

				}
				composition.compScheme.calculateQos();
				for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
					if ((composition.atomicCompSchemes.get(i).isFailed == true) && (composition.atomicCompSchemes.get(i).isRedundant == false)) {
						//wcriRt = (double)(composition.executionPaths.size() - composition.atomicCompSchemes.get(i).rank[Config.QOS_INDEX_RESPONSETIME] + 1) / composition.executionPaths.size();
						//wcriRt = (double)composition.atomicCompSchemes.get(i).getTenantsNum() / Config.NUM_TENANTS;
						wcriRt = composition.atomicCompSchemes.get(i).criticality[Config.QOS_INDEX_RESPONSETIME];
					}
				}
				//wcriRt = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];
				LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Backup Solution 2 Qos: " + Arrays.toString(composition.compScheme.getQosValues()));

//				for (int i = 0; i < Config.NUM_SERVICE_CLASSES; i++) {
//					double[] varX = cplex.getValues(x[i]);
//					for (int j = 0; j < varX.length; j++) {
//						System.out.println("WCRI: Variable X[" + i + "][" + j
//								+ "] = " + varX[j]);
//					}
//
//				}
				
				//collectDataWCri();
				
				objective = cplex.getObjValue();
				wcriUtility = objective;
				//System.out.println("WCRI: Objective  = " + objective);
			} else {
				/* Reach time limit */
				timeStamp = System.currentTimeMillis() - currTime;
				
				if (IloCplex.Status.Unknown == cplex.getStatus()) {
					LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Cannot get solution in specified time limit, then return");
					return;
				}
				
				
				LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "TimeStamp: Solving without solution consumed time: " + timeStamp + " ms");
				totalTime += timeStamp;
				
				objective = 0;
				
				//writer.writeFile2("Find backup services without criticality end...");
			}
		} catch (UnknownObjectException e) {
			return;
		} catch (IloException e) {
			return;
		}
		currTime = System.currentTimeMillis();
		cplex.end();
		timeStamp = System.currentTimeMillis() - currTime;
		//totalTime += timeStamp;
		
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "TimeStamp: consumed time: " + totalTime + "ms");
		
		//rst.addRecordOfClassicModel(foundSolution, totalTime, objective);
	}
	public void sloveWithoutCriCostConstrainted(double ftBudget) throws IloException {
		double timeStamp;
		double totalTime = 0;
		double objective = 0;
		
		double currTime = System.currentTimeMillis();
		composition.compScheme.calculateQos();
		
		IloCplex cplex = new IloCplex();
		cplex.setParam(IloCplex.DoubleParam.TiLim, 60);
		int candidateAggServiceNum = composition.aggregateServiceNumPerClass;

		//initialise x matrix
		String[][] indexesX = new String[Config.NUM_SERVICE_CLASSES][candidateAggServiceNum + 1];
		for (int i = 0; i < Config.NUM_SERVICE_CLASSES; ++i) {
			for (int j = 0; j < candidateAggServiceNum; ++j) {
				indexesX[i][j] = "x[" + i + "][" + j + "]";
			}
		}
	
		IloIntVar[][] x = new IloIntVar[Config.NUM_SERVICE_CLASSES][candidateAggServiceNum+1];
		
		for (int i = 0; i < Config.NUM_SERVICE_CLASSES; ++i) {
			x[i] = new IloIntVar[candidateAggServiceNum+1];
		}


		for (int i = 0; i < Config.NUM_SERVICE_CLASSES; ++i) {
			for (int j = 0; j < candidateAggServiceNum+1; ++j) {
				x[i][j] = cplex.intVar(0, 1, indexesX[i][j]);
			}
		}

		
		//add constraints (1): a maximum of one candidate service is selected in each class
		for (int i = 0; i < Config.NUM_SERVICE_CLASSES; ++i) {
			IloLinearNumExpr expr = cplex.linearNumExpr();
			for (int j = 0; j < candidateAggServiceNum+1; ++j) {
				expr.addTerm(1.0, x[i][j]);
			}			
			cplex.addEq(expr, 1, "C1@" + i);
		}
//		IloLinearNumExpr expr = cplex.linearNumExpr();
//		for (int i = 0; i < Config.NUM_SERVICE_CLASSES; ++i) {
//			expr.addTerm(1.0, x[i][0]);
//		}
//		cplex.addMinimize(expr);
		
		/* Add objective */	
		IloNumExpr exprObj = composition.compScheme.getNumExprOfQoS2(Config.QOS_INDEX_UTILITY, cplex, x);
		cplex.addMaximize(exprObj);
		//IloNumExpr exprObj = composition.compScheme.getNumExprOfQoS2(Config.QOS_INDEX_COST, cplex, x);
		//cplex.addMinimize(exprObj);

		IloNumExpr exprCt = composition.compScheme.getNumExprOfQoS2(Config.QOS_INDEX_FTCOST, cplex, x);
		cplex.addGe(ftBudget, exprCt, "C@Cost");

		//cplex.addMinimize(exprCt);
		
//		IloNumExpr exprRe = composition.compScheme.getNumExprOfQoS2(Config.QOS_INDEX_RELIABLITY, cplex, x);		
//		double reliabilityConstraints = composition.getConstraints().constraints[Config.QOS_INDEX_RELIABLITY];
//		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Reliability constraints: " + reliabilityConstraints);
//		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Reliability numeric expressions: " + exprRe.toString());
//		cplex.addLe(Math.log(reliabilityConstraints), exprRe, "C@Reliability");
//
//		IloNumExpr exprTp = composition.compScheme.getNumExprOfQoS2(Config.QOS_INDEX_THROUGHPUT, cplex, x);
//		double throughputConstraints = composition.getConstraints().constraints[Config.QOS_INDEX_THROUGHPUT];
//		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Throughput constraints: " + throughputConstraints);
//		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Throughput numeric expressions: " + exprTp.toString());
//		cplex.addLe(throughputConstraints, exprTp, "C@Throughput");
//		
//		IloNumExpr exprRt = composition.compScheme.getNumExprOfQoS2(Config.QOS_INDEX_RESPONSETIME, cplex, x);
//		double responseTimeConstraints = composition.getConstraints().constraints[Config.QOS_INDEX_RESPONSETIME];
//		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Responsetime constraints: " + responseTimeConstraints);
//		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Responsetime numeric expressions: " + exprRt.toString());
//		cplex.addGe(responseTimeConstraints, exprRt, "C@Responsetime");
				
		timeStamp = System.currentTimeMillis() - currTime;
		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "TimeStamp: Adding constraints consumed time: " + timeStamp + " ms");
		currTime = System.currentTimeMillis();
		try {
			if ( cplex.solve() ) {
				//cplex.exportModel("scheduler.lp");
				timeStamp = System.currentTimeMillis() - currTime;
				
				this.wcriSso = timeStamp;
				
				if (IloCplex.Status.Optimal != cplex.getStatus()) {
					LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Cannot get optimal solution in specified time limit, then return");
					return;
				}

			    
				//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "TimeStamp: Solving with solution consumed time: " + timeStamp + " ms");
				totalTime += timeStamp;

			    objective = cplex.getObjValue();

			    //LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Qos Constraints: " + Arrays.toString(composition.getConstraints().constraints));
			    wcriSolution = new String("");
			    int ftscy = 0;
			    double wcriUsedBudget = 0;
			    for (int i = 0; i < composition.atomicCompSchemes.size(); i++) {
					double[] varX = cplex.getValues(x[composition.atomicCompSchemes.get(i).getId()]);
					for (int j = 0; j < varX.length; j++) {
						if (Math.abs(varX[j] - 1.0) <= 0.001f) {
							if (j != 0) {
								ftscy++;
//								System.out.println("X[" + composition.atomicCompSchemes.get(i).getId() + "][" + j + "] = 1");
//								System.out.println("Service " + composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j-1).servicdId
//										+ ", qos = " + Arrays.toString(composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j-1).qos)
//										+ ", utility = " + composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j-1).utility);
//
								wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()] = composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j-1);
								wcriSolutionArray[composition.atomicCompSchemes.get(i).getId()] = 1.0;
								wcriSolution = wcriSolution.concat("S" + composition.atomicCompSchemes.get(i).getId() + " ");
//								composition.atomicCompSchemes.get(i).isRedundantArray[1] = true;
								wcriUsedBudget += composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j-1).qos[Config.QOS_INDEX_COST] - 
										composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_COST];
		
								
//								System.out.println("WCRI: Backup Service[" + composition.atomicCompSchemes.get(i).getId() + "][" + j + "]: " + 
//										Arrays.toString(composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j-1).qos)
//										+ ", instance cost is " + composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_COST]
//										+ ", total used budget is " + wcriUsedBudget);								
							} else {
								LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "No Backup Original Service[" + i + "][0]: " + 
										Arrays.toString(composition.atomicCompSchemes.get(i).getServiceInstance().qos));
							}
						}
					}

				}
				//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Backup Solution 2 Qos: " + Arrays.toString(composition.compScheme.getQosValues()));

//				for (int i = 0; i < Config.NUM_SERVICE_CLASSES; i++) {
//					double[] varX = cplex.getValues(x[i]);
//					for (int j = 0; j < varX.length; j++) {
//						System.out.println("WCRI: Variable X[" + i + "][" + j
//								+ "] = " + varX[j]);
//					}
//
//				}
				
				//collectDataWCri();
				
				objective = cplex.getObjValue();
				wcriUtility = objective;
				//System.out.println("WCRI: Objective  = " + objective);
				this.wcriFtCostEffi = wcriUsedBudget / ftBudget;
				this.wcriRedundantPercentage = ftscy / Config.NUM_SERVICE_CLASSES;
//				System.out.println("WCRI: FTSC[y] is " + ftscy + ", Objective  = " + objective 
//						+ ", wcriFtCostEffi is " + wcriFtCostEffi);
			} else {
				/* Reach time limit */
				timeStamp = System.currentTimeMillis() - currTime;
				
				if (IloCplex.Status.Unknown == cplex.getStatus()) {
					LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Cannot get solution in specified time limit, then return");
					return;
				}
				
				
				LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "TimeStamp: Solving without solution consumed time: " + timeStamp + " ms");
				totalTime += timeStamp;
				
				objective = 0;
				
				//writer.writeFile2("Find backup services without criticality end...");
			}
		} catch (UnknownObjectException e) {
			return;
		} catch (IloException e) {
			return;
		}
		currTime = System.currentTimeMillis();
		cplex.end();
		timeStamp = System.currentTimeMillis() - currTime;
		//totalTime += timeStamp;
		
		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "TimeStamp: consumed time: " + totalTime + "ms");
		
		//rst.addRecordOfClassicModel(foundSolution, totalTime, objective);
	}
	public void backupFTCloud(int k) {
		double utility = 0;
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "\r\nFind backup services ftc begin...");
		//originalRt = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];
		
		for (int i=0; i<this.ftcloudSolutionArray.length; i++) {
			this.ftcloudSolutionArray[i] = 0.0;
			this.ftcFtStrategyArray[i] = null;
		}
		
		composition.sortServicesByV();
		//composition.printV();
		
		for (int i=0; i<k; i++) {
			composition.atomicCompSchemes.get(i).setRedundant(true);
			ftcloudSolutionArray[composition.atomicCompSchemes.get(i).getId()] = 1.0;
			composition.atomicCompSchemes.get(i).getSc().sortAggSrcByFailureProbability();
			//composition.atomicCompSchemes.get(i).getSc().printAggregateServices();
			ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()] = composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(0);
		}
		
//		for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
//			if (ftcloudSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 1.0) {
//				//composition.atomicCompSchemes.get(i).setFtStrategy(composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(0));
//				this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()] = composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(0);
//				composition.atomicCompSchemes.get(i).setServiceInstance(composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(0));
//				//composition.atomicCompSchemes.get(i).utility = composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(0).utility;
//				//composition.atomicCompSchemes.get(i).qosValues[Config.QOS_INDEX_COST] = composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(0).qos[Config.QOS_INDEX_COST];
//			}
//			composition.atomicCompSchemes.get(i).utility = composition.atomicCompSchemes.get(i).getServiceInstance().utility;
//		}
//
//		// just for calculating utility
//		composition.compScheme.calculateQos();
//		
//		this.ftcloudUtility = composition.compScheme.utility;
		
		//恢复
		for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
			if (Math.abs(ftcloudSolutionArray[composition.atomicCompSchemes.get(i).getId()] - 1.0) < 0.001f) {
//				composition.atomicCompSchemes.get(i).setServiceInstance(composition.atomicCompSchemes.get(i).getCompServiceInstance());
//				composition.atomicCompSchemes.get(i).utility = composition.atomicCompSchemes.get(i).getServiceInstance().utility;
				composition.atomicCompSchemes.get(i).getSc().sortAggSrcByUtility();
			}
		}
		
		composition.sortCompSchemesById();
		
		//System.out.println("FTCloud array is " + Arrays.toString(ftcloudSolutionArray) + ", utility is " + this.ftcloudUtility);
	}
	public void printAllFtArray() {
		System.out.println("All FT Array: ");
		System.out.println("CRI  Array: " + Arrays.toString(this.criSolutionArray));
		System.out.println("WCRI Array: " + Arrays.toString(this.wcriSolutionArray));
		System.out.println("FTC  Array: " + Arrays.toString(this.ftcloudSolutionArray));
		System.out.println("RAND Array: " + Arrays.toString(this.randomSolutionArray));
	}
	public void backupFTCloudCostConstrainted(double ftBudget) {
		double utility = 0;
		double budget = ftBudget;
		double currentTime = System.currentTimeMillis();
		double timeStamp = 0;
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "\r\nFind backup services ftc begin...");
		//originalRt = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];
		//System.out.println("backupFTCloudCostConstrainted: budget = " + ftBudget);
		for (int i=0; i<this.ftcloudSolutionArray.length; i++) {
			this.ftcloudSolutionArray[i] = 0.0;
			this.ftcFtStrategyArray[i] = null;
		}
		
		composition.sortServicesByV();
		//composition.printV();
		int redNum = 0;
		for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
			composition.atomicCompSchemes.get(i).getSc().sortAggSrcByFailureProbability();
			for (int j=0; j<composition.atomicCompSchemes.get(i).getSc().aggServiceList.size(); j++) {
				double curFtCost = composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j).qos[Config.QOS_INDEX_COST] 
						- composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_COST];

				if (curFtCost <= budget) {
					ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()] = composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(0);
					ftcloudSolutionArray[composition.atomicCompSchemes.get(i).getId()] = 1.0;
					budget = budget - curFtCost;
//					System.out.println("backupFTCloudCostConstrainted: Find compScheme" + composition.atomicCompSchemes.get(i).getId() + " agg service " 
//							+ composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j).servicdId
//							+ ", ftCost is " + curFtCost 
//							+ ", agg service qos is " + Arrays.toString(composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(j).qos)
//							+", service instance cost is " + composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_COST]
//							+ ", left budget is " + budget);
					redNum++;
					break;
				}
			}
			composition.atomicCompSchemes.get(i).getSc().sortAggSrcByUtility();
			//composition.atomicCompSchemes.get(i).getSc().printAggregateServices();

		}
		this.ftcFtCostEffi = (ftBudget - budget) / ftBudget;
		//System.out.println("backupFTCloudCostConstrainted: ftcFtCostEffi is " + ftcFtCostEffi);
//		for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
//			if (ftcloudSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 1.0) {
//				//composition.atomicCompSchemes.get(i).setFtStrategy(composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(0));
//				this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()] = composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(0);
//				composition.atomicCompSchemes.get(i).setServiceInstance(composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(0));
//				//composition.atomicCompSchemes.get(i).utility = composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(0).utility;
//				//composition.atomicCompSchemes.get(i).qosValues[Config.QOS_INDEX_COST] = composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(0).qos[Config.QOS_INDEX_COST];
//			}
//			composition.atomicCompSchemes.get(i).utility = composition.atomicCompSchemes.get(i).getServiceInstance().utility;
//		}
//
//		// just for calculating utility
//		composition.compScheme.calculateQos();
//		
//		this.ftcloudUtility = composition.compScheme.utility;
		
		composition.sortCompSchemesById();
		timeStamp = System.currentTimeMillis() - currentTime;
		
		this.ftcSso = timeStamp;
		
		//System.out.println("FTCloud array is " + Arrays.toString(ftcloudSolutionArray) + ", utility is " + this.ftcloudUtility);
	}
	
	public void collectDataFTCloud() {
    	double oriSrcRt = 0;
    	double oriSrcTp = 0;
    	//double oriSrcRe = 0;
    	//System.out.println("FTCloud solution array is " + Arrays.toString(this.ftcloudSolutionArray));
    	
    	for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
    		if (Math.abs(this.ftcloudSolutionArray[composition.atomicCompSchemes.get(i).getId()] - 1.0) < 0.001f) {
    			composition.atomicCompSchemes.get(i).setServiceInstance(this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()]);
    			composition.atomicCompSchemes.get(i).utility = this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].utility;
    		}
    	}
    	
    	composition.compScheme.calculateQos();
    	
    	boolean isSolutionFailed = isSolutionFailed();
    	//System.out.println("FTCloud isSolutionFailed = " + isSolutionFailed);
    	
    	this.ftcCost = composition.compScheme.qosValues[Config.QOS_INDEX_COST];
    	this.ftcloudUtility = composition.compScheme.utility;
    	this.originalRt = composition.compScheme.qosValues[Config.QOS_INDEX_RESPONSETIME];
    	this.originalTp = composition.compScheme.qosValues[Config.QOS_INDEX_THROUGHPUT];

    	for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
    		oriSrcRt = composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME];
    		oriSrcTp = composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_THROUGHPUT];
    		//oriSrcRe = composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RELIABLITY];
    		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "FTCloud: S" + composition.atomicCompSchemes.get(i).getId() + " OriSrcRt is " + oriSrcRt + 
    				", isFailed is " + composition.atomicCompSchemes.get(i).isFailed);
    		if (isSolutionFailed || composition.atomicCompSchemes.get(i).isFailed == true && this.ftcloudSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 0) {
    			//System.out.println("FTCloud Failed service is " + composition.atomicCompSchemes.get(i).getId());
    			this.ftcAffectedTenant = composition.atomicCompSchemes.get(i).tenantsNum;
    			this.ftCloudSucc = 0;
    			this.failedId = composition.atomicCompSchemes.get(i).getId();
    			composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME] = oriSrcRt * Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY;
    			composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_THROUGHPUT] = oriSrcTp * Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY;
    			//composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RELIABLITY] = oriSrcTp * Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY;
    			
    			composition.compScheme.calculateQos();
    			newFtCloudRT = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];
    			newFtCloudTP = composition.compScheme.getQosValues()[Config.QOS_INDEX_THROUGHPUT];
    			//newCriRE = composition.compScheme.getQosValues()[Config.QOS_INDEX_RELIABLITY];
    			
    			ftCloudRtIncr = newFtCloudRT - this.originalRt;
    			ftCloudTpDecr = this.originalTp - newFtCloudTP;
    			//criReIncr = newCriRE - this.originalRe;
    			
    			ftCloudRtIncrP = ftCloudRtIncr/this.originalRt;
    			ftCloudTpDecrP = ftCloudTpDecr/this.originalTp;
    			//criReIncrP = criReIncr/this.originalRe;
    			
    			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "FTCloud: S" + composition.atomicCompSchemes.get(i).getId() + " 2 OriSrcRt is " + oriSrcRt);
    			composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME] = oriSrcRt;
    			composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_THROUGHPUT] = oriSrcTp;
    			//composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RELIABLITY] = oriSrcRe;
    			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "FTCloud: S" + composition.atomicCompSchemes.get(i).getId() + " RT is " + composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME]);
    		}
    		if (!isSolutionFailed && composition.atomicCompSchemes.get(i).isFailed == true && this.ftcloudSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 1.0) {
    			int failedMemberIdx = 0;
    			Service failedMember = null;
    			double oriStraRt = 0;
    			double oriStraTp = 0;
    			if (this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].getRedundantMode() == Config.REDUNDANT_MODE_PARALLEL) {
        			//随机选择一个strategy的成员service失败 
        			Random rand = new Random();
        			failedMemberIdx = rand.nextInt(this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.size());
        			failedMember = this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(failedMemberIdx);
        			//记录原始的QoS
        			oriStraRt = failedMember.qos[Config.QOS_INDEX_RESPONSETIME];
        			oriStraTp = failedMember.qos[Config.QOS_INDEX_THROUGHPUT];   			
        			//设置response time和throughput为劣化的目标
        			failedMember.qos[Config.QOS_INDEX_RESPONSETIME] = oriStraRt * Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY;
        			failedMember.qos[Config.QOS_INDEX_THROUGHPUT] = oriStraTp * Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY;
        			//重新计算QoS
        			this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].calTmpRtAndTp();;
        				
    			} else {
    				if (this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(0).qos[Config.QOS_INDEX_RESPONSETIME] * Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY 
        				    > this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(1).qos[Config.QOS_INDEX_RESPONSETIME]
        					|| this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(0).qos[Config.QOS_INDEX_THROUGHPUT] * Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY 
        					< this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(1).qos[Config.QOS_INDEX_THROUGHPUT]) {
    					this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].changeToNextInSeq(1);
        				}
    				
    			}
   			
    			//重新计算composition的QoS
    			composition.compScheme.calculateQos();
    			
    			newFtCloudRT = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];
    			newFtCloudTP = composition.compScheme.getQosValues()[Config.QOS_INDEX_THROUGHPUT];
    			//newCriRE = composition.compScheme.getQosValues()[Config.QOS_INDEX_RELIABLITY];
    			
    			ftCloudRtIncr = newFtCloudRT - this.originalRt;
    			ftCloudTpDecr = this.originalTp - newFtCloudTP;
    			//criReIncr = newCriRE - this.originalRe;
    			
    			ftCloudRtIncrP = ftCloudRtIncr/this.originalRt;
    			ftCloudTpDecrP = ftCloudTpDecr/this.originalTp;

    			if (this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].getRedundantMode() == Config.REDUNDANT_MODE_PARALLEL) {
        			//恢复strategy的QoS
        			
        			failedMember.qos[Config.QOS_INDEX_RESPONSETIME] = oriStraRt;
        			failedMember.qos[Config.QOS_INDEX_THROUGHPUT] = oriStraTp;
        			//重新计算QoS
        			this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].calTmpRtAndTp();;
   				
    			} else {
    				this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].changeToNextInSeq(0);
    			}
    			
    			composition.compScheme.calculateQos();
    			
    			this.ftcAffectedTenant = 0;
    			this.ftCloudSucc = 1;
    			this.failedId = composition.atomicCompSchemes.get(i).getId();
     			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "FTCloud " + composition.atomicCompSchemes.get(i).getId() + "th Service " + "has backup OK ");
    		}
    		
    	}
    	ftCloudSuccTotal += this.ftCloudSucc;
    	
    	for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
    		if (Math.abs(this.ftcloudSolutionArray[composition.atomicCompSchemes.get(i).getId()] - 1.0) < 0.001f) {
    			composition.atomicCompSchemes.get(i).setServiceInstance(composition.atomicCompSchemes.get(i).getCompServiceInstance());
    			composition.atomicCompSchemes.get(i).utility = composition.atomicCompSchemes.get(i).getCompServiceInstance().utility;
    		}
    	}
    	
    	composition.compScheme.calculateQos();
	}
	public void bakcupRandom(int k) {
		Random rand = new Random();
		double utility = 0;
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "\r\nFind backup services randomly begin...");
		//originalRt = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];
		
		for (int i=0; i<this.randomSolutionArray.length; i++) {
			this.randomSolutionArray[i] = 0.0;
			this.randomFtStrategyArray[i] = null;
		}
		
		int[] backupIdxArray = new int[Config.NUM_SERVICE_CLASSES];
		randomSolution = new String();
		for (int i=0; i<k; i++) {
			int idx = rand.nextInt(composition.atomicCompSchemes.size());
			while (randomSolutionArray[idx] == 1.0) {
				idx = rand.nextInt(composition.atomicCompSchemes.size());
			}
			composition.atomicCompSchemes.get(idx).setRedundant(true);
			randomSolution = randomSolution.concat("S" + composition.atomicCompSchemes.get(idx).getId() + " ");
			randomSolutionArray[composition.atomicCompSchemes.get(idx).getId()] = 1.0;
			//composition.atomicCompSchemes.get(idx).isRedundantArray[2] = true;
			int backupIdx = rand.nextInt(composition.atomicCompSchemes.get(idx).getSc().aggServiceNum);
			//composition.atomicCompSchemes.get(idx).setServiceInstance(composition.atomicCompSchemes.get(idx).getSc().aggServiceList.get(backupIdx));
			//composition.atomicCompSchemes.get(idx).setRedundant(true);
			backupIdxArray[i] = backupIdx;
			this.randomFtStrategyArray[composition.atomicCompSchemes.get(idx).getId()] = composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(backupIdxArray[i]);
			//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "The " + i + "th round find redundant aggregate service " + backupIdx + " for S" + idx);
			//writer.writeFile2("Find backup service for S" + composition.atomicCompSchemes.get(idx).getId());
		}
		
//		for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
//			if (randomSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 1.0) {
//				composition.atomicCompSchemes.get(i).setServiceInstance(randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()]);
//				//composition.atomicCompSchemes.get(i).utility = composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(backupIdxArray[i]).utility;
//				//composition.atomicCompSchemes.get(i).qosValues[Config.QOS_INDEX_COST] = composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(backupIdxArray[i]).qos[Config.QOS_INDEX_COST];
//				//utility += composition.atomicCompSchemes.get(i).getSc().aggServiceList.get(backupIdxArray[i]).qos[Config.QOS_INDEX_COST];
//			} 
//			composition.atomicCompSchemes.get(i).utility = composition.atomicCompSchemes.get(i).getServiceInstance().utility;
//		}
//		//this.randomUtility = utility;
//		
//		composition.compScheme.calculateQos();
//		
//		this.randomUtility = composition.compScheme.utility;
		
		for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
			if ((composition.atomicCompSchemes.get(i).isFailed == true) && (composition.atomicCompSchemes.get(i).isRedundant == false)) {
				//randomRt = (double)(composition.executionPaths.size() - composition.atomicCompSchemes.get(i).rank[Config.QOS_INDEX_RESPONSETIME] + 1) / composition.executionPaths.size();
				//randomRt = (double)composition.atomicCompSchemes.get(i).getTenantsNum() / Config.NUM_TENANTS;
				randomRt = composition.atomicCompSchemes.get(i).criticality[Config.QOS_INDEX_RESPONSETIME];
			}
		}
		
//		for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
//			if (randomSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 1.0) {
//				composition.atomicCompSchemes.get(i).setServiceInstance(composition.atomicCompSchemes.get(i).getCompServiceInstance());
//				composition.atomicCompSchemes.get(i).utility = composition.atomicCompSchemes.get(i).getServiceInstance().utility;
//			}
//		}
		
		//collectDataRandom();
		
		//randomRt = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Backup Solution Random Qos: " + Arrays.toString(composition.compScheme.getQosValues()));
		//writer.writeFile2("Qos of Solution randomly: " + Arrays.toString(composition.compScheme.getQosValues()));
		//writer.writeFile2("Find backup services randomly end...");
	}
	
	public void bakcupRandomCostConstrainted(double ftBudget) {
		Random rand = new Random();
		double budget = ftBudget;
		double currentTime = System.currentTimeMillis();
		double timeStamp = 0;
		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "\r\nFind backup services randomly begin...");
		//originalRt = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];
		//System.out.println("bakcupRandomCostConstrainted: budget = " + ftBudget);

		for (int i=0; i<this.randomSolutionArray.length; i++) {
			this.randomSolutionArray[i] = 0.0;
			this.randomFtStrategyArray[i] = null;
		}
		
		ArrayList<Integer> scList = new ArrayList<Integer>();
		for (int i = 0; i<composition.atomicCompSchemes.size(); i++) {
			scList.add(i);
		}
		
		randomSolution = new String();
		int redNum = 0;
		while (scList.size() > 0) {
			int scListIdx = rand.nextInt(scList.size());
			int idx = scList.get(scListIdx).intValue();
			ArrayList<Integer> aggList = new ArrayList<Integer>();
			for (int i = 0; i<composition.atomicCompSchemes.get(idx).getSc().aggServiceList.size(); i++) {
				aggList.add(i);
			}
			boolean isEnd = false;
			while (aggList.size() > 0 && !isEnd) {
				int aggListIdx = rand.nextInt(aggList.size());
				int backupIdx = aggList.get(aggListIdx).intValue();
				double curFtCost = composition.atomicCompSchemes.get(idx).getSc().aggServiceList.get(backupIdx).qos[Config.QOS_INDEX_COST] 
						- composition.atomicCompSchemes.get(idx).getServiceInstance().qos[Config.QOS_INDEX_COST];
				if (curFtCost <= budget) {
					randomSolution = randomSolution.concat("S" + composition.atomicCompSchemes.get(idx).getId() + " ");
					randomSolutionArray[composition.atomicCompSchemes.get(idx).getId()] = 1.0;
					this.randomFtStrategyArray[composition.atomicCompSchemes.get(idx).getId()] = composition.atomicCompSchemes.get(idx).getSc().aggServiceList.get(backupIdx);					
					budget = budget - curFtCost;
//					System.out.println("bakcupRandomCostConstrainted: Find compScheme" + composition.atomicCompSchemes.get(idx).getId() + " agg service " 
//							+ composition.atomicCompSchemes.get(idx).getSc().aggServiceList.get(backupIdx).servicdId
//							+ ", ftCost is " + curFtCost 
//							+ ", agg service qos is " + Arrays.toString(composition.atomicCompSchemes.get(idx).getSc().aggServiceList.get(backupIdx).qos)
//							+", service instance cost is " + composition.atomicCompSchemes.get(idx).getServiceInstance().qos[Config.QOS_INDEX_COST]
//							+ ", left budget is " + budget);
					isEnd = true;
					redNum++;
				}
				aggList.remove(aggListIdx);
				if (isEnd) {
					break;
				}
			}
			
			scList.remove(scListIdx);
		}
		
		this.randomFtCostEffi = (ftBudget - budget) / ftBudget;
		this.randomRedundantPercentage = redNum / Config.NUM_SERVICE_CLASSES;
		timeStamp = System.currentTimeMillis() - currentTime;
		this.randomSso = timeStamp;
		
		//System.out.println("bakcupRandomCostConstrainted: randomFtCostEffi is " + randomFtCostEffi);
	}
	public boolean isHaveSolution() {
		return isHaveSolution;
	}
	public void setHaveSolution(boolean isHaveSolution) {
		this.isHaveSolution = isHaveSolution;
	}
	public double getOriginalRt() {
		return originalRt;
	}
	public void setOriginalRt(double originalRt) {
		this.originalRt = originalRt;
	}
	public double getCriRt() {
		return criRt;
	}
	public void setCriRt(double criRt) {
		this.criRt = criRt;
	}
	public double getWcriRt() {
		return wcriRt;
	}
	public void setWcriRt(double wcriRt) {
		this.wcriRt = wcriRt;
	}
	public double getRandomRt() {
		return randomRt;
	}
	public void setRandomRt(double randomRt) {
		this.randomRt = randomRt;
	}
	public int getCriSucc() {
		return criSucc;
	}
	public void setCriSucc(int criSucc) {
		this.criSucc = criSucc;
	}
	public int getWcriSucc() {
		return wcriSucc;
	}
	public void setWcriSucc(int wcriSucc) {
		this.wcriSucc = wcriSucc;
	}
	public int getRandomSucc() {
		return randomSucc;
	}
	public void setRandomSucc(int randomSucc) {
		this.randomSucc = randomSucc;
	}

	public int getNewTP() {
		return newTP;
	}
	public void setNewTP(int newTP) {
		this.newTP = newTP;
	}
	public String getCriSolution() {
		return criSolution;
	}
	public void setCriSolution(String criSolution) {
		this.criSolution = criSolution;
	}
	public String getWcriSolution() {
		return wcriSolution;
	}
	public void setWcriSolution(String wcriSolution) {
		this.wcriSolution = wcriSolution;
	}
	public String getRandomSolution() {
		return randomSolution;
	}
	public void setRandomSolution(String randomSolution) {
		this.randomSolution = randomSolution;
	}
	public double getCriRtIncr() {
		return criRtIncr;
	}
	public void setCriRtIncr(double criRtIncr) {
		this.criRtIncr = criRtIncr;
	}
	public double getWcriRtIncr() {
		return wcriRtIncr;
	}
	public void setWcriRtIncr(double wcriRtIncr) {
		this.wcriRtIncr = wcriRtIncr;
	}
	public double getRandomRtIncr() {
		return randomRtIncr;
	}
	public void setRandomRtIncr(double randomRtIncr) {
		this.randomRtIncr = randomRtIncr;
	}
	public double getCriRtIncrP() {
		return criRtIncrP;
	}
	public void setCriRtIncrP(double criRtIncrP) {
		this.criRtIncrP = criRtIncrP;
	}
	public double getWcriRtIncrP() {
		return wcriRtIncrP;
	}
	public void setWcriRtIncrP(double wcriRtIncrP) {
		this.wcriRtIncrP = wcriRtIncrP;
	}
	public double getRandomRtIncrP() {
		return randomRtIncrP;
	}
	public void setRandomRtIncrP(double randomRtIncrP) {
		this.randomRtIncrP = randomRtIncrP;
	}
	public double getNewCriRT() {
		return newCriRT;
	}
	public void setNewCriRT(double newCriRT) {
		this.newCriRT = newCriRT;
	}
	public double getNewWcriRT() {
		return newWcriRT;
	}
	public void setNewWcriRT(double newWcriRT) {
		this.newWcriRT = newWcriRT;
	}
	public double getNewRandomRT() {
		return newRandomRT;
	}
	public void setNewRandomRT(double newRandomRT) {
		this.newRandomRT = newRandomRT;
	}
	public double getCriUtility() {
		return criUtility;
	}
	public void setCriUtility(double criUtility) {
		this.criUtility = criUtility;
	}
	public double getWcriUtility() {
		return wcriUtility;
	}
	public void setWcriUtility(double wcriUtility) {
		this.wcriUtility = wcriUtility;
	}
	public double getRandomUtility() {
		return randomUtility;
	}
	public void setRandomUtility(double randomUtility) {
		this.randomUtility = randomUtility;
	}
	
    public int getFailedId() {
		return failedId;
	}
	public void setFailedId(int failedId) {
		this.failedId = failedId;
	}
	
	public double getDelay() {
		return delay;
	}
	public void setDelay(double delay) {
		this.delay = delay;
	}
	
	public ServiceComposition getComposition() {
		return composition;
	}
	public void setComposition(ServiceComposition composition) {
		this.composition = composition;
	}
//
	public double getOriginalTp() {
		return originalTp;
	}
	public void setOriginalTp(double originalTp) {
		this.originalTp = originalTp;
	}
	public double getOriginalRe() {
		return originalRe;
	}
	public void setOriginalRe(double originalRe) {
		this.originalRe = originalRe;
	}
	public double getNewCriRE() {
		return newCriRE;
	}
	public void setNewCriRE(double newCriRE) {
		this.newCriRE = newCriRE;
	}
	public double getNewWcriRE() {
		return newWcriRE;
	}
	public void setNewWcriRE(double newWcriRE) {
		this.newWcriRE = newWcriRE;
	}
	public double getNewRandomRE() {
		return newRandomRE;
	}
	public void setNewRandomRE(double newRandomRE) {
		this.newRandomRE = newRandomRE;
	}
	public double getNewCriTP() {
		return newCriTP;
	}
	public void setNewCriTP(double newCriTP) {
		this.newCriTP = newCriTP;
	}
	public double getNewWcriTP() {
		return newWcriTP;
	}
	public void setNewWcriTP(double newWcriTP) {
		this.newWcriTP = newWcriTP;
	}
	public double getNewRandomTP() {
		return newRandomTP;
	}
	public void setNewRandomTP(double newRandomTP) {
		this.newRandomTP = newRandomTP;
	}
	public double getCriTpDecr() {
		return criTpDecr;
	}
	public void setCriTpDecr(double criTpDecr) {
		this.criTpDecr = criTpDecr;
	}
	public double getWcriTpDecr() {
		return wcriTpDecr;
	}
	public void setWcriTpDecr(double wcriTpDecr) {
		this.wcriTpDecr = wcriTpDecr;
	}
	public double getRandomTpDecr() {
		return randomTpDecr;
	}
	public void setRandomTpDecr(double randomTpDecr) {
		this.randomTpDecr = randomTpDecr;
	}
	public double getCriTpDecrP() {
		return criTpDecrP;
	}
	public void setCriTpDecrP(double criTpDecrP) {
		this.criTpDecrP = criTpDecrP;
	}
	public double getWcriTpDecrP() {
		return wcriTpDecrP;
	}
	public void setWcriTpDecrP(double wcriTpDecrP) {
		this.wcriTpDecrP = wcriTpDecrP;
	}
	public double getRandomTpDecrP() {
		return randomTpDecrP;
	}
	public void setRandomTpDecrP(double randomTpDecrP) {
		this.randomTpDecrP = randomTpDecrP;
	}
	public double getCriReIncr() {
		return criReIncr;
	}
	public void setCriReIncr(double criReIncr) {
		this.criReIncr = criReIncr;
	}
	public double getWcriReIncr() {
		return wcriReIncr;
	}
	public void setWcriReIncr(double wcriReIncr) {
		this.wcriReIncr = wcriReIncr;
	}
	public double getRandomReIncr() {
		return randomReIncr;
	}
	public void setRandomReIncr(double randomReIncr) {
		this.randomReIncr = randomReIncr;
	}
	public double getCriReIncrP() {
		return criReIncrP;
	}
	public void setCriReIncrP(double criReIncrP) {
		this.criReIncrP = criReIncrP;
	}
	public double getWcriReIncrP() {
		return wcriReIncrP;
	}
	public void setWcriReIncrP(double wcriReIncrP) {
		this.wcriReIncrP = wcriReIncrP;
	}
	public double getRandomReIncrP() {
		return randomReIncrP;
	}
	public void setRandomReIncrP(double randomReIncrP) {
		this.randomReIncrP = randomReIncrP;
	}
	public double[] getCriSolutionArray() {
		return criSolutionArray;
	}
	public void setCriSolutionArray(double[] criSolutionArray) {
		this.criSolutionArray = criSolutionArray;
	}
	public double[] getWcriSolutionArray() {
		return wcriSolutionArray;
	}
	public void setWcriSolutionArray(double[] wcriSolutionArray) {
		this.wcriSolutionArray = wcriSolutionArray;
	}
	public double[] getRandomSolutionArray() {
		return randomSolutionArray;
	}
	public void setRandomSolutionArray(double[] randomSolutionArray) {
		this.randomSolutionArray = randomSolutionArray;
	}
	public void collectDataCri() {
    	double oriSrcRt = 0;
    	double oriSrcTp = 0;
    	//double oriSrcRe = 0;
    	//System.out.println("CRI solution array is " + Arrays.toString(this.criSolutionArray));
    	for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
    		if (Math.abs(this.criSolutionArray[composition.atomicCompSchemes.get(i).getId()]-1.0) < 0.001f) {
    			composition.atomicCompSchemes.get(i).setServiceInstance(this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()]);
    			composition.atomicCompSchemes.get(i).utility = this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].utility;
    		}
    	}
    	
    	composition.compScheme.calculateQos();
    	
    	this.criCost = composition.compScheme.qosValues[Config.QOS_INDEX_COST];
    	this.originalRt = composition.compScheme.qosValues[Config.QOS_INDEX_RESPONSETIME];
    	this.originalTp = composition.compScheme.qosValues[Config.QOS_INDEX_THROUGHPUT];
    	
    	for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
    		oriSrcRt = composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME];
    		oriSrcTp = composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_THROUGHPUT];
    		//oriSrcRe = composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RELIABLITY];
    		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "CRI: S" + composition.atomicCompSchemes.get(i).getId() + " OriSrcRt is " + oriSrcRt + 
    				", isFailed is " + composition.atomicCompSchemes.get(i).isFailed);
    		if (composition.atomicCompSchemes.get(i).isFailed == true 
    				&& Math.abs(this.criSolutionArray[composition.atomicCompSchemes.get(i).getId()] - 0.0) < 0.001f) {
    			//System.out.println("CRI Failed service is " + composition.atomicCompSchemes.get(i).getId());
    			this.criAffectedTenant = composition.atomicCompSchemes.get(i).tenantsNum;
    			this.criSucc = 0;
    			this.failedId = composition.atomicCompSchemes.get(i).getId();
    			composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME] = oriSrcRt * Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY;
    			composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_THROUGHPUT] = oriSrcTp * Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY;
    			//composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RELIABLITY] = oriSrcTp * Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY;
    			
    			composition.compScheme.calculateQos();
    			newCriRT = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];
    			newCriTP = composition.compScheme.getQosValues()[Config.QOS_INDEX_THROUGHPUT];
    			//newCriRE = composition.compScheme.getQosValues()[Config.QOS_INDEX_RELIABLITY];
    			
    			criRtIncr = newCriRT - this.originalRt;
    			criTpDecr = this.originalTp - newCriTP;
    			//criReIncr = newCriRE - this.originalRe;
    			
    			criRtIncrP = criRtIncr/this.originalRt;
    			criTpDecrP = criTpDecr/this.originalTp;
    			//criReIncrP = criReIncr/this.originalRe;
    			
    			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "CRI: S" + composition.atomicCompSchemes.get(i).getId() + " 2 OriSrcRt is " + oriSrcRt);
    			composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME] = oriSrcRt;
    			composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_THROUGHPUT] = oriSrcTp;
    			//composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RELIABLITY] = oriSrcRe;
    			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "CRI: S" + composition.atomicCompSchemes.get(i).getId() + " RT is " + composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME]);
    		}
    		if (composition.atomicCompSchemes.get(i).isFailed == true 
    				&& Math.abs(this.criSolutionArray[composition.atomicCompSchemes.get(i).getId()] - 1.0) < 0.001f) {
    			int failedMemberIdx = 0;
    			Service failedMember = null;
    			double oriStraRt = 0;
    			double oriStraTp = 0;
    			//随机选择一个strategy的成员service失败 
    			if (this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].getRedundantMode() == Config.REDUNDANT_MODE_PARALLEL) {
        			Random rand = new Random();
        			failedMemberIdx = rand.nextInt(this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.size());			
        			failedMember = this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(failedMemberIdx);
        			//è®°å½•åŽŸå§‹çš„QoS
        			oriStraRt = failedMember.qos[Config.QOS_INDEX_RESPONSETIME];
        			oriStraTp = failedMember.qos[Config.QOS_INDEX_THROUGHPUT];   			
        			//设置response time和throughput为劣化的目标
        			failedMember.qos[Config.QOS_INDEX_RESPONSETIME] = oriStraRt * Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY;
        			failedMember.qos[Config.QOS_INDEX_THROUGHPUT] = oriStraTp * Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY;
        			//é‡�æ–°è®¡ç®—QoS
        			this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].calTmpRtAndTp();;
    			} else {
    				if (this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(0).qos[Config.QOS_INDEX_RESPONSETIME] * Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY 
    				    > this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(1).qos[Config.QOS_INDEX_RESPONSETIME]
    					|| this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(0).qos[Config.QOS_INDEX_THROUGHPUT] * Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY 
    					< this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(1).qos[Config.QOS_INDEX_THROUGHPUT]) {
    					this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].changeToNextInSeq(1);
    				}
    				
    			}
    			
    			
    			//重新计算composition的QoS
    			composition.compScheme.calculateQos();
    			
    			newCriRT = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];
    			newCriTP = composition.compScheme.getQosValues()[Config.QOS_INDEX_THROUGHPUT];
    			//newCriRE = composition.compScheme.getQosValues()[Config.QOS_INDEX_RELIABLITY];
    			
    			criRtIncr = newCriRT - this.originalRt;
    			criTpDecr = this.originalTp - newCriTP;
    			//criReIncr = newCriRE - this.originalRe;
    			
    			criRtIncrP = criRtIncr/this.originalRt;
    			criTpDecrP = criTpDecr/this.originalTp;

    			//æ�¢å¤�strategyçš„QoS
    			
    			if (this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].getRedundantMode() == Config.REDUNDANT_MODE_PARALLEL) {
        			failedMember.qos[Config.QOS_INDEX_RESPONSETIME] = oriStraRt;
        			failedMember.qos[Config.QOS_INDEX_THROUGHPUT] = oriStraTp;
        			//重新计算QoS
        			this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].calTmpRtAndTp(); 				
    			} else {
    				this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].changeToNextInSeq(0);
    			}
    				
    			//composition.compScheme.calculateQos();
    			
    			this.criAffectedTenant = 0;
    			this.criSucc = 1;
    			this.failedId = composition.atomicCompSchemes.get(i).getId();
     			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, composition.atomicCompSchemes.get(i).getId() + "th Service " + "has backup OK ");
    		}
    		criSuccTotal += this.criSucc;
    	}
    	
//    	for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
//    		if (Math.abs(this.criSolutionArray[composition.atomicCompSchemes.get(i).getId()] - 1.0) < 0.001f) {
//    			composition.atomicCompSchemes.get(i).setServiceInstance(composition.atomicCompSchemes.get(i).getCompServiceInstance());
//    			composition.atomicCompSchemes.get(i).utility = composition.atomicCompSchemes.get(i).getCompServiceInstance().utility;
//    		}
//    	}
    	
    	composition.compScheme.calculateQos();
    }

	public void collectDataCriMultiFailure() {
		double[] oriSrcRt = new double[composition.atomicCompSchemes.size()];
		
		for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
    		if (Math.abs(this.criSolutionArray[composition.atomicCompSchemes.get(i).getId()]-1.0) < 0.001f) {
    			composition.atomicCompSchemes.get(i).setServiceInstance(this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()]);
    			composition.atomicCompSchemes.get(i).utility = this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].utility;
    		}
    	}
    	//double oriSrcRe = 0;
		composition.compScheme.calculateQos();
    	this.originalRt = composition.compScheme.qosValues[Config.QOS_INDEX_RESPONSETIME];
		
    	for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
    		oriSrcRt[i] = composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME];

    		//oriSrcRe = composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RELIABLITY];
    		if (composition.atomicCompSchemes.get(i).isFailed == true && this.criSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 0) {
     			composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME] = oriSrcRt[i] * Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY;
    		} 

    		if (composition.atomicCompSchemes.get(i).isFailed == true && this.criSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 1.0) {
    			int failedMemberIdx = 0;
    			Service failedMember = null;
    			double oriStraRt = 0;
    			double oriStraTp = 0;
    			//随机选择一个strategy的成员service失败 
    			if (this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].getRedundantMode() == Config.REDUNDANT_MODE_PARALLEL) {
        			Random rand = new Random();
        			failedMemberIdx = rand.nextInt(this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.size());			
        			failedMember = this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(failedMemberIdx);
        			//记录原始的QoS
        			oriStraRt = failedMember.qos[Config.QOS_INDEX_RESPONSETIME];
 			
        			//设置response time和throughput为劣化的目标
        			failedMember.qos[Config.QOS_INDEX_RESPONSETIME] = oriStraRt * Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY;
        			//重新计算QoS
        			this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].calTmpRtAndTp();;
    			} else {
    				this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].changeToNextInSeq(1);
    			}
    			
    		}
    		
			
    	}
    	
		composition.compScheme.calculateQos();
		newCriRT = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];
		
		criRtIncr = newCriRT - this.originalRt;
		
		criRtIncrP = criRtIncr/this.originalRt;
		
   	
    	for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
    		if (composition.atomicCompSchemes.get(i).isFailed == true && this.criSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 0) {
    			composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME] = oriSrcRt[i];
    		}
    	}
    	
    	for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
    		if (Math.abs(this.criSolutionArray[composition.atomicCompSchemes.get(i).getId()] - 1.0) < 0.001f) {
    			composition.atomicCompSchemes.get(i).setServiceInstance(composition.atomicCompSchemes.get(i).getCompServiceInstance());
    			composition.atomicCompSchemes.get(i).utility = composition.atomicCompSchemes.get(i).getCompServiceInstance().utility;
    			if (this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].getRedundantMode() == Config.REDUNDANT_MODE_PARALLEL) {
        			for (int m=0; m<this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.size(); m++) {
        				this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(m).qos[Config.QOS_INDEX_RESPONSETIME] = 
        						this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(m).originalRt;	
        			}
        			//重新计算QoS
        			this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].calTmpRtAndTp(); 				
    			} else {
    				this.criFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].changeToNextInSeq(0);
    			}
    		}
    		
    	}
    	composition.compScheme.calculateQos();
    }

	
    public void collectDataWCri() {
       	double oriSrcRt = 0;
    	double oriSrcTp = 0;
    	//double oriSrcRe = 0;
    	//System.out.println("WCRI solution array is " + Arrays.toString(this.wcriSolutionArray));
    	
    	for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
    		if (Math.abs(this.wcriSolutionArray[composition.atomicCompSchemes.get(i).getId()] - 1.0) < 0.001f) {
    			composition.atomicCompSchemes.get(i).setServiceInstance(this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()]);
    			composition.atomicCompSchemes.get(i).utility = this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].utility;
    		}
    	}
    	
    	composition.compScheme.calculateQos();
    	
    	this.wcriCost = composition.compScheme.qosValues[Config.QOS_INDEX_COST];
    	this.originalRt = composition.compScheme.qosValues[Config.QOS_INDEX_RESPONSETIME];
    	this.originalTp = composition.compScheme.qosValues[Config.QOS_INDEX_THROUGHPUT];

    	for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
    		oriSrcRt = composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME];
    		oriSrcTp = composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_THROUGHPUT];
    		//oriSrcRe = composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RELIABLITY];
    		
    		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "BEGIN: WCRI S" + composition.atomicCompSchemes.get(i).getId() + " RT is " + composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME]);

    		if (composition.atomicCompSchemes.get(i).isFailed == true && this.wcriSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 0) {
    			//System.out.println("WCRI Failed service is " + composition.atomicCompSchemes.get(i).getId());
    			this.wcriAffectedTenant = composition.atomicCompSchemes.get(i).tenantsNum;
    			this.wcriSucc = 0;
    			this.failedId = composition.atomicCompSchemes.get(i).getId();
    			composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME] = oriSrcRt * Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY;
    			composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_THROUGHPUT] = oriSrcTp * Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY;
    			//composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RELIABLITY] = oriSrcTp * Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY;
    			
    			composition.compScheme.calculateQos();
    			newWcriRT = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];
    			newWcriTP = composition.compScheme.getQosValues()[Config.QOS_INDEX_THROUGHPUT];
    			//newWcriRE = composition.compScheme.getQosValues()[Config.QOS_INDEX_RELIABLITY];

    			wcriRtIncr = newWcriRT - this.originalRt;
    			wcriTpDecr = this.originalTp - newWcriTP;
    			//wcriReIncr = newWcriRE - this.originalRe;

    			wcriRtIncrP = wcriRtIncr/this.originalRt;
    			wcriTpDecrP = wcriTpDecr/this.originalTp;
    			//wcriReIncrP = wcriReIncr/this.originalRe;
 
    			composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME] = oriSrcRt;
    			composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_THROUGHPUT] = oriSrcTp;
    			//composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RELIABLITY] = oriSrcRe;
    		}
    		if (composition.atomicCompSchemes.get(i).isFailed == true && this.wcriSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 1.0) {
    			int failedMemberIdx = 0;
    			Service failedMember = null;
    			double oriStraRt = 0;
    			double oriStraTp = 0;   			

    			if (this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].getRedundantMode() == Config.REDUNDANT_MODE_PARALLEL) {
        			//随机选择一个strategy的成员service失败 
        			Random rand = new Random();
        			failedMemberIdx = rand.nextInt(this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.size());
        			failedMember = this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(failedMemberIdx);
        			//记录原始的QoS
        			oriStraRt = failedMember.qos[Config.QOS_INDEX_RESPONSETIME];
        			oriStraTp = failedMember.qos[Config.QOS_INDEX_THROUGHPUT];   			
        			//设置response time和throughput为劣化的目标
        			failedMember.qos[Config.QOS_INDEX_RESPONSETIME] = oriStraRt * Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY;
        			failedMember.qos[Config.QOS_INDEX_THROUGHPUT] = oriStraTp * Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY;
        			//重新计算QoS
        			this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].calTmpRtAndTp();;

    			} else {
    				if (this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(0).qos[Config.QOS_INDEX_RESPONSETIME] * Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY 
        				    > this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(1).qos[Config.QOS_INDEX_RESPONSETIME]
        					|| this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(0).qos[Config.QOS_INDEX_THROUGHPUT] * Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY 
        					< this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(1).qos[Config.QOS_INDEX_THROUGHPUT]) {
    					this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].changeToNextInSeq(1);
        				}
    			}
    			
    			//重新计算composition的QoS
    			composition.compScheme.calculateQos();
    			
    			newWcriRT = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];
    			newWcriTP = composition.compScheme.getQosValues()[Config.QOS_INDEX_THROUGHPUT];
    			//newCriRE = composition.compScheme.getQosValues()[Config.QOS_INDEX_RELIABLITY];
    			
    			wcriRtIncr = newWcriRT - this.originalRt;
    			wcriTpDecr = this.originalTp - newWcriTP;
    			//criReIncr = newCriRE - this.originalRe;
    			
    			wcriRtIncrP = wcriRtIncr/this.originalRt;
    			wcriTpDecrP = wcriTpDecr/this.originalTp;

    			//恢复strategy的QoS
    			if (this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].getRedundantMode() == Config.REDUNDANT_MODE_PARALLEL) {
        			failedMember.qos[Config.QOS_INDEX_RESPONSETIME] = oriStraRt;
        			failedMember.qos[Config.QOS_INDEX_THROUGHPUT] = oriStraTp;
        			//重新计算QoS
        			this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].calTmpRtAndTp();;
   				
    			} else {
    				this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].changeToNextInSeq(0);
    			}
    			composition.compScheme.calculateQos();
    			
    			this.wcriAffectedTenant = 0;
    			this.wcriSucc = 1;
    			this.failedId = composition.atomicCompSchemes.get(i).getId();

    			
    			//composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RELIABLITY] = 1.0;
    			//composition.compScheme.calculateQos();
    			//newWcriRE = composition.compScheme.getQosValues()[Config.QOS_INDEX_RELIABLITY];
    			////newWcriRE = this.originalRe;
    			
    			//wcriReIncr = newWcriRE - this.originalRe;
    			//wcriReIncr = 0;
    			
    			//wcriReIncrP = wcriReIncr/this.originalRe;
    			//wcriReIncrP = 0;
    			
    			//composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RELIABLITY] = oriSrcRe;

    		}
    		
    		wcriSuccTotal += this.wcriSucc;
    		
			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "END: WCRI S" + composition.atomicCompSchemes.get(i).getId() + " RT is " + composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME]);

    	}
    	
    	for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
    		if (Math.abs(this.wcriSolutionArray[composition.atomicCompSchemes.get(i).getId()] - 1.0) < 0.001f) {
    			composition.atomicCompSchemes.get(i).setServiceInstance(composition.atomicCompSchemes.get(i).getCompServiceInstance());
    			composition.atomicCompSchemes.get(i).utility = composition.atomicCompSchemes.get(i).getCompServiceInstance().utility;
    		}
    	}
    	
    	composition.compScheme.calculateQos();
    }
    
    public void collectDataWCriMultiFailure() {
       	double[] oriSrcRt = new double[composition.atomicCompSchemes.size()];
       	
    	for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
    		if (Math.abs(this.wcriSolutionArray[composition.atomicCompSchemes.get(i).getId()] - 1.0) < 0.001f) {
    			composition.atomicCompSchemes.get(i).setServiceInstance(this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()]);
    			composition.atomicCompSchemes.get(i).utility = this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].utility;
    		}
    	}
    	
    	composition.compScheme.calculateQos();
    	
    	this.originalRt = composition.compScheme.qosValues[Config.QOS_INDEX_RESPONSETIME];

    	for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
    		oriSrcRt[i] = composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME];

    		if (composition.atomicCompSchemes.get(i).isFailed == true && this.wcriSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 0) {
    			this.wcriSucc = 0;
    			this.failedId = composition.atomicCompSchemes.get(i).getId();
    			composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME] = oriSrcRt[i] * Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY;
    			
     		}
    		
       		if (composition.atomicCompSchemes.get(i).isFailed == true && this.wcriSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 1.0) {
    			int failedMemberIdx = 0;
    			Service failedMember = null;
    			double oriStraRt = 0;
    			double oriStraTp = 0;   			

    			if (this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].getRedundantMode() == Config.REDUNDANT_MODE_PARALLEL) {
        			//随机选择一个strategy的成员service失败 
        			Random rand = new Random();
        			failedMemberIdx = rand.nextInt(this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.size());
        			failedMember = this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(failedMemberIdx);
        			//记录原始的QoS
        			oriStraRt = failedMember.qos[Config.QOS_INDEX_RESPONSETIME];
        			oriStraTp = failedMember.qos[Config.QOS_INDEX_THROUGHPUT];   			
        			//设置response time和throughput为劣化的目标
        			failedMember.qos[Config.QOS_INDEX_RESPONSETIME] = oriStraRt * Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY;
        			failedMember.qos[Config.QOS_INDEX_THROUGHPUT] = oriStraTp * Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY;
        			//重新计算QoS
        			this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].calTmpRtAndTp();;

    			} else {
    				this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].changeToNextInSeq(1);
    			}
    			
       		}
    	}
    	
		composition.compScheme.calculateQos();
		newWcriRT = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];

		wcriRtIncr = newWcriRT - this.originalRt;

		wcriRtIncrP = wcriRtIncr/this.originalRt;

		for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
			if (composition.atomicCompSchemes.get(i).isFailed == true && this.wcriSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 0) {
				composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME] = oriSrcRt[i];
			}
    		if (Math.abs(this.wcriSolutionArray[composition.atomicCompSchemes.get(i).getId()] - 1.0) < 0.001f) {
    			composition.atomicCompSchemes.get(i).setServiceInstance(composition.atomicCompSchemes.get(i).getCompServiceInstance());
    			composition.atomicCompSchemes.get(i).utility = composition.atomicCompSchemes.get(i).getCompServiceInstance().utility;
    			if (this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].getRedundantMode() == Config.REDUNDANT_MODE_PARALLEL) {
        			for (int m=0; m<this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.size(); m++) {
        				this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(m).qos[Config.QOS_INDEX_RESPONSETIME] = 
        						this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(m).originalRt;	
        			}
        			//重新计算QoS
        			this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].calTmpRtAndTp(); 				
    			} else {
    				this.wcriFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].changeToNextInSeq(0);
    			}

    		}
		} 	
		composition.compScheme.calculateQos();
		
    }

    public void collectDataRandom() {
       	double oriSrcRt = 0;
       	double oriSrcTp = 0;
    	//double oriSrcRe = 0;
       //	System.out.println("Random solution array is " + Arrays.toString(this.randomSolutionArray));
       	
    	for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
    		if (Math.abs(this.randomSolutionArray[composition.atomicCompSchemes.get(i).getId()] - 1.0) < 0.001f) {
    			composition.atomicCompSchemes.get(i).setServiceInstance(this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()]);
    			composition.atomicCompSchemes.get(i).utility = this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].utility;
    		}
    	}
    	
    	composition.compScheme.calculateQos();
    	boolean isSolutionFailed = isSolutionFailed();
    	//System.out.println("Random isSolutionFailed = " + isSolutionFailed);

    	this.randomCost = composition.compScheme.qosValues[Config.QOS_INDEX_COST];

    	this.randomUtility = composition.compScheme.utility;
    	this.originalRt = composition.compScheme.qosValues[Config.QOS_INDEX_RESPONSETIME];
    	this.originalTp = composition.compScheme.qosValues[Config.QOS_INDEX_THROUGHPUT];

    	for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
    		oriSrcRt = composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME];
    		oriSrcTp = composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_THROUGHPUT];
    		//oriSrcRe = composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RELIABLITY];

    		if (isSolutionFailed || composition.atomicCompSchemes.get(i).isFailed == true && this.randomSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 0) {
    			//System.out.println("Random Failed service is " + composition.atomicCompSchemes.get(i).getId());
    			this.randomAffectedTenant = composition.atomicCompSchemes.get(i).tenantsNum;
    			this.randomSucc = 0;
    			this.failedId = composition.atomicCompSchemes.get(i).getId();
    			delay = oriSrcRt * (Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY - 1);
    			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Random: Delay is " + delay);
    			composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME] = oriSrcRt * Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY;
    			composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_THROUGHPUT] = oriSrcTp * Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY;
    			//composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RELIABLITY] = oriSrcTp * Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY;

    			composition.compScheme.calculateQos();
    			newRandomRT = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];
    			newRandomTP = composition.compScheme.getQosValues()[Config.QOS_INDEX_THROUGHPUT];
    			//newRandomRE = composition.compScheme.getQosValues()[Config.QOS_INDEX_RELIABLITY];

    			randomRtIncr = newRandomRT - this.originalRt;
    			randomTpDecr = this.originalTp - newRandomTP;
    			//randomReIncr = newRandomRE - this.originalRe;

    			randomRtIncrP = randomRtIncr/this.originalRt;
    			randomTpDecrP = randomTpDecr/this.originalTp;
    			//randomReIncrP = randomReIncr/this.originalRe;

    			composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME] = oriSrcRt;
    			composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_THROUGHPUT] = oriSrcTp;
    			//composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RELIABLITY] = oriSrcRe;
    			
    		}
    		if (!isSolutionFailed && composition.atomicCompSchemes.get(i).isFailed == true && this.randomSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 1.0) {
    			int failedMemberIdx = 0;
    			Service failedMember = null;
    			double oriStraRt = 0;
    			double oriStraTp = 0;   
    			if (this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].getRedundantMode() == Config.REDUNDANT_MODE_PARALLEL) {
        			//随机选择一个strategy的成员service失败 
        			Random rand = new Random();
        			failedMemberIdx = rand.nextInt(this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.size());
        			failedMember = this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(failedMemberIdx);
        			//记录原始的QoS
        			oriStraRt = failedMember.qos[Config.QOS_INDEX_RESPONSETIME];
        			oriStraTp = failedMember.qos[Config.QOS_INDEX_THROUGHPUT];   			
        			//设置response time和throughput为劣化的目标
        			failedMember.qos[Config.QOS_INDEX_RESPONSETIME] = oriStraRt * Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY;
        			failedMember.qos[Config.QOS_INDEX_THROUGHPUT] = oriStraTp * Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY;
        			//重新计算QoS
        			this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].calTmpRtAndTp();;
   				
    			} else {
    				if (this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(0).qos[Config.QOS_INDEX_RESPONSETIME] * Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY 
        				    > this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(1).qos[Config.QOS_INDEX_RESPONSETIME]
        					|| this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(0).qos[Config.QOS_INDEX_THROUGHPUT] * Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY 
        					< this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(1).qos[Config.QOS_INDEX_THROUGHPUT]) {
    					this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].changeToNextInSeq(1);
        				}
    				
    			}
    			
    			
    			//重新计算composition的QoS
    			composition.compScheme.calculateQos();
    			
    			newRandomRT = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];
    			newRandomTP = composition.compScheme.getQosValues()[Config.QOS_INDEX_THROUGHPUT];
    			//newCriRE = composition.compScheme.getQosValues()[Config.QOS_INDEX_RELIABLITY];
    			
    			randomRtIncr = newRandomRT - this.originalRt;
    			randomTpDecr = this.originalTp - newRandomTP;
    			//criReIncr = newCriRE - this.originalRe;
    			
    			randomRtIncrP = randomRtIncr/this.originalRt;
    			randomTpDecrP = randomTpDecr/this.originalTp;

    			if (this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].getRedundantMode() == Config.REDUNDANT_MODE_PARALLEL) {
    	   			//恢复strategy的QoS
        			
        			failedMember.qos[Config.QOS_INDEX_RESPONSETIME] = oriStraRt;
        			failedMember.qos[Config.QOS_INDEX_THROUGHPUT] = oriStraTp;
        			//重新计算QoS
        			this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].calTmpRtAndTp();;
   				
    			} else {
    				this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].changeToNextInSeq(0);
    			}
    			
     			composition.compScheme.calculateQos();
    			
    			this.randomAffectedTenant = 0;
    			this.randomSucc = 1;
    			this.failedId = composition.atomicCompSchemes.get(i).getId();
     		}
    		
    	}
    	randomSuccTotal += this.randomSucc;
    	
    	for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
    		if (Math.abs(this.randomSolutionArray[composition.atomicCompSchemes.get(i).getId()] - 1.0) < 0.001f) {
    			composition.atomicCompSchemes.get(i).setServiceInstance(composition.atomicCompSchemes.get(i).getCompServiceInstance());
    			composition.atomicCompSchemes.get(i).utility = composition.atomicCompSchemes.get(i).getCompServiceInstance().utility;
    		}
    	}
    	
    	composition.compScheme.calculateQos();
    }
    public void collectDataRandomMultiFailure() {
       	double[] oriSrcRt = new double[composition.atomicCompSchemes.size()];

    	for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
    		if (Math.abs(this.randomSolutionArray[composition.atomicCompSchemes.get(i).getId()] - 1.0) < 0.001f) {
    			composition.atomicCompSchemes.get(i).setServiceInstance(this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()]);
    			composition.atomicCompSchemes.get(i).utility = this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].utility;
    		}
    	}
    	
    	composition.compScheme.calculateQos();
    	boolean isSolutionFailed = isSolutionFailed();
    	//System.out.println("Random isSolutionFailed = " + isSolutionFailed);

     	this.originalRt = composition.compScheme.qosValues[Config.QOS_INDEX_RESPONSETIME];
   	
    	for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
    		oriSrcRt[i] = composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME];

    		if (isSolutionFailed || composition.atomicCompSchemes.get(i).isFailed == true && this.randomSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 0) {
     			composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME] = oriSrcRt[i] * Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY;
    		}
    		if (!isSolutionFailed && composition.atomicCompSchemes.get(i).isFailed == true && this.randomSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 1.0) {
    			int failedMemberIdx = 0;
    			Service failedMember = null;
    			double oriStraRt = 0;
    			double oriStraTp = 0;   
    			if (this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].getRedundantMode() == Config.REDUNDANT_MODE_PARALLEL) {
        			//随机选择一个strategy的成员service失败 
        			Random rand = new Random();
        			failedMemberIdx = rand.nextInt(this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.size());
        			failedMember = this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(failedMemberIdx);
        			//记录原始的QoS
        			oriStraRt = failedMember.qos[Config.QOS_INDEX_RESPONSETIME];
        			oriStraTp = failedMember.qos[Config.QOS_INDEX_THROUGHPUT];   			
        			//设置response time和throughput为劣化的目标
        			failedMember.qos[Config.QOS_INDEX_RESPONSETIME] = oriStraRt * Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY;
        			failedMember.qos[Config.QOS_INDEX_THROUGHPUT] = oriStraTp * Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY;
        			//重新计算QoS
        			this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].calTmpRtAndTp();;
   				
    			} else {
    				this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].changeToNextInSeq(1);
    			}
    		}
    	}
    	
		composition.compScheme.calculateQos();
		newRandomRT = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];

		randomRtIncr = newRandomRT - this.originalRt;

		randomRtIncrP = randomRtIncr/this.originalRt;

		for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
			if (isSolutionFailed || composition.atomicCompSchemes.get(i).isFailed == true && this.randomSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 0) {
				composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME] = oriSrcRt[i];
			}
    		if (Math.abs(this.randomSolutionArray[composition.atomicCompSchemes.get(i).getId()] - 1.0) < 0.001f) {
    			composition.atomicCompSchemes.get(i).setServiceInstance(composition.atomicCompSchemes.get(i).getCompServiceInstance());
    			composition.atomicCompSchemes.get(i).utility = composition.atomicCompSchemes.get(i).getCompServiceInstance().utility;
    		}
    		if (!isSolutionFailed && composition.atomicCompSchemes.get(i).isFailed == true && this.randomSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 1.0) {
    			if (this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].getRedundantMode() == Config.REDUNDANT_MODE_PARALLEL) {
        			for (int m=0; m<this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.size(); m++) {
        				this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(m).qos[Config.QOS_INDEX_RESPONSETIME] = 
        						this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(m).originalRt;	
        			}
        			//重新计算QoS
        			this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].calTmpRtAndTp(); 				
    			} else {
    				this.randomFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].changeToNextInSeq(0);
    			}    			
    		}

		}
		composition.compScheme.calculateQos();
    }
    
    public void collectDataFtcMultiFailure() {
       	double[] oriSrcRt = new double[composition.atomicCompSchemes.size()];
       	for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
    		if (Math.abs(this.ftcloudSolutionArray[composition.atomicCompSchemes.get(i).getId()] - 1.0) < 0.001f) {
    			composition.atomicCompSchemes.get(i).setServiceInstance(this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()]);
    			composition.atomicCompSchemes.get(i).utility = this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].utility;
    		}
    	}
    	
    	composition.compScheme.calculateQos();
    	
    	boolean isSolutionFailed = isSolutionFailed();
    	//System.out.println("FTCloud isSolutionFailed = " + isSolutionFailed);
    	
     	this.originalRt = composition.compScheme.qosValues[Config.QOS_INDEX_RESPONSETIME];

    	for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
    		oriSrcRt[i] = composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME];

    		if (isSolutionFailed || composition.atomicCompSchemes.get(i).isFailed == true && this.ftcloudSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 0) {
     			composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME] = oriSrcRt[i] * Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY;
    		}
    		if (!isSolutionFailed && composition.atomicCompSchemes.get(i).isFailed == true && this.ftcloudSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 1.0) {
    			int failedMemberIdx = 0;
    			Service failedMember = null;
    			double oriStraRt = 0;
    			double oriStraTp = 0;
    			if (this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].getRedundantMode() == Config.REDUNDANT_MODE_PARALLEL) {
        			//随机选择一个strategy的成员service失败 
        			Random rand = new Random();
        			failedMemberIdx = rand.nextInt(this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.size());
        			failedMember = this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(failedMemberIdx);
        			//记录原始的QoS
        			oriStraRt = failedMember.qos[Config.QOS_INDEX_RESPONSETIME];
        			oriStraTp = failedMember.qos[Config.QOS_INDEX_THROUGHPUT];   			
        			//设置response time和throughput为劣化的目标
        			failedMember.qos[Config.QOS_INDEX_RESPONSETIME] = oriStraRt * Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY;
        			failedMember.qos[Config.QOS_INDEX_THROUGHPUT] = oriStraTp * Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY;
        			//重新计算QoS
        			this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].calTmpRtAndTp();;
        				
    			} else {
    				this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].changeToNextInSeq(1);
    			}
    		}
  		
    	}
		composition.compScheme.calculateQos();
		newFtCloudRT = composition.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];

		ftCloudRtIncr = newFtCloudRT - this.originalRt;

		ftCloudRtIncrP = ftCloudRtIncr/this.originalRt;

		for (int i=0; i<composition.atomicCompSchemes.size(); i++) {
			if (isSolutionFailed || composition.atomicCompSchemes.get(i).isFailed == true && this.ftcloudSolutionArray[composition.atomicCompSchemes.get(i).getId()] == 0) {
				composition.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME] = oriSrcRt[i];
			}
			
    		if (Math.abs(this.ftcloudSolutionArray[composition.atomicCompSchemes.get(i).getId()] - 1.0) < 0.001f) {
    			composition.atomicCompSchemes.get(i).setServiceInstance(composition.atomicCompSchemes.get(i).getCompServiceInstance());
    			composition.atomicCompSchemes.get(i).utility = composition.atomicCompSchemes.get(i).getCompServiceInstance().utility;
    			if (this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].getRedundantMode() == Config.REDUNDANT_MODE_PARALLEL) {
        			for (int m=0; m<this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.size(); m++) {
        				this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(m).qos[Config.QOS_INDEX_RESPONSETIME] = 
        						this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].memberService.get(m).originalRt;	
        			}
        			//重新计算QoS
        			this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].calTmpRtAndTp(); 				
    			} else {
    				this.ftcFtStrategyArray[composition.atomicCompSchemes.get(i).getId()].changeToNextInSeq(0);
    			}

    		}
		}
		composition.compScheme.calculateQos();

    }
    
    public boolean isSolutionFailed() {

    	if (this.composition.compScheme.qosValues[Config.QOS_INDEX_COST] > this.composition.constraints.constraints[Config.QOS_INDEX_COST]) {
    		return true;
    	}
    	if (this.composition.compScheme.qosValues[Config.QOS_INDEX_RELIABLITY] < this.composition.constraints.constraints[Config.QOS_INDEX_RELIABLITY]) {
    		return true;
    	}
    	if (this.composition.compScheme.qosValues[Config.QOS_INDEX_RESPONSETIME] > this.composition.constraints.constraints[Config.QOS_INDEX_RESPONSETIME]) {
    		return true;
    	}
    	if (this.composition.compScheme.qosValues[Config.QOS_INDEX_THROUGHPUT] < this.composition.constraints.constraints[Config.QOS_INDEX_THROUGHPUT]) {
    		return true;
    	}
   	
    	return false;
    }
}
