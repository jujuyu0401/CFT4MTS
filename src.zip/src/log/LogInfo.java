/**
 * 
 */
package log;

/**
 * @author juanzhou
 *
 */
public class LogInfo {

	public final static int LOGLEVEL_INFO = 1;
	public final static int LOGLEVEL_DEBUG = 2;
	public final static int LOGLEVEL_WARNNING = 3;
	
	public static int specifiedLevel = LOGLEVEL_INFO;
	
	public static int getSpecifiedLevel() {
		return specifiedLevel;
	}

	public static void setSpecifiedLevel(int specifiedLevel) {
		LogInfo.specifiedLevel = specifiedLevel;
	}

	public static void logInfo(String str) {
		
	}
	
	public static void logInfo(int level, String str) {
		if (level <= specifiedLevel) {
			System.out.println(str);
		}
	}

}
