package services;

import java.util.ArrayList;
import java.util.Arrays;

import config.Config;

public class AggregateService extends Service {

	public ArrayList<Service> memberService;
	double aggRt = 0;
	double aggTp = 0;
	int redundantMode = Config.REDUNDANT_MODE_NULL;
	public int getRedundantMode() {
		return redundantMode;
	}

	public void setRedundantMode(int redundantMode) {
		this.redundantMode = redundantMode;
	}

	public AggregateService() {
		this.qos = new double[Config.NUM_QOS];
		memberService = new ArrayList<Service>();
	}

	public ArrayList<Service> getMemberService() {
		return memberService;
	}

	public void setMemberService(ArrayList<Service> memberService) {
		this.memberService = memberService;
	}

	public void addMember(Service service) {
		this.memberService.add(service);
	}

	public void changeToNextInSeq(int idx) {
		this.qos[Config.QOS_INDEX_RESPONSETIME] = this.memberService.get(idx).qos[Config.QOS_INDEX_RESPONSETIME];
		this.qos[Config.QOS_INDEX_THROUGHPUT] = this.memberService.get(idx).qos[Config.QOS_INDEX_THROUGHPUT];
	}
	
	public void calTmpRtAndTp() {
		double minimumRt = 0;
		double tp = 0;
		minimumRt = this.memberService.get(0).qos[Config.QOS_INDEX_RESPONSETIME];
		tp = this.memberService.get(0).qos[Config.QOS_INDEX_THROUGHPUT];
		for (int i=0; i<this.memberService.size(); i++) {
			if (minimumRt > this.memberService.get(i).qos[Config.QOS_INDEX_RESPONSETIME]) {
				minimumRt = this.memberService.get(i).qos[Config.QOS_INDEX_RESPONSETIME];
				tp = this.memberService.get(i).qos[Config.QOS_INDEX_THROUGHPUT];
			}
		}
		this.qos[Config.QOS_INDEX_RESPONSETIME] = minimumRt;
		this.qos[Config.QOS_INDEX_THROUGHPUT] = tp;
	}
	
	public void calculateAggParaServiceRtAndTp() {
		double checkProbability = 0;
		//创建一个成员服务的数组用于排列组合
		int memberSize = this.memberService.size();
		Service[] memberServiceArray = new Service[memberSize];
		for (int i=0; i< memberSize; i++) {
			memberServiceArray[i] = this.memberService.get(i);
		}
		//下面两个变量是agg service最终的rt和tp
		aggRt = 0;
		aggTp = 0;
		//排列组合从1到所有成员服务 失败服务的排列组合
		for (int i=1; i<= memberSize; i++) {
			Permutations per = new Permutations();
			//当前i个服务同时失败
			ArrayList<Service[]> failedSrvList = per.combine(memberServiceArray, i);
			//针对每个排列组合进行计算
			for (int k=0; k<failedSrvList.size(); k++) {
				//这里把失败的服务设置标记 传递的是引用 所以在成员服务链表里的也会被设置
				for (int j=0; j<failedSrvList.get(k).length; j++) {
					failedSrvList.get(k)[j].failed = true;
				}
				double curScenarioProbability = 1.0;
				double finalRt = 0;
				double finalTp = 0;
				double tmpRt = 0;
				double tmpTp = 0;
				//遍历成员列表 计算当前所有失败服务一起失败的概率和这种情况下的rt和tp
				for (int r=0; r<this.memberService.size(); r++) {
					if (this.memberService.get(r).failed == true) {
						curScenarioProbability *= (1 - this.memberService.get(r).qos[Config.QOS_INDEX_RELIABLITY]);
						tmpRt = this.memberService.get(r).qos[Config.QOS_INDEX_RESPONSETIME] * Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY;
						tmpTp = this.memberService.get(r).qos[Config.QOS_INDEX_THROUGHPUT] * Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY;
					} else {
						curScenarioProbability *= this.memberService.get(r).qos[Config.QOS_INDEX_RELIABLITY];
						tmpRt = this.memberService.get(r).qos[Config.QOS_INDEX_RESPONSETIME];
						tmpTp = this.memberService.get(r).qos[Config.QOS_INDEX_THROUGHPUT];						
					}
					
					if (0 == r) {
						finalRt = tmpRt;
						finalTp = tmpTp;
					} else {
						//以执行最快的service rt为当前的rt，取之相应的tp
						if (finalRt > tmpRt) {
							finalRt = tmpRt;
							finalTp = tmpTp;
						}						
					}
				}
				aggRt += curScenarioProbability * finalRt;
				aggTp += curScenarioProbability * finalTp;
				checkProbability += curScenarioProbability;
				for (int j=0; j<failedSrvList.get(k).length; j++) {
					failedSrvList.get(k)[j].failed = false;
				}
				
//				ArrayList<Service> succSrvList = new ArrayList<Service>();
//				for (int j=0; j<this.memberService.size(); j++) {
//					boolean failed = false;
//					for (int r=0; r<failedSrvList.get(k).length; r++) {
//						if (this.memberService.get(j).servicdId == failedSrvList.get(k)[r].servicdId) {
//							failed = true;
//							break;
//						}
//					}
//					if (!failed) {
//						succSrvList.add(this.memberService.get(j));
//					}
//					
//				}
//				double failureProbability = 1.0;
//				for (int j=0; j<failedSrvList.get(k).length; j++) {
//					failureProbability *= (1 - failedSrvList.get(k)[j].qos[Config.QOS_INDEX_RELIABLITY]);
//				}
//				
			}
		}
		
		double succProbability = 1.0;
		double succRt = 0;
		double succTp = 0;
		succRt = this.memberService.get(0).qos[Config.QOS_INDEX_RESPONSETIME];
		for (int j=0; j<this.memberService.size(); j++) {
			succProbability *= this.memberService.get(j).qos[Config.QOS_INDEX_RELIABLITY];
			if (succRt > this.memberService.get(j).qos[Config.QOS_INDEX_RESPONSETIME]) {
				succRt = this.memberService.get(j).qos[Config.QOS_INDEX_RESPONSETIME];
				succTp = this.memberService.get(j).qos[Config.QOS_INDEX_THROUGHPUT];
			}
		}
		aggRt += succProbability * succRt;
		aggTp += succProbability * succTp;			
		checkProbability += succProbability; 
		this.qos[Config.QOS_INDEX_RESPONSETIME] = aggRt;
		this.qos[Config.QOS_INDEX_THROUGHPUT] = aggTp;
		
		//System.out.println("Check probability is " + checkProbability + ", final RT is " + aggRt + ", final TP is " + aggTp);
	}
	public void calculateAggSeqServiceRtAndTp() {
		//下面两个变量是agg service最终的rt和tp
		aggRt = 0;
		aggTp = 0;
		double preFailedProbability = 1.0;
		aggRt = this.memberService.get(0).qos[Config.QOS_INDEX_RESPONSETIME] 
				* this.memberService.get(0).qos[Config.QOS_INDEX_RELIABLITY];
		aggTp = this.memberService.get(0).qos[Config.QOS_INDEX_THROUGHPUT] 
				* this.memberService.get(0).qos[Config.QOS_INDEX_RELIABLITY];
		preFailedProbability = 1 - this.memberService.get(0).qos[Config.QOS_INDEX_RELIABLITY];
		for (int i=1; i<this.memberService.size(); i++) {
			aggRt += preFailedProbability * this.memberService.get(i).qos[Config.QOS_INDEX_RESPONSETIME];
			aggTp += preFailedProbability * this.memberService.get(i).qos[Config.QOS_INDEX_THROUGHPUT];
			preFailedProbability *= (1 - this.memberService.get(i).qos[Config.QOS_INDEX_RELIABLITY]);
		}
	}
	public void calculateQoS() {
		double cost = 0;
		double failureRate = 1.0;
		double failProbability = 1.0;
		
		for (int i=0; i<this.memberService.size(); i++) {

			if (this.redundantMode == Config.REDUNDANT_MODE_PARALLEL) {
				cost += this.memberService.get(i).qos[Config.QOS_INDEX_COST];
			} else {
				//之前所有服务都失败的概率
				double totalCost = 0;
				for (int j=0; j<=i; j++) {
					totalCost += this.memberService.get(j).qos[Config.QOS_INDEX_COST];
				}
				cost += totalCost * failProbability;
				failProbability *= (1 - this.memberService.get(i).qos[Config.QOS_INDEX_RELIABLITY]);	
			}
			
			failureRate = failureRate * (1.0 - this.memberService.get(i).qos[Config.QOS_INDEX_RELIABLITY]);
		}
		if (this.redundantMode == Config.REDUNDANT_MODE_PARALLEL) {
			calculateAggParaServiceRtAndTp();
		} else {
			calculateAggSeqServiceRtAndTp();
		}
		this.qos[Config.QOS_INDEX_COST] = cost;
		this.qos[Config.QOS_INDEX_RELIABLITY] = 1.0 - failureRate;
		this.qos[Config.QOS_INDEX_RESPONSETIME] = this.aggRt;
		this.qos[Config.QOS_INDEX_THROUGHPUT] = this.aggTp;
		
		return;
	}
	
	@Override
	public String toString() {
		return "AggregateService [memberService=" + memberService + "]";
	}
	
}
