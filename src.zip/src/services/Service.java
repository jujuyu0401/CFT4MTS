package services;

import java.util.Arrays;

import config.Config;

public class Service {
	public int servicdId;
	public double[] qos = new double[Config.NUM_QOS];
	public double[] nqos = new double[Config.NUM_QOS];
	public double utility;
	public double failureProbability = 0;
	boolean failed = false;
	public double originalRt = 0;
	
	public int getServicdId() {
		return servicdId;
	}

	public void setServicdId(int servicdId) {
		this.servicdId = servicdId;
	}

	public double[] getQos() {
		return qos;
	}

	public void setQos(double[] qos) {
		this.qos = qos;
	}

	public Service() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Service [servicdId=" + servicdId + ", qos="
				+ Arrays.toString(qos) + "]\n";
	}
}
