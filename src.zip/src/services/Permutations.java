package services;
import java.util.ArrayList;
import java.util.List;

public class Permutations {
//  ç»„å�ˆç®—æ³•   
//    æœ¬ç¨‹åº�çš„æ€�è·¯æ˜¯å¼€ä¸€ä¸ªæ•°ç»„ï¼Œå…¶ä¸‹æ ‡è¡¨ç¤º1åˆ°mä¸ªæ•°ï¼Œæ•°ç»„å…ƒç´ çš„å€¼ä¸º1è¡¨ç¤ºå…¶ä¸‹æ ‡   
//    ä»£è¡¨çš„æ•°è¢«é€‰ä¸­ï¼Œä¸º0åˆ™æ²¡é€‰ä¸­ã€‚     
//    é¦–å…ˆåˆ�å§‹åŒ–ï¼Œå°†æ•°ç»„å‰�nä¸ªå…ƒç´ ç½®1ï¼Œè¡¨ç¤ºç¬¬ä¸€ä¸ªç»„å�ˆä¸ºå‰�nä¸ªæ•°ã€‚     
//    ç„¶å�Žä»Žå·¦åˆ°å�³æ‰«æ��æ•°ç»„å…ƒç´ å€¼çš„â€œ10â€�ç»„å�ˆï¼Œæ‰¾åˆ°ç¬¬ä¸€ä¸ªâ€œ10â€�ç»„å�ˆå�Žå°†å…¶å�˜ä¸º   
//    â€œ01â€�ç»„å�ˆï¼Œå�Œæ—¶å°†å…¶å·¦è¾¹çš„æ‰€æœ‰â€œ1â€�å…¨éƒ¨ç§»åŠ¨åˆ°æ•°ç»„çš„æœ€å·¦ç«¯ã€‚     
//    å½“ç¬¬ä¸€ä¸ªâ€œ1â€�ç§»åŠ¨åˆ°æ•°ç»„çš„m-nçš„ä½�ç½®ï¼Œå�³nä¸ªâ€œ1â€�å…¨éƒ¨ç§»åŠ¨åˆ°æœ€å�³ç«¯æ—¶ï¼Œå°±å¾—   
//    åˆ°äº†æœ€å�Žä¸€ä¸ªç»„å�ˆã€‚     
//    ä¾‹å¦‚æ±‚5ä¸­é€‰3çš„ç»„å�ˆï¼š     
//    1   1   1   0   0   //1,2,3     
//    1   1   0   1   0   //1,2,4     
//    1   0   1   1   0   //1,3,4     
//    0   1   1   1   0   //2,3,4     
//    1   1   0   0   1   //1,2,5     
//    1   0   1   0   1   //1,3,5     
//    0   1   1   0   1   //2,3,5     
//    1   0   0   1   1   //1,4,5     
//    0   1   0   1   1   //2,4,5     
//    0   0   1   1   1   //3,4,5   
	ArrayList<Service[]> permutationResult = null;
	public Permutations() {

	}

	  private void swap(Service[] array, int i, int j) {
		    if (i == j) return;
		    Service x = array[i];
		    array[i] = array[j];
		    array[j] = x;
		  }

	  private void permutate(Service[] array, int start, int end) {
	    if (start == end) {
	      //System.out.println("start = end");
	      Service[] srvArray = new Service[array.length];
	      for (int j=0; j<array.length; j++) {
	    	  srvArray[j] = array[j]; 	  
	      }
	      permutationResult.add(srvArray);
	    } else {
	      for (int i = start; i <= end; i++) {
	        swap(array, i, start);
	        permutate(array, start + 1, end);
	        swap(array, start, i);
	      }
	    }
	  }

	  public ArrayList<Service[]> permutate(Service[] array) {
		permutationResult = new ArrayList<Service[]>();
	    permutate(array, 0, array.length - 1);
	    return permutationResult;
	  }
    /**
     * ä»Žnä¸ªæ•°å­—ä¸­é€‰æ‹©mä¸ªæ•°å­—
     * @param a
     * @param m
     * @return
     */
    public ArrayList<Service[]> combine(Service[] a,int m){
        int n = a.length;
        if(m>n){
            System.out.println("!!!");
        }
        
        ArrayList<Service[]> result = new ArrayList<Service[]>();
        
        int[] bs = new int[n];
        for(int i=0;i<n;i++){
            bs[i]=0;
        }
        //åˆ�å§‹åŒ–
        for(int i=0;i<m;i++){
            bs[i]=1;
        }
        boolean flag = true;
        boolean tempFlag = false;
        int pos = 0;
        int sum = 0;
        //é¦–å…ˆæ‰¾åˆ°ç¬¬ä¸€ä¸ª10ç»„å�ˆï¼Œç„¶å�Žå�˜æˆ�01ï¼Œå�Œæ—¶å°†å·¦è¾¹æ‰€æœ‰çš„1ç§»åŠ¨åˆ°æ•°ç»„çš„æœ€å·¦è¾¹
        do{
            sum = 0;
            pos = 0;
            tempFlag = true; 
            result.add(print(bs,a,m));
            
            for(int i=0;i<n-1;i++){
                if(bs[i]==1 && bs[i+1]==0 ){
                    bs[i]=0;
                    bs[i+1]=1;
                    pos = i;
                    break;
                }
            }
            //å°†å·¦è¾¹çš„1å…¨éƒ¨ç§»åŠ¨åˆ°æ•°ç»„çš„æœ€å·¦è¾¹
            
            for(int i=0;i<pos;i++){
                if(bs[i]==1){
                    sum++;
                }
            }
            for(int i=0;i<pos;i++){
                if(i<sum){
                    bs[i]=1;
                }else{
                    bs[i]=0;
                }
            }
            
            //æ£€æŸ¥æ˜¯å�¦æ‰€æœ‰çš„1éƒ½ç§»åŠ¨åˆ°äº†æœ€å�³è¾¹
            for(int i= n-m;i<n;i++){
                if(bs[i]==0){
                    tempFlag = false;
                    break;
                }
            }
            if(tempFlag==false){
                flag = true;
            }else{
                flag = false;
            }
            
        }while(flag);
        if (n != m) {
        	result.add(print(bs,a,m));
        }
        
        
        return result;
    }
    
    private Service[] print(int[] bs,Service[] a,int m){
        Service[] result = new Service[m];
        int pos= 0;
        for(int i=0;i<bs.length;i++){
            if(bs[i]==1){
                result[pos]=a[i];
                pos++;
            }
        }
        return result ;
    }
    
    private void print(ArrayList<Service[]> l){
        for(int i=0;i<l.size();i++){
            Service[] a = (Service[])l.get(i);
            for(int j=0;j<a.length;j++){
                System.out.print(a[j].servicdId+"\t");
            }
            System.out.println();
        }
    }
}
