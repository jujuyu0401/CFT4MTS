package services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

import composition.ExecutionPath;

import log.LogInfo;
import config.Config;

public class ServiceClass {
	public int serviceClassId;
	public int serviceNum;
	public Service[] services;
	public double[][] minAndMaxQoS = new double[Config.NUM_QOS][Config.QOS_MIN_MAX_BOUND];
	public int aggServiceNum;
	public ArrayList<AggregateService> aggServiceList;
	public double originalInstanceCost = 0;

	public int getServiceClassId() {
		return serviceClassId;
	}

	public void setServiceClassId(int serviceClassId) {
		this.serviceClassId = serviceClassId;
	}

	public Service[] getServices() {
		return services;
	}

	public void setServices(Service[] services) {
		this.services = services;
	}

	public int getServiceNum() {
		return serviceNum;
	}

	public void setServiceNum(int serviceNum) {
		this.serviceNum = serviceNum;
	}
	
	public void initMinAndMaxQoS() {
		for (int i=0; i<Config.NUM_QOS; i++) {
			minAndMaxQoS[i][Config.QOS_MIN_INDEX] = Config.QOS_UPPER_BOUND;
			minAndMaxQoS[i][Config.QOS_MAX_INDEX] = Config.QOS_LOWER_BOUND;
		}
	}
	public ServiceClass(int serviceNum, int serviceClassId) {
		this.serviceNum = serviceNum;
		this.serviceClassId = serviceClassId;
		this.services = new Service[serviceNum];
		this.aggServiceList = new ArrayList<AggregateService>();
		initMinAndMaxQoS();
	}
	public void normaliseQoS() {
		for (int i=0; i<this.services.length; i++) {
			this.services[i].nqos[Config.QOS_INDEX_COST] = (minAndMaxQoS[Config.QOS_INDEX_COST][Config.QOS_MAX_INDEX]-this.services[i].qos[Config.QOS_INDEX_COST])
					/(minAndMaxQoS[Config.QOS_INDEX_COST][Config.QOS_MAX_INDEX] - minAndMaxQoS[Config.QOS_INDEX_COST][Config.QOS_MIN_INDEX]);
			this.services[i].nqos[Config.QOS_INDEX_RELIABLITY] = (this.services[i].qos[Config.QOS_INDEX_RELIABLITY] - minAndMaxQoS[Config.QOS_INDEX_RELIABLITY][Config.QOS_MIN_INDEX])
					/(minAndMaxQoS[Config.QOS_INDEX_RELIABLITY][Config.QOS_MAX_INDEX] - minAndMaxQoS[Config.QOS_INDEX_RELIABLITY][Config.QOS_MIN_INDEX]);
			this.services[i].nqos[Config.QOS_INDEX_RESPONSETIME] = (minAndMaxQoS[Config.QOS_INDEX_RESPONSETIME][Config.QOS_MAX_INDEX]-this.services[i].qos[Config.QOS_INDEX_RESPONSETIME])
					/(minAndMaxQoS[Config.QOS_INDEX_RESPONSETIME][Config.QOS_MAX_INDEX] - minAndMaxQoS[Config.QOS_INDEX_RESPONSETIME][Config.QOS_MIN_INDEX]);
			this.services[i].nqos[Config.QOS_INDEX_THROUGHPUT] = (this.services[i].qos[Config.QOS_INDEX_THROUGHPUT] - minAndMaxQoS[Config.QOS_INDEX_THROUGHPUT][Config.QOS_MIN_INDEX])
					/(minAndMaxQoS[Config.QOS_INDEX_THROUGHPUT][Config.QOS_MAX_INDEX] - minAndMaxQoS[Config.QOS_INDEX_THROUGHPUT][Config.QOS_MIN_INDEX]);		
//			System.out.println("SC " + this.serviceClassId + " service " + i + " original qos is " 
//					+ Arrays.toString(this.services[i].qos)
//					+ ", normalised qos is " + Arrays.toString(this.services[i].nqos));
		}
		
	}
	public void updateMaxMinQoS() {

		for (int i=0; i<this.services.length; i++) {
			for (int d=0;d<Config.NUM_QOS;d++) {
				if (minAndMaxQoS[d][Config.QOS_MIN_INDEX] > this.services[i].qos[d]) {
					minAndMaxQoS[d][Config.QOS_MIN_INDEX] = this.services[i].qos[d];
				}
				if (minAndMaxQoS[d][Config.QOS_MAX_INDEX] < this.services[i].qos[d]) {
					minAndMaxQoS[d][Config.QOS_MAX_INDEX] = this.services[i].qos[d];
				}
			}
		}	
//		for (int d=0;d<Config.NUM_QOS;d++) {
//			System.out.println("SC " + this.serviceClassId + " max and min qos is " + Arrays.toString(minAndMaxQoS[d]));
//		}
		
	}
	public void addService(int index, Service service) {
		services[index] = service;
		return;
	}
	
	Comparator<Service> comparatorTopk = new Comparator<Service>(){
		   @Override
		public int compare(Service s1, Service s2) {
			   if (s1.utility < s2.utility) {
				   return 1;
			   } else {
				   return -1;
			   }
		   }
	};

	Comparator<Service> comparatorFb = new Comparator<Service>(){
		   @Override
		public int compare(Service s1, Service s2) {
			   if (s1.failureProbability > s2.failureProbability) {
				   return 1;
			   } else {
				   return -1;
			   }
		   }
	};
	
	public void sortAggSrcByFailureProbability() {
		//Arrays.sort(this.services, comparatorFb);
		Collections.sort(this.aggServiceList, comparatorFb);
	}
	public void sortAggSrcByUtility() {
		//Arrays.sort(this.services, comparatorFb);
		Collections.sort(this.aggServiceList, comparatorTopk);
	}
	public void sortScByUtility() {
		Arrays.sort(this.services, comparatorTopk);
	}
	
	public void generateAggregateServicesByTopk(Service originalInstance, double[][] minAndMaxQoS, int topk) {	
		int aggServiceNum = 0;
		this.aggServiceList.removeAll(aggServiceList);
		this.aggServiceNum = 0;
		this.originalInstanceCost = originalInstance.qos[Config.QOS_INDEX_COST];
		Arrays.sort(this.services, comparatorTopk);
		
//		System.out.println("Sorted services by utility: ");
//		for (int j=0; j<this.services.length;j++) {
//			System.out.println("Service " + this.services[j].utility);
//		}
		
		for (int j = 1; j <= topk; j++) {
			/*
			 * Create permutation of current candidate services with the
			 * specified instantiated service
			 */
			Service[] topkServices = new Service[topk];
			for (int i=0;i<topk;i++) {
				topkServices[i] = this.services[i];
			}
			Permutations per = new Permutations();
			ArrayList<Service[]> aggParaSrvList = per.combine(topkServices, j);
//			System.out.println("Top " + topk + " services make " + aggSrvList.size() + " aggregated services.");
			for (int k = 0; k < aggParaSrvList.size(); k++) {
				AggregateService aggParaService = new AggregateService();
				aggParaService.setRedundantMode(Config.REDUNDANT_MODE_PARALLEL);
				aggParaService.servicdId = aggServiceNum++;
				aggParaService.failureProbability = 1.0;
				aggParaService.addMember(originalInstance);
				aggParaService.failureProbability *= originalInstance.failureProbability;
				
				for (int l = 0; l < aggParaSrvList.get(k).length; l++) {
//					//按照FT Cost计算 不包括original instance的cost 在这里计算
//					if (Config.USE_FT_COST_CONSTRAINT) {
//						aggService1.qos[Config.QOS_INDEX_COST] += aggSrvList.get(k)[l].qos[Config.QOS_INDEX_COST];
//					}
					aggParaService.addMember(aggParaSrvList.get(k)[l]);
					aggParaService.failureProbability *= aggParaSrvList.get(k)[l].failureProbability;
				}
				/* Calculate the aggregate QoS values for aggregate services */
				aggParaService.calculateQoS();
				
				if (aggParaService.qos[Config.QOS_INDEX_COST] > minAndMaxQoS[Config.QOS_INDEX_COST][Config.QOS_MAX_INDEX]) {
					minAndMaxQoS[Config.QOS_INDEX_COST][Config.QOS_MAX_INDEX] = aggParaService.qos[Config.QOS_INDEX_COST];
				}
				
				if (aggParaService.qos[Config.QOS_INDEX_RELIABLITY] > minAndMaxQoS[Config.QOS_INDEX_RELIABLITY][Config.QOS_MAX_INDEX]) {
					minAndMaxQoS[Config.QOS_INDEX_RELIABLITY][Config.QOS_MAX_INDEX] = aggParaService.qos[Config.QOS_INDEX_RELIABLITY];
				}
				
				if (aggParaService.qos[Config.QOS_INDEX_THROUGHPUT] > minAndMaxQoS[Config.QOS_INDEX_THROUGHPUT][Config.QOS_MAX_INDEX]) {
					minAndMaxQoS[Config.QOS_INDEX_THROUGHPUT][Config.QOS_MAX_INDEX] = aggParaService.qos[Config.QOS_INDEX_THROUGHPUT];
				}
				
				if (aggParaService.qos[Config.QOS_INDEX_RESPONSETIME] < minAndMaxQoS[Config.QOS_INDEX_RESPONSETIME][Config.QOS_MIN_INDEX]) {
					minAndMaxQoS[Config.QOS_INDEX_RESPONSETIME][Config.QOS_MIN_INDEX] = aggParaService.qos[Config.QOS_INDEX_RESPONSETIME];
				}
				
				//aggService1.qos[Config.QOS_INDEX_RESPONSETIME] = originalInstance.qos[Config.QOS_INDEX_RESPONSETIME];
				//aggService1.qos[Config.QOS_INDEX_THROUGHPUT] = originalInstance.qos[Config.QOS_INDEX_THROUGHPUT];
				this.aggServiceList.add(aggParaService);
				
				//对当前的组合进行全排列 生成sequential模式的redundant service
				ArrayList<Service[]> aggSeqSrvList = per.permutate(aggParaSrvList.get(k));
				for (int m=0; m<aggSeqSrvList.size(); m++) {
					AggregateService aggSeqService = new AggregateService();
					aggSeqService.setRedundantMode(Config.REDUNDANT_MODE_SEQUENTIAL);
					aggSeqService.servicdId = aggServiceNum++;
					aggSeqService.failureProbability = 1.0;
					aggSeqService.addMember(originalInstance);
					aggSeqService.failureProbability *= originalInstance.failureProbability;
					
					for (int l = 0; l < aggSeqSrvList.get(m).length; l++) {
						aggSeqService.addMember(aggSeqSrvList.get(m)[l]);
						aggSeqService.failureProbability *= aggSeqSrvList.get(m)[l].failureProbability;
					}
					/* Calculate the aggregate QoS values for aggregate services */
					aggSeqService.calculateQoS();
					
					if (aggSeqService.qos[Config.QOS_INDEX_COST] > minAndMaxQoS[Config.QOS_INDEX_COST][Config.QOS_MAX_INDEX]) {
						minAndMaxQoS[Config.QOS_INDEX_COST][Config.QOS_MAX_INDEX] = aggSeqService.qos[Config.QOS_INDEX_COST];
					}
					
					if (aggSeqService.qos[Config.QOS_INDEX_RELIABLITY] > minAndMaxQoS[Config.QOS_INDEX_RELIABLITY][Config.QOS_MAX_INDEX]) {
						minAndMaxQoS[Config.QOS_INDEX_RELIABLITY][Config.QOS_MAX_INDEX] = aggSeqService.qos[Config.QOS_INDEX_RELIABLITY];
					}
					
					if (aggSeqService.qos[Config.QOS_INDEX_THROUGHPUT] > minAndMaxQoS[Config.QOS_INDEX_THROUGHPUT][Config.QOS_MAX_INDEX]) {
						minAndMaxQoS[Config.QOS_INDEX_THROUGHPUT][Config.QOS_MAX_INDEX] = aggSeqService.qos[Config.QOS_INDEX_THROUGHPUT];
					}
					
					if (aggSeqService.qos[Config.QOS_INDEX_RESPONSETIME] < minAndMaxQoS[Config.QOS_INDEX_RESPONSETIME][Config.QOS_MIN_INDEX]) {
						minAndMaxQoS[Config.QOS_INDEX_RESPONSETIME][Config.QOS_MIN_INDEX] = aggSeqService.qos[Config.QOS_INDEX_RESPONSETIME];
					}
					
					//aggService1.qos[Config.QOS_INDEX_RESPONSETIME] = originalInstance.qos[Config.QOS_INDEX_RESPONSETIME];
					//aggService1.qos[Config.QOS_INDEX_THROUGHPUT] = originalInstance.qos[Config.QOS_INDEX_THROUGHPUT];
					this.aggServiceList.add(aggSeqService);				
				}
			}
		}
		this.aggServiceNum = aggServiceNum;
		//printAggregateServices();
		
	}
	public void printAllAggServices() {
		for (int i=0; i<this.aggServiceList.size(); i++) {
			System.out.println("AggService " + this.aggServiceList.get(i).getServicdId()
					+ ", fail probability is " + this.aggServiceList.get(i).failureProbability
					+ ", member number is " + this.aggServiceList.get(i).memberService.size());
		}
	}
	public void generateAggregateServices(Service originalInstance, double[][] minAndMaxQoS) {	
		int aggServiceNum = 0;
		this.aggServiceList.removeAll(aggServiceList);
		this.aggServiceNum = 0;

		for (int j = 1; j <= Config.NUM_AGG_SERVICES_PER_CLASS; j++) {
			/*
			 * Create permutation of current candidate services with the
			 * specified instantiated service
			 */
			Permutations per = new Permutations();
			ArrayList<Service[]> aggSrvList = per.combine(this.services, j);
			for (int k = 0; k < aggSrvList.size(); k++) {
				AggregateService aggService1 = new AggregateService();
				aggService1.servicdId = aggServiceNum++;
				aggService1.addMember(originalInstance);
				for (int l = 0; l < aggSrvList.get(k).length; l++) {
					aggService1.addMember(aggSrvList.get(k)[l]);
				}
				/* Calculate the aggregate QoS values for aggregate services */
				aggService1.calculateQoS();
				
				if (aggService1.qos[Config.QOS_INDEX_COST] > minAndMaxQoS[Config.QOS_INDEX_COST][Config.QOS_MAX_INDEX]) {
					minAndMaxQoS[Config.QOS_INDEX_COST][Config.QOS_MAX_INDEX] = aggService1.qos[Config.QOS_INDEX_COST];
				}
				
				if (aggService1.qos[Config.QOS_INDEX_RELIABLITY] > minAndMaxQoS[Config.QOS_INDEX_RELIABLITY][Config.QOS_MAX_INDEX]) {
					minAndMaxQoS[Config.QOS_INDEX_RELIABLITY][Config.QOS_MAX_INDEX] = aggService1.qos[Config.QOS_INDEX_RELIABLITY];
				}
				
				if (aggService1.qos[Config.QOS_INDEX_THROUGHPUT] > minAndMaxQoS[Config.QOS_INDEX_THROUGHPUT][Config.QOS_MAX_INDEX]) {
					minAndMaxQoS[Config.QOS_INDEX_THROUGHPUT][Config.QOS_MAX_INDEX] = aggService1.qos[Config.QOS_INDEX_THROUGHPUT];
				}
				
				if (aggService1.qos[Config.QOS_INDEX_RESPONSETIME] < minAndMaxQoS[Config.QOS_INDEX_RESPONSETIME][Config.QOS_MIN_INDEX]) {
					minAndMaxQoS[Config.QOS_INDEX_RESPONSETIME][Config.QOS_MIN_INDEX] = aggService1.qos[Config.QOS_INDEX_RESPONSETIME];
				}
				
				//aggService1.qos[Config.QOS_INDEX_RESPONSETIME] = originalInstance.qos[Config.QOS_INDEX_RESPONSETIME];
				//aggService1.qos[Config.QOS_INDEX_THROUGHPUT] = originalInstance.qos[Config.QOS_INDEX_THROUGHPUT];
				this.aggServiceList.add(aggService1);
			}
		}
		this.aggServiceNum = aggServiceNum;
		//printAggregateServices();
		
	}
	public void printAggregateServices() {
		System.out.println();
		System.out.println("Aggregate Services of Service Class " + this.serviceClassId + " :");
		System.out.println("Cost of original instance service: " + originalInstanceCost);
		System.out.println("Number in total: " + this.aggServiceList.size());
		for (int i=0; i<this.aggServiceList.size(); i++) {
			System.out.println("Service Id: " + this.aggServiceList.get(i).servicdId);
			if (this.aggServiceList.get(i).redundantMode == Config.REDUNDANT_MODE_PARALLEL) {
				System.out.println("Redundancy mode: Parallel");
			} else {
				System.out.println("Redundancy mode: Sequential");
			}
			
			System.out.println("failure probability: " + this.aggServiceList.get(i).failureProbability);
			System.out.println("Member services number: " + aggServiceList.get(i).memberService.size());
			System.out.println("Member services : ");
			for (int j=0; j<this.aggServiceList.get(i).memberService.size(); j++) {
				System.out.println("Member service " + this.aggServiceList.get(i).memberService.get(j).servicdId + ", qos = " 
						+ ", utility: " + this.aggServiceList.get(i).memberService.get(j).utility + Arrays.toString(this.aggServiceList.get(i).memberService.get(j).qos));
			}
			
			System.out.println("Aggregate Qos is " + Arrays.toString(this.aggServiceList.get(i).qos));
			
			System.out.println("---------------------------------------------------------");
		}
	}
	
	public int getAggServiceNum() {
		return aggServiceNum;
	}

	public void setAggServiceNum(int aggServiceNum) {
		this.aggServiceNum = aggServiceNum;
	}

	@Override
	public String toString() {
		return "\nServiceClass [serviceClassId=" + serviceClassId
				+ ", serviceNum=" + serviceNum + ", services=\n"
				+ Arrays.toString(services) + "]";
	}

}
