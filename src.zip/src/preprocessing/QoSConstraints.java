package preprocessing;

import java.util.Arrays;
import java.util.Random;

import log.LogInfo;
import config.Config;

public class QoSConstraints {
	public double[] constraints;

	public QoSConstraints() {
		constraints = new double[Config.NUM_QOS];
	}
	
	public void randomQoSConstraints() {
		Random rand = new Random();
		for (int i=0; i<Config.NUM_QOS; i++) {
			if (i == Config.QOS_INDEX_RELIABLITY) {
				constraints[i] = 0;
//				while (((double) Config.QOS_CONSTRAINT_LOWER_BOUND / Config.QOS_CONSTRAINT_UPPER_BOUND) >= constraints[i]) {
//					constraints[i] = rand.nextDouble();
//				}
			} else if (i == Config.QOS_INDEX_THROUGHPUT) {
				constraints[i] = 0;
//				while (Config.QOS_CONSTRAINT_LOWER_BOUND >= constraints[i]) {
//					constraints[i] = rand.nextInt(Config.QOS_UPPER_BOUND + 1);
//				}	
			}
			else if (i == Config.QOS_INDEX_RESPONSETIME) {
				constraints[i] = 1200000;//Config.QOS_UPPER_BOUND * Config.NUM_TASKS;
//				constraints[i] = 0;
//				while (Config.QOS_CONSTRAINT_LOWER_BOUND_ACCU >= constraints[i]) {
//					constraints[i] = rand.nextDouble() * Config.QOS_CONSTRAINT_UPPER_BOUND_ACCU;					
//				}			
			}	
			else {//cost
				constraints[i] = 1200000;
//				constraints[i] = 0;
//				while (Config.QOS_CONSTRAINT_LOWER_BOUND_ACCU*Config.NUM_TOP_SERVICES_PER_CLASS >= constraints[i]) {
//					constraints[i] = rand.nextDouble() * Config.QOS_CONSTRAINT_UPPER_BOUND_ACCU*Config.NUM_TOP_SERVICES_PER_CLASS;					
//				}			
				
			}
		}
		return;
	}
	
	public void printConstraints() {
		System.out.println();
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, this.toString());
		System.out.println();
	}
	
	@Override
	public String toString() {
		return "QoSConstraints [constraints=" + Arrays.toString(constraints)
				+ "]";
	}

}
