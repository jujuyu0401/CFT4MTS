/**
 * 
 */
package preprocessing;

import java.util.Arrays;
import java.util.Random;

import config.Config;
import services.Service;
import services.ServiceClass;


/**
 * @author Yanchun Wang
 *
 */
public class ServiceSampling {
	public Service[] serviceInstances;
	public ServiceClass[] serviceClasses;
 
	public ServiceSampling() {
		serviceInstances = new Service[Config.NUM_TASKS];
		serviceClasses = new ServiceClass[Config.NUM_SERVICE_CLASSES];
	}
	
	public Service[] getOriginalServices() {
		return serviceInstances;
	}

	public void setOriginalServices(Service[] originalServices) {
		this.serviceInstances = originalServices;
	}

	public ServiceClass[] getServiceClasses() {
		return serviceClasses;
	}

	public void setServiceClasses(ServiceClass[] serviceClasses) {
		this.serviceClasses = serviceClasses;
	}

	public Service generateService() {
		Random rand = new Random();
		Service service = new Service();
		for (int j=0; j<Config.NUM_QOS; j++) {
			if (j == Config.QOS_INDEX_RELIABLITY) {
				double re = rand.nextDouble();
				while (re <= 0.8) {
					re = rand.nextDouble();
				}
				service.getQos()[j] = re;
			} else if (j == Config.QOS_INDEX_THROUGHPUT) {
				int tp = rand.nextInt(Config.QOS_UPPER_BOUND);
				while (tp < 10) {
					tp = rand.nextInt(Config.QOS_UPPER_BOUND);
				}
				service.getQos()[j] = tp;
			} else if (j == Config.QOS_INDEX_RESPONSETIME) {
				double coeff = 0.0;
				while (coeff <= 0.04) {
					coeff = rand.nextDouble();
				}
				service.getQos()[j] = coeff * Config.QOS_UPPER_BOUND;
				service.originalRt = service.getQos()[j];
			} else if (j == Config.QOS_INDEX_COST) {
				double coeff = 0.0;
				//如果rt或tp比较优 则cost较高
				if (service.getQos()[Config.QOS_INDEX_RESPONSETIME] < Config.QOS_UPPER_BOUND/2 ||
						service.getQos()[Config.QOS_INDEX_THROUGHPUT] > Config.QOS_UPPER_BOUND/2) {
					while (coeff <= 0.5) {
						coeff = rand.nextDouble();
					}
				} else {
					while (coeff >= 0.5) {
						coeff = rand.nextDouble();
					}
				}
				service.getQos()[j] = coeff * Config.QOS_UPPER_BOUND;
			}
					
		}
		service.failureProbability = Config.DEFAULT_FAILURE_PROBABILITY;
		return service;
	}
	
	public void generateServiceInstances() {
		for (int i=0; i<Config.NUM_TASKS; i++) {
			serviceInstances[i] = generateService();
			serviceInstances[i].setServicdId(0);
			//System.out.println("Generate instances: " + i + ", qos is " + Arrays.toString(serviceInstances[i].qos));
		}
		return;
	}

	
	public void generateServiceClasses() {
		for (int i=0; i<Config.NUM_SERVICE_CLASSES; i++) {
			serviceClasses[i] = new ServiceClass(Config.NUM_SERVICES_PER_CLASS, i);
			for (int j=0; j<Config.NUM_SERVICES_PER_CLASS; j++) {
				serviceClasses[i].getServices()[j] = generateService();
				
				serviceClasses[i].getServices()[j].setServicdId(j+1);
			}
			serviceClasses[i].updateMaxMinQoS();
			serviceClasses[i].normaliseQoS();
		}
		return;
	}
	
	@Override
	public String toString() {
		return "ServiceSampling \n[originalServices=\n"
				+ Arrays.toString(serviceInstances) + ", \nserviceClasses="
				+ Arrays.toString(serviceClasses) + "]";
	}
}
