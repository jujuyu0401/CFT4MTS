package preprocessing;

import java.util.Arrays;

import log.LogInfo;
import weka.core.Debug.Random;
import config.Config;

public class Users {
	public double[] userDistribution;
	public double[][] userPreferences;

	public Users() {
		userDistribution = new double[Config.NUM_USER_CLUSTERS];
		userPreferences = new double[Config.NUM_USER_CLUSTERS][Config.NUM_QOS];
	}

	public void randomUserDistribution() {
		Random rand = new Random();
		double left = 1.0;
		for (int i=0; i<Config.NUM_USER_CLUSTERS; i++) {

			if (i == Config.NUM_USER_CLUSTERS - 1) {
				userDistribution[i] = left;
			} else {
				while (0 >= userDistribution[i]) {
					userDistribution[i] = rand.nextDouble() * left;
				}
			}
			left = left - userDistribution[i];

		}
	}
	
	public void randomUserPreferences() {
		
		userPreferences[0][1] = 0.6;
		userPreferences[0][2] = 0.3;
		userPreferences[0][3] = 0.1;
		
		userPreferences[0][1] = 0.3;
		userPreferences[0][2] = 0.6;
		userPreferences[0][3] = 0.1;
		
		userPreferences[0][1] = 0.3;
		userPreferences[0][2] = 0.1;
		userPreferences[0][3] = 0.6;
		
		return;
	}
	
	public void printUserDistribution() {
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, this.toString());
	}
	
	@Override
	public String toString() {
		return "Users [userDistribution=" + Arrays.toString(userDistribution)
				+ "]";
	}
	
}
