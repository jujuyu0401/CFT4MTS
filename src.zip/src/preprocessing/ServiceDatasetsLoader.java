/**
 * 
 */
package preprocessing;

import java.io.File;
import java.io.IOException;
import weka.core.Instances;
import weka.core.converters.ArffLoader;


/**
 * @author Yanchun Wang
 *
 */
public class ServiceDatasetsLoader {

	/**
	 * 
	 */
	String inputFilePath;
	public ServiceDatasetsLoader(String filePath) {
		// TODO Auto-generated constructor stub
		inputFilePath = filePath;
	}
	
	public Instances getInstances() {
		ArffLoader loader = new ArffLoader();
	    /* Read QWS datasets from specified path */
	    try {
			loader.setSource(new File(inputFilePath));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    /* Read all the instances */
	    Instances resInstances = null;
		try {
			resInstances = loader.getDataSet();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return resInstances;
	}
}
