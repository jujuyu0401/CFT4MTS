package main;

import java.io.File;
import java.util.Arrays;

import log.LogInfo;
import output.ExcelWriter;
import ilog.concert.IloException;
import optimisation.CplexOpt;
import preprocessing.QoSConstraints;
import preprocessing.ServiceSampling;
import preprocessing.Users;
import composition.CompositionPattern;
import composition.CompositionScheme;
import composition.ServiceComposition;
import config.Config;

public class Scheduler {

	public Scheduler() {

	}

	public static void main(String[] args) throws IloException {
		double rtWeight = 0.5;
		double tpWeight = 0.5;
		
		testSuite1(rtWeight, tpWeight, 500);
	}
	
	public static void testSuite1(double rt, double tp, double ftBudget) throws IloException {
		int failureNumber = Config.NUM_FAILURE;
		int runTimes = 100;
		int anomalies = 1;
		ExcelWriter excelWriter = new ExcelWriter();
		for (int b = 1; b <= 1; b++) {
			//output the experimental results to Excel
			excelWriter.newTestCase("Budget" + (int)ftBudget, (int) ftBudget, Config.NUM_TASKS);
			excelWriter.createSheet(Config.NUM_TASKS, anomalies, (int) ftBudget);

			for (int i = 0; i < runTimes; i++) {
				//Service sampling
				ServiceSampling sample = new ServiceSampling();
				sample.generateServiceInstances();
				sample.generateServiceClasses();
				//Generate a service composition randomly
				ServiceComposition composition = new ServiceComposition();
				composition.createCompScheme();
				composition.compScheme.outputSubCompoList(0);
				//Calculate V values for FTCloud
				double ftcCurTime = System.currentTimeMillis();
				composition.calculateV();
				double ftcPreTime = System.currentTimeMillis() - ftcCurTime;
				
				//Allocate tenants in the SBS, overlap considered
				composition.compScheme.setTenantsNum(Config.NUM_TENANTS);
				composition.compScheme.allocateTenants();
				composition.compScheme.generateTenantQoSPrferences(0.25, 0.25);
				composition.allocateFailures(failureNumber);
				composition.instantiate(sample.serviceInstances);
				composition.setServiceClasses(sample.serviceClasses);
				double currentTime = System.currentTimeMillis();
				composition.calculateCandidateServicesUtility();
				composition.generateAggBackupServicesByTopk(Config.NUM_TOP_SERVICES_PER_CLASS);
				double timeStampSgo = System.currentTimeMillis() - currentTime;
				//System.exit(0);
				composition.compScheme.calculateQos();
				composition.calculateUtility();
				double criCurTime = System.currentTimeMillis();
				composition.calCriticalityByResponsetime();
				composition.calCriticalityByThroughput();
				composition.calOverallCriticality();
				double criPreTime = System.currentTimeMillis() - criCurTime;
				QoSConstraints constraints = new QoSConstraints();
				constraints.randomQoSConstraints();
				composition.setConstraints(constraints);
				composition.sortCompSchemesById();
				CplexOpt opt = new CplexOpt(composition);

				composition.clearFailureFlag();
				composition.clearRedundantFlag();

				//time
				composition.sortServicesByCriticality();
				opt.sloveByCriCostConstrainted(ftBudget);
				
				composition.sortCompSchemesById();

				composition.clearRedundantFlag();
				opt.sloveWithoutCriCostConstrainted(ftBudget);

				composition.clearRedundantFlag();
				opt.sloveByFtcCostConstrainted(ftBudget);
				
				if (opt.isHaveSolution() == false) {
					LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Round " + i + " have no solution for CRI then continue to next round");
					continue;
				}
				
				for (int l = 0; l < composition.atomicCompSchemes.size(); l++) {
					composition.clearFailureFlag();
					composition.atomicCompSchemes.get(l).setFailed(true);
					for (int m = 0; m < composition.atomicCompSchemes.get(l).failureNum; m++) {
//						composition.clearRedundantFlag();
//						opt.backupFTCloudCostConstrainted(ftBudget);
						composition.clearRedundantFlag();
						opt.bakcupRandomCostConstrainted(ftBudget);
						
						//opt.printAllFtArray();
					
						//System.out.println("Failed service class: " + composition.atomicCompSchemes.get(l).getId());
						
						if (opt.isHaveSolution()) {
						
							opt.collectDataCri();
							opt.collectDataWCri();
							opt.collectDataFTCloud();
							opt.collectDataRandom();
							
							excelWriter.addRecordOfSuccessRate(
									"S"	+ composition.atomicCompSchemes.get(l).getId() 
									+ "-" + (m + 1)	+ "/" + composition.atomicCompSchemes.get(l).failureNum, 
									opt.getCriSucc(), 
									opt.getWcriSucc(),	
									opt.getFtCloudSucc(),
									opt.getRandomSucc(), 
									opt.getCriSolution(),
									opt.getWcriSolution(), 
									opt.getRandomSolution());
							excelWriter.addRecordOfResponseTime("S" + composition.atomicCompSchemes.get(l).getId()
													+ "-" + m + "/"	+ composition.atomicCompSchemes.get(l).failureNum,
											composition.atomicCompSchemes.get(l).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME],
											composition.atomicCompSchemes.get(l).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME]
													* (Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY-1),
											opt.getCriSucc(),
											opt.getWcriSucc(), 
											opt.getRandomSucc(), 
											opt.getFtCloudSucc(),
											opt.getOriginalRt(),
											opt.getNewCriRT(), 
											opt.getNewWcriRT(), 
											opt.getNewRandomRT(), 
											opt.getNewFtCloudRT(), 
											opt.getCriRtIncr(), 
											opt.getWcriRtIncr(), 
											opt.getRandomRtIncr(), 
											opt.getFtCloudRtIncr(),
											opt.getCriRtIncrP(), 
											opt.getWcriRtIncrP(), 
											opt.getRandomRtIncrP(), 
											opt.getFtCloudRtIncrP());
							
							if (opt.getOriginalTp() == 0) {
								composition.printComposition();
								composition.printAllAtomicCompSchemes();
								System.exit(0);
							}
							excelWriter.addRecordOfThroughput("S" + composition.atomicCompSchemes.get(l).getId()
													+ "-" + m + "/"
													+ composition.atomicCompSchemes.get(l).failureNum,
											composition.atomicCompSchemes.get(l).getServiceInstance().qos[Config.QOS_INDEX_THROUGHPUT],
											composition.atomicCompSchemes.get(l).getServiceInstance().qos[Config.QOS_INDEX_THROUGHPUT]
													* (1 - Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY),
											opt.getCriSucc(),
											opt.getWcriSucc(), 
											opt.getRandomSucc(), 
											opt.getFtCloudSucc(), 
											opt.getOriginalTp(), 
											opt.getNewCriTP(), 
											opt.getNewWcriTP(), 
											opt.getNewRandomTP(), 
											opt.getNewFtCloudTP(),
											opt.getCriTpDecr(), 
											opt.getWcriTpDecr(), 
											opt.getRandomTpDecr(), 
											opt.getFtCloudTpDecr(),
											opt.getCriTpDecrP(), 
											opt.getWcriTpDecrP(), 
											opt.getRandomTpDecrP(), 
											opt.getFtCloudTpDecrP());


							excelWriter.addRecordOfUtility(opt.getCriFtCostEffi(),
									opt.getWcriFtCostEffi(),
									opt.getFtcFtCostEffi(),
									opt.getRandomFtCostEffi());
							excelWriter.addRecordOfAffectedTenant(opt.getCriAffectedTenantPercentage(), 
									opt.getWcriAffectedTenantPercentage(),
									opt.getRandomAffectedTenantPercentage(),
									opt.getFtcAffectedTenantPercentage());
							excelWriter.addRecordOfStrategyGenerationOverhead(timeStampSgo/Config.NUM_TOP_SERVICES_PER_CLASS);
							excelWriter.addRecordOfStrategySelectionOverhead(opt.getCriSso() + criPreTime,
									opt.getWcriSso(),
									opt.getRandomSso(),
									opt.getFtcSso() + ftcPreTime);
						}

					}
				}
			//break;	
			}
			excelWriter.outputResult();
			excelWriter.outputSummary();
		}

		
	}
	public static void testSuite11(double rt, double tp, double ftBudget) throws IloException {
		int failureNumber = 500;
		int runTimes = 50;
		ExcelWriter excelWriter = new ExcelWriter();
		for (int fs=1; fs<=1; fs++) {
			int f = 1*fs;
			ftBudget = 500.0;
			excelWriter.newTestCase("Budget" + (int)f, (int) f, Config.NUM_TASKS);

			excelWriter.createSheet(Config.NUM_TASKS, f, (int) ftBudget);

			for (int i = 0; i < runTimes; i++) {
				ServiceSampling sample = new ServiceSampling();
				sample.generateServiceInstances();
				sample.generateServiceClasses();
				ServiceComposition composition = new ServiceComposition();
				composition.createCompScheme();
				composition.compScheme.outputSubCompoList(0);
				double ftcCurTime = System.currentTimeMillis();
				composition.calculateV();
				double ftcPreTime = System.currentTimeMillis() - ftcCurTime;
				
				composition.compScheme.setTenantsNum(Config.NUM_TENANTS);
				composition.compScheme.allocateTenants();
				composition.compScheme.generateTenantQoSPrferences(rt, tp);
				composition.allocateFailures(failureNumber);
				composition.instantiate(sample.serviceInstances);
				composition.setServiceClasses(sample.serviceClasses);
				double currentTime = System.currentTimeMillis();
				composition.generateAggBackupServicesByTopk(Config.NUM_TOP_SERVICES_PER_CLASS);
				double timeStampSgo = System.currentTimeMillis() - currentTime;
				//System.exit(0);
				composition.compScheme.calculateQos();
				composition.calculateUtility();
				double criCurTime = System.currentTimeMillis();
				composition.calCriticalityByResponsetime();
				composition.calCriticalityByThroughput();
				composition.calOverallCriticality();
				double criPreTime = System.currentTimeMillis() - criCurTime;
				QoSConstraints constraints = new QoSConstraints();
				constraints.randomQoSConstraints();
				composition.setConstraints(constraints);
				composition.sortCompSchemesById();
				CplexOpt opt = new CplexOpt(composition);

				composition.clearFailureFlag();
				composition.clearRedundantFlag();

				//time
				composition.sortServicesByCriticality();
				opt.sloveByCriCostConstrainted(ftBudget);
				
				composition.sortCompSchemesById();

				composition.clearRedundantFlag();
				opt.sloveWithoutCriCostConstrainted(ftBudget);

				if (opt.isHaveSolution() == false) {
					LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Round " + i + " have no solution for CRI then continue to next round");
					continue;
				}



				composition.clearRedundantFlag();
				opt.backupFTCloudCostConstrainted(ftBudget);
				composition.clearRedundantFlag();
				opt.bakcupRandomCostConstrainted(ftBudget);
				
				//opt.printAllFtArray();
				
				composition.clearFailureFlag();
				composition.randomFailure(f);	
				
				if (opt.isHaveSolution()) {
				
					opt.collectDataCriMultiFailure();
					opt.collectDataWCriMultiFailure();
					opt.collectDataRandomMultiFailure();
					opt.collectDataFtcMultiFailure();

					
					excelWriter.addRecordOfSuccessRate(
							"S", 
							opt.getCriSucc(), 
							opt.getWcriSucc(),	
							opt.getFtCloudSucc(),
							opt.getRandomSucc(), 
							opt.getCriSolution(),
							opt.getWcriSolution(), 
							opt.getRandomSolution());
					excelWriter.addRecordOfResponseTime("S",
									0,
									0,
									opt.getCriSucc(),
									opt.getWcriSucc(), 
									opt.getRandomSucc(), 
									opt.getFtCloudSucc(),
									opt.getOriginalRt(),
									opt.getNewCriRT(), 
									opt.getNewWcriRT(), 
									opt.getNewRandomRT(), 
									opt.getNewFtCloudRT(), 
									opt.getCriRtIncr(), 
									opt.getWcriRtIncr(), 
									opt.getRandomRtIncr(), 
									opt.getFtCloudRtIncr(),
									opt.getCriRtIncrP(), 
									opt.getWcriRtIncrP(), 
									opt.getRandomRtIncrP(), 
									opt.getFtCloudRtIncrP());
					
					if (opt.getOriginalTp() == 0) {
						composition.printComposition();
						composition.printAllAtomicCompSchemes();
						System.exit(0);
					}

					excelWriter.addRecordOfUtility(opt.getCriFtCostEffi(),
							opt.getWcriFtCostEffi(),
							opt.getFtcFtCostEffi(),
							opt.getRandomFtCostEffi());
					excelWriter.addRecordOfAffectedTenant(opt.getCriAffectedTenantPercentage(), 
							opt.getWcriAffectedTenantPercentage(),
							opt.getRandomAffectedTenantPercentage(),
							opt.getFtcAffectedTenantPercentage());
					excelWriter.addRecordOfStrategyGenerationOverhead(timeStampSgo);
					excelWriter.addRecordOfStrategySelectionOverhead(opt.getCriSso() + criPreTime,
							opt.getWcriSso(),
							opt.getRandomSso(),
							opt.getFtcSso() + ftcPreTime);
				}

			}
			excelWriter.outputResult();
			
		}
		excelWriter.outputSummary();
	}	
}
