package config;

public class Config {
	public static int NUM_USERS = 500; /*  */
	public static int NUM_USER_CLUSTERS = 3; /* Every cluster has different QoS preferences */
	public static int NUM_TENANTS = 500; /*  */
	public static int NUM_TASKS = 120;
	public static int NUM_SERVICE_CLASSES = NUM_TASKS;
	public static int NUM_SERVICES_PER_CLASS = 50;
	public static int NUM_TOP_SERVICES_PER_CLASS = 4;
	public static int NUM_AGG_SERVICES_PER_CLASS = NUM_TOP_SERVICES_PER_CLASS;
	public static int NUM_QOS = 4;
	public static int NUM_FAILURE = 500;

	public static int QOS_LOWER_BOUND = 0;
	public static int QOS_UPPER_BOUND = 100;
	public static int DIFF_COEFF = 10; //10-100, the higher, the harder
	public static int QOS_CONSTRAINT_LOWER_BOUND = QOS_LOWER_BOUND + DIFF_COEFF;
	public static int QOS_CONSTRAINT_UPPER_BOUND = QOS_UPPER_BOUND;
	public static int QOS_CONSTRAINT_LOWER_BOUND_ACCU = (QOS_LOWER_BOUND + DIFF_COEFF) * NUM_TASKS;
	public static int QOS_CONSTRAINT_UPPER_BOUND_ACCU = QOS_UPPER_BOUND * NUM_TASKS;
	public static double QOS_PREFERENCE_LOWER_BOUND = 0.5;
	public static int MIN_SERVICE_NUM_FOR_CHOICE_PARALLEL = 4;
	public static int MIN_SERVICE_NUM_FOR_SEQUENCE = 1;
	public static int MIN_SUB_COMPOSITION_SCHEME_NUM_FOR_SEQUENCE = 2;
	public static int MAX_SUB_COMPOSITION_SCHEME_NUM_FOR_SEQUENCE = 3;
	public static int MIN_SUB_COMPOSITION_SCHEME_NUM_FOR_CHOICE_PARALLEL = 4;
	public static int MAX_SUB_COMPOSITION_SCHEME_NUM_FOR_CHOICE_PARALLEL = 6;
	
	public static int QOS_INDEX_COST = 0;
	public static int QOS_INDEX_RESPONSETIME = 1;
	public static int QOS_INDEX_RELIABLITY = 2;
	public static int QOS_INDEX_THROUGHPUT = 3;
	public static int QOS_INDEX_UTILITY = 4;
	public static int QOS_INDEX_FTCOST = 5;
	public static int QOS_INDEX_FB = 6;
	
	public static int QOS_MIN_INDEX = 0;
	public static int QOS_MAX_INDEX = 1;
	public static int QOS_MIN_MAX_BOUND = 2;
		
	public static double DEGRADATION_SEVERITY_STEP = 0.2; // 1%
	public static double DEGRADATION_SEVERITY_NEGATIVE_MILD = 2.0; // 2^1
	public static double DEGRADATION_SEVERITY_NEGATIVE_MEDIUM = 4.0; // 2^2
	public static double DEGRADATION_SEVERITY_NEGATIVE_SEVERE = 32.0; // 2^5
	public static double CURRENT_DEGRADATION_NEGATIVE_SEVERITY = 128.0; 
	public static double DEGRADATION_SEVERITY_POSITIVE_MILD = 0.5; // 1/2^1
	public static double DEGRADATION_SEVERITY_POSITIVE_MEDIUM = 0.25; // 1/2^2
	public static double DEGRADATION_SEVERITY_POSITIVE_SEVERE = 0.125; // 1/2^3
	public static double CURRENT_DEGRADATION_POSITIVE_SEVERITY = 0.0;
	
	public static double DEFAULT_FAILURE_PROBABILITY = 0.01;
	public static double DEFAULT_FTCLOUD_V = 1.0;
	public static boolean USE_FT_COST_CONSTRAINT = true;
	//Sum all the service cost directly without multiplying by probability
	public static boolean SUM_COST_WO_PROB = false;
	
	public static int REDUNDANT_MODE_NULL = 0;
	public static int REDUNDANT_MODE_SEQUENTIAL = 1;
	public static int REDUNDANT_MODE_PARALLEL = 2;
}
