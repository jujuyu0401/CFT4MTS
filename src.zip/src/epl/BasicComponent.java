package epl;

import java.util.Arrays;

import configuration.CloudConfig;

public class BasicComponent {
	boolean isViolated;
	public boolean isViolated() {
		return isViolated;
	}

	public void setViolated(boolean isViolated) {
		this.isViolated = isViolated;
	}
	public int[] QoS;
	
	public int[] getQoS() {
		return QoS;
	}

	public void setQoS(int[] qoS) {
		QoS = qoS;
	}

	/* Stub: Hard code for set response time */	
	public void setRT(int rt) {
		QoS[0] = rt;
	}
	int[] relatedES;
	int[] N;
	double[] scdc;
	double scWeight = 1.0;
	int bcId;
	int rank;
	
	public String getBcName() {
		return null;
	}
	
	public double getScWeight() {
		return scWeight;
	}

	public void setScWeight(double scWeight) {
		this.scWeight = scWeight;
	}

	public void calculateSC(double[] ctArray) {
		//System.out.println("N: " + Arrays.toString(this.N));
		double ctTimeForSJ = System.currentTimeMillis();
		this.scdc[Config.IDX_SJ] = ((double)N[Config.IDX_N11] / (N[Config.IDX_N11] + N[Config.IDX_N10] + N[Config.IDX_N01])) * this.scWeight;
		double timeStampForSJ = System.currentTimeMillis() - ctTimeForSJ;
		ctArray[Config.IDX_SJ] += timeStampForSJ;
		
		double ctTimeForST = System.currentTimeMillis();
		if (N[Config.IDX_N11] + N[Config.IDX_N01] == 0 || N[Config.IDX_N10] + N[Config.IDX_N00] == 0) {
			this.scdc[Config.IDX_ST] = 1.0;
		} else {
			this.scdc[Config.IDX_ST] = ((N[Config.IDX_N11] / (N[Config.IDX_N11] + N[Config.IDX_N01])) /
					((double)N[Config.IDX_N11] / (N[Config.IDX_N11] + N[Config.IDX_N01]) + (double)N[Config.IDX_N10] / (N[Config.IDX_N10] + N[Config.IDX_N00])))
					* this.scWeight;
		}
		double timeStampForST = System.currentTimeMillis() - ctTimeForST;
		ctArray[Config.IDX_ST] += timeStampForST;
		
		double ctTimeForSO = System.currentTimeMillis();
		this.scdc[Config.IDX_CO] = (N[Config.IDX_N11] / Math.sqrt((N[Config.IDX_N11] + N[Config.IDX_N01]) * (N[Config.IDX_N11] + N[Config.IDX_N10])))
				* this.scWeight;
		double timeStampForSO = System.currentTimeMillis() - ctTimeForSO;
		ctArray[Config.IDX_CO] += timeStampForSO;
		
		//System.out.println("SC: " + Arrays.toString(this.scdc));
	}
	
	public BasicComponent() {
		this.scdc = new double[Config.NUM_SC+1];
		this.isViolated = false;
		QoS = new int[CloudConfig.NUM_QOS];
	}
	

}
