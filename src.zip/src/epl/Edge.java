package epl;

import configuration.CloudConfig;

public class Edge extends BasicComponent {
	public int edgeId;
	public int sourceNodeId;
	public Service sourceNode;
	public Service targetNode;
	public int targetNodeId;
	public double weight;
//	public int[] QoS;
	
	@Override
	public String getBcName() {
		return "E" + this.edgeId;
	}
	
	public Edge(int sourceServiceId, int targetServiceId, double weight) {
		super();
		this.sourceNodeId = sourceServiceId;
		this.targetNodeId = targetServiceId;
		this.weight = weight;
		//QoS = new int[CloudConfig.NUM_QOS];
	}
	public Edge(int sourceServiceId, int targetServiceId, double weight, int[] qos) {
		super();
		this.sourceNodeId = sourceServiceId;
		this.targetNodeId = targetServiceId;
		this.weight = weight;
		QoS = qos;
		this.scdc = new double[Config.NUM_SC];
	}
	public int getEdgeId() {
		return edgeId;
	}
	public void setEdgeId(int edgeId) {
		this.edgeId = edgeId;
	}
	public int getSourceNodeId() {
		return sourceNodeId;
	}
	public void setSourceNodeId(int sourceNodeId) {
		this.sourceNodeId = sourceNodeId;
	}
	public int getTargetNodeId() {
		return targetNodeId;
	}
	public void setTargetNodeId(int targetNodeId) {
		this.targetNodeId = targetNodeId;
	}
	public Service getSourceNode() {
		return sourceNode;
	}
	public void setSourceNode(Service sourceNode) {
		this.sourceNode = sourceNode;
	}
	public Service getTargetNode() {
		return targetNode;
	}
	public void setTargetNode(Service targetNode) {
		this.targetNode = targetNode;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
//	public int[] getQoS() {
//		return QoS;
//	}
//	public void setQoS(int[] qoS) {
//		QoS = qoS;
//	}
//	/* Stub: Hard code for set response time */	
//	public void setRT(int rt) {
//		QoS[0] = rt;
//	}
}
