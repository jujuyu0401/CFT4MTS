package epl;

import java.util.ArrayList;
import java.util.Arrays;

public class ExecutionPlan extends BaseComposition{
	public int[] pathArray;
	public ExecutionPlan(int pathCount) {
		super();
		pathArray = new int[pathCount];
	}
	
	public ExecutionPlan() {
		super();
	}

	public void addPath(int pathId) {
		if (pathId >= this.pathArray.length) {
			System.out.println("Invalid path...");
			return;
		}
		
		this.pathArray[pathId] = 1;
	}
	
	public boolean isDuplicatePlan(ExecutionPlan scenario) {
		if (scenario.services.size() != this.services.size()) {
			return false;
		}
		for (int i=0; i<scenario.services.size(); i++) {
			if (!isServiceExist(scenario.services.get(i).getServiceId())) {
				return false;
			}
		}
		return true;
	}
	
	public void display() {
		this.buildComposition();
		System.out.println("Aggregation QoS: " + Arrays.toString(services.get(0).getAggQos()));
		System.out.println("Services: ");
		for (int i=0; i<services.size(); i++) {
			System.out.println("Service " + services.get(i).getServiceId() + ", RT = " + services.get(i).getQoS()[0]);
		}
		System.out.println("Edges: ");
		for (int i=0; i<edges.size(); i++) {
			System.out.println("Edge: Source = Service " + edges.get(i).getSourceNode().getServiceId() + 
					", Target = Service " + edges.get(i).targetNodeId + 
					", Weight = " + edges.get(i).weight + ", RT = " + edges.get(i).getQoS()[0]);
		}
	}
}
