package epl;

import java.util.ArrayList;
/**
 * The super class of ExecutionComposition, ExecutionPath, and ExecutionScenario
 * All of them are composed with services and edges
 * @author juanzhou
 *
 */
public class BaseComposition {

	public BaseComposition() {
		services = new ArrayList<Service>();
		edges = new ArrayList<Edge>();
	}

	/* Node and edge in a composition mean the service and transition respectively */
	public ArrayList<Service> services;
	public ArrayList<Edge> edges;

	public ArrayList<Service> getServices() {
		return services;
	}
	
	public void setServices(ArrayList<Service> services) {
		this.services = services;
	}
	
	public ArrayList<Edge> getEdges() {
		return edges;
	}
	
	public void setEdges(ArrayList<Edge> edges) {
		this.edges = edges;
	}
	
	public void addService(Service node) {
		services.add(node);
	}
	
	public void addEdge(Edge edge) {
		edges.add(edge);
	}
	
	/* Build the composition of services and edges  */
	public void buildComposition() {
		for (int i=0; i<services.size(); i++) {
			int serviceId = services.get(i).serviceId;
			services.get(i).createNewBranchList();
			//System.out.println("Generate branches for node " + serviceId);
			/* Each service has its branches */
			for (int j=0; j<edges.size(); j++) {
				if (edges.get(j).getSourceNode().getServiceId() == serviceId) {
					services.get(i).addBranch(edges.get(j));
				}
			}
		}		
	}
	/* This is used to calculate the aggregation QoS of composition, 
	 * including ExecutionComposition, ExecutionPath and ExecutionScenario,
	 * Before use this method, the function buildComposition must be 
	 * called to create the composition structure
	 */
	public int[] getAggQos() {
		int[] rstQos = new int[Config.NUM_QOS];
		
		return rstQos;
	}
	
	
	public Service getServiceById(int id) {
		Service service = null;
		for (int i=0; i<services.size(); i++) {
			if (services.get(i).serviceId == id) {
				service = services.get(i);
				break;
			}
		}
		return service;
	}
	public boolean isContain(int serviceId) {
		for (int i=0; i<services.size(); i++) {
			if (services.get(i).getServiceId() == serviceId) {
				return true;
			}
		}
		return false;
	}
	
	public void addServiceByList(ArrayList<Service> servicesList) {
		for (int i=0; i<servicesList.size(); i++) {
			if (!isServiceExist(servicesList.get(i).getServiceId())) {
				addService(servicesList.get(i));
			}
		}
	}

	public void addEdgeByList(ArrayList<Edge> edgesList) {
		for (int i=0; i<edgesList.size(); i++) {
			if (!isEdgeExist(edgesList.get(i).getSourceNode().getServiceId(), edgesList.get(i).getTargetNode().getServiceId())) {
				addEdge(edgesList.get(i));
			}
		}
		
	}
	
	public boolean isServiceExist(int serviceId) {
		for (int i=0; i<services.size(); i++) {
			if (serviceId == services.get(i).getServiceId()) {
				return true;
			}
		}
		return false;
	}
	public boolean isEdgeExist(int sourceId, int targetId) {
		for (int i=0; i<edges.size(); i++) {
			if (edges.get(i).getSourceNode().getServiceId() == sourceId 
					&& edges.get(i).getTargetNode().getServiceId() == targetId) {
				return true;
			}
		}
		return false;
	}
	public boolean isEdgeExist(int edgeId) {
		for (int i=0; i<edges.size(); i++) {
			if (edges.get(i).edgeId == edgeId) {
				return true;
			}
		}
		return false;
	}

}
