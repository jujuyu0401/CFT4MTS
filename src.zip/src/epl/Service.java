package epl;

import java.util.ArrayList;
import java.util.Arrays;

import configuration.CloudConfig;

public class Service extends BasicComponent {

	public Service(int serviceId) {
		this.serviceId = serviceId;
		
		paths = new ArrayList<ExecutionPath>();
		branchPathsList = new ArrayList<ArrayList<Integer>>();
		QoS = new int[CloudConfig.NUM_QOS];
	}
	public ArrayList<Edge> branches;
	
	public ArrayList<ExecutionPath> paths;
	
	public ArrayList<ArrayList<Integer>> branchPathsList; 
	
	@Override
	public String getBcName() {
		return "N" + this.serviceId;
	}
	public boolean traversed = false;	
	public int serviceId;
	
	public int getServiceId() {
		return serviceId;
	}

	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	
	public void createNewBranchList() {
		branches = new ArrayList<Edge>();
	}

	
	public void addBranch(Edge edge) {
		this.branches.add(edge);
	}
	
	/* This function is used to add service and edge to the paths of current service
	 * Backtrack method is used when build paths for a composition
	 * all the paths stored in a service are the paths from the service to the end point */
	public void addServiceAndEdgeToPath(Service service, Edge edge) {
		//System.out.println("Add node to path: self id is " + this.serviceId + ", next node id is " + service.serviceId);
		
		if (0 == service.paths.size()) {
			ExecutionPath path = new ExecutionPath();
			path.addService(this);
			path.addService(service);
			path.addEdge(edge);
			this.paths.add(path);
		} else {
			for (int i=0; i<service.paths.size(); i++) {
				ExecutionPath path = new ExecutionPath();
				path.addService(this);
				path.addServiceByList(service.paths.get(i).services);							
				path.addEdgeByList(service.paths.get(i).edges);
				path.addEdge(edge);
				this.paths.add(path);
			}
		}
		
//		for (int i=0; i<this.paths.size(); i++) {
//			this.paths.get(i).display();
//		}
	}
	
	/* Build the policies used for matching path combinations 
	 * to identify valid execution scenario */
	public void traverseForPolicy(ArrayList<ExecutionPath> pathList, 
			ArrayList<int[]> conflictList, ArrayList<ArrayList<int[]>> coccurrentList, int pathCount) {
		if (!traversed) {
			System.out.println("Traverse nodes for matching rules: node "
					+ this.serviceId);
			this.branchPathsList.removeAll(this.branchPathsList);
			int branchCount = this.branches.size();
			if (branchCount > 1) {
				for (int i = 0; i < this.branches.size(); i++) {
					ArrayList<Integer> pathListForEachBranch = new ArrayList<Integer>();
					int serviceId = this.branches.get(i).getTargetNode().serviceId;
					for (int j = 0; j < pathList.size(); j++) {
						if (pathList.get(j).isContain(serviceId)) {
							pathListForEachBranch.add(pathList.get(j)
									.getPathId());
							System.out.println("Add path "
									+ pathList.get(j).getPathId()
									+ " into set " + i);
						}
					}
					this.branchPathsList.add(pathListForEachBranch);
				}
			}
			/* Branch compositional pattern */
			if (branchCount > 1 && this.branches.get(0).weight != 1.0) {
				for (int i = 0; i < this.branchPathsList.size(); i++) {
					ArrayList<Integer> firstSet = this.branchPathsList.get(i);
					for (int j = 0; j < firstSet.size(); j++) {
						int firstPathId = firstSet.get(j);
						for (int k = i + 1; k < this.branchPathsList.size(); k++) {
							for (int l = 0; l < this.branchPathsList.get(k)
									.size(); l++) {
								int secondPathId = this.branchPathsList.get(k)
										.get(l);
								int[] comb = new int[pathCount];
								comb[firstPathId] = 1;
								comb[secondPathId] = 1;
								conflictList.add(comb);
								System.out
										.println("Generate conflict matching rule: path "
												+ firstPathId
												+ " and path "
												+ secondPathId);
							}
						}
					}
				}
			} else if (branchCount > 1 && this.branches.get(0).weight == 1.0) { // Parallel
																				// compositional
																				// pattern
				ArrayList<Integer> rst = new ArrayList<Integer>();
				ArrayList<int[]> tmpList = new ArrayList<int[]>();
				getCoccurrentList(pathCount, 0, rst, tmpList);
				coccurrentList.add(tmpList);
			}
			
			traversed = true;
		}
		
		for (int i=0; i<this.branches.size(); i++) {
			this.branches.get(i).getTargetNode().traverseForPolicy(pathList, conflictList, coccurrentList, pathCount);
		}
	}
	
	public void getCoccurrentList(int pathCount, int curListIndex, ArrayList<Integer> rstList, ArrayList<int[]> coccurrentList) {
		for (int i=0; i<this.branchPathsList.get(curListIndex).size(); i++) {
			int pathId = this.branchPathsList.get(curListIndex).get(i).intValue();
			rstList.add(pathId);
			if (curListIndex != this.branches.size()-1) {
				getCoccurrentList(pathCount, curListIndex+1, rstList, coccurrentList);
			} else {
				int[] comb = new int[pathCount];
				for (int j=0; j<rstList.size(); j++) {
					comb[rstList.get(j).intValue()] = 1;
				}
				coccurrentList.add(comb);
			}
			rstList.remove(rstList.size()-1);
		}
	}
	
	/* Hard code for response time calculation */
	public int[] getAggQos() {
		int[] qos = new int[Config.NUM_QOS];
		if (this.branches.size() > 0) {
			qos[0] = this.QoS[0] + this.branches.get(0).getQoS()[0] + this.branches.get(0).getTargetNode().getAggQos()[0];
			for (int i=1; i<this.branches.size(); i++) {
				if (qos[0] > this.QoS[0] + this.branches.get(i).getQoS()[0] + this.branches.get(i).getTargetNode().getAggQos()[0]) {
					qos[0] = this.QoS[0] + this.branches.get(i).getQoS()[0] + this.branches.get(i).getTargetNode().getAggQos()[0];
				}
			}			
		} else {
			qos[0] = this.QoS[0];
		}

		return qos;
	}
}
