package epl;

public class Statistics {
	int scType;
	int esNum;
	int round;
	double eff;
	
	public Statistics(int scType) {
		this.scType = scType;
	}
	public int getScType() {
		return scType;
	}
	public void setScType(int scType) {
		this.scType = scType;
	}
	public int getEsNum() {
		return esNum;
	}
	public void setEsNum(int esNum) {
		this.esNum = esNum;
	}
	public int getRound() {
		return round;
	}
	public void setRound(int round) {
		this.round = round;
	}
	public double getEff() {
		return eff;
	}
	public void setEff(double eff) {
		this.eff = eff;
	}
}
