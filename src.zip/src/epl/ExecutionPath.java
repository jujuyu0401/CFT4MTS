package epl;

import java.util.ArrayList;
import java.util.Arrays;

public class ExecutionPath extends BaseComposition {

	public ExecutionPath() {
		super();
	}
	
	public int pathId;
	
	public int getPathId() {
		return pathId;
	}

	public void setPathId(int pathId) {
		this.pathId = pathId;
	}
	
	public int[] pathCombination;

	
	public void initPathCombination(int pathCount) {
		this.pathCombination = new int[pathCount];
		//this.pathCombination[this.pathId] = 1;
	}	
	public double getPathRt() {
		double rt = 0;
		for (int i=0; i<services.size(); i++) {
			rt +=  services.get(i).getQoS()[0];
		}
		for (int i=0; i<edges.size(); i++) {
			rt += edges.get(i).getQoS()[0];
		}
		
		return rt;
	}
	public void display() {
		System.out.println("PathId: " + this.pathId);
		System.out.println("QoS: " + Arrays.toString(this.services.get(0).getAggQos()));
		System.out.println("Services: ");
		for (int i=0; i<services.size(); i++) {
			System.out.println("Service " + services.get(i).getServiceId());
		}
		System.out.println("Edges: ");
		for (int i=0; i<edges.size(); i++) {
			System.out.println("Edge " + edges.get(i).edgeId + ": Source = Service " + edges.get(i).getSourceNode().getServiceId() + 
					", Target = Service " + edges.get(i).targetNodeId + 
					", Weight = " + edges.get(i).weight);
		}
	}
}
