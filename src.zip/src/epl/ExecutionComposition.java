package epl;

import java.util.ArrayList;
import java.util.Arrays;
/**
 * This is the main composition to be decomposed to execution scenarios
 * @author juanzhou
 *
 */
public class ExecutionComposition extends BaseComposition {
	
	/* The combinations of paths */
	public ArrayList<int[]> pathCombinations;

	/* The policies are used to filter out the invalid path combination */
	public ArrayList<ArrayList<int[]>> coccurrentPolicy = new ArrayList<ArrayList<int[]>>();
	public ArrayList<int[]> conflictPolicy = new ArrayList<int[]>();
	
	/* The set of valid service scenarios, including the ones that might be overlap or duplicate */
	public ArrayList<int[]> candiateScenarios;
	
	/* The final set of service scenarios after filtering and merging */
	public ArrayList<ExecutionPlan> scenarios;
	
	public ExecutionComposition() {
		super();
		scenarios = new ArrayList<ExecutionPlan>();
		pathCombinations = new ArrayList<int[]>();
		coccurrentPolicy = new ArrayList<ArrayList<int[]>>();
		conflictPolicy = new ArrayList<int[]>();
		candiateScenarios = new ArrayList<int[]>();
	}
	
	public void addScenario(ExecutionPlan scenario) {
		scenarios.add(scenario);
	}
		
	/* ExecuteNode.paths using backtrack method */
	public void buildPaths() {
		for (int i=services.size()-1; i>=0; i--) {
			Service node = services.get(i);
			int serviceId = node.serviceId;
			for (int j=0; j<edges.size(); j++) {
				if (edges.get(j).getTargetNode().getServiceId() == serviceId) {
					Service sourceNode = edges.get(j).getSourceNode();
				    sourceNode.addServiceAndEdgeToPath(node, edges.get(j));
				}
			}
		}
		for (int i=0; i<this.services.get(0).paths.size(); i++) {
			this.services.get(0).paths.get(i).setPathId(i);
		}
	}
	
	/* this.coccurrentPolicy & this.conflictPolicy */
	public void createPolicy() {
		int pathCount = this.services.get(0).paths.size();
		this.coccurrentPolicy = new ArrayList<ArrayList<int[]>>();
		this.conflictPolicy = new ArrayList<int[]>();
		
		this.services.get(0).traverseForPolicy(this.services.get(0).paths, conflictPolicy, coccurrentPolicy, pathCount);
		
		System.out.println("Conflict list: ");
		displayPathArrays(conflictPolicy);
		
		System.out.println("Coccurrent list: ");
		
		for (int i=0; i<this.coccurrentPolicy.size(); i++) {
			System.out.println("The " + i + "th set parallel rules: ");
			displayPathArrays(coccurrentPolicy.get(i));
		}		
	}
	
	/* this.pathCombinations */
	public void buildPathCombinations() {
		int pathCount = this.services.get(0).paths.size();
		int[] pathIdArray = new int[pathCount];
		for (int i=0; i<pathCount; i++) {
			pathIdArray[i] = i;
		}	
		
		getPathCombinations(pathIdArray);
		System.out.println("The path combination: ");
		displayPathArrays(this.pathCombinations);		
	}
	
	public void parseScenarios() {		
		int validCnt = 0;
		int invalidCnt = 0;
		for (int i=0; i<this.pathCombinations.size(); i++) {
			if (isValidPathCombination(this.pathCombinations.get(i))) {
				System.out.println("Found scenario");
				
				boolean isOverlap = false;
				
				for (int j=0; j<this.candiateScenarios.size(); j++) {
					if (isOverlap(this.pathCombinations.get(i), this.candiateScenarios.get(j))) {
						isOverlap = true;
					}
				}
				/* Overlap: for example, {path0, path1} and {path0, path1, path2} */
				if (!isOverlap) {
					this.candiateScenarios.add(this.pathCombinations.get(i));
					ExecutionPlan scenario = new ExecutionPlan();
					for (int k=0; k<this.pathCombinations.get(i).length; k++) {
						if (1 == this.pathCombinations.get(i)[k]) {
							scenario.addServiceByList(this.services.get(0).paths.get(k).services);
							scenario.addEdgeByList(this.services.get(0).paths.get(k).edges);
						}
					} 
					if (!isDupScenario(scenario)) {
						//scenario.buildComposition();
						this.scenarios.add(scenario);
					}
										
				}

				validCnt++;
			} else {
				System.out.println("Not a valid scenario: " + i + ": " + Arrays.toString(this.pathCombinations.get(i)));
				invalidCnt++;
			}
		}
			
		System.out.println("Total combination count: " + this.pathCombinations.size() + ", valid: " + validCnt + 
				", invlaid cnt: " + invalidCnt + ", after merge scenario count: " + this.scenarios.size());
	}
	
	public boolean isOverlap(int[] comb1, int[] comb2) {
		int[] temp = new int[comb1.length];
		for (int i=0; i<comb1.length; i++) {
			temp[i] = comb1[i] & comb2[i];
		}
		
		if (Arrays.equals(temp, comb2)) {
			return true;
		}
		
		return false;
	}
	
	public boolean isDupScenario(ExecutionPlan scenario) {
		for (int i=0; i<this.scenarios.size(); i++) {
			if (scenario.isDuplicatePlan(this.scenarios.get(i))) {
				return true;
			}
		}
		return false;
	}
	public boolean isValidPathCombination(int[] comb) {

		if (!isValidBranchPathes(comb)) {
			System.out.println("Not comply with conflict rule");
			return false;
		}

		if (!isValidParallelPathes(comb)) {
			System.out.println("Not comply with parallel rule");
			return false;
		}
			
		return true;
	}

	public boolean isValidParallelPathes(int[] comb) {

		for (int k=0; k<this.coccurrentPolicy.size(); k++) {
			boolean isInvolved = false;
			boolean isFoundMatchRule = false;
			
			for (int i=0; i<this.coccurrentPolicy.get(k).size(); i++) {
				int[] parallelRule = this.coccurrentPolicy.get(k).get(i);
				int[] blankArray = new int[comb.length];
				int[] tempArray = new int[comb.length];
				
				for (int j=0; j<comb.length; j++) {
					blankArray[j] = 0;
					tempArray[j] = comb[j] & parallelRule[j];
				}
				/* For example: 
				 * Assume this scenario is {1, 0, 0, 0}, indicating only path0 in it, 
				 * while one of the parallel path combination is {0, 1, 1, 0}, it means path1 and path2 must in the same scenario
				 * So {1, 0, 0, 0} & {0, 1, 1, 0} = {0, 0, 0, 0}, this scenario might be valid
				 * if this scenario is {1, 1, 1, 0}, then {1, 1, 1, 0} & {0, 1, 1, 0} = {0, 1, 1, 0}
				 * this scenario also might be valid  */
				System.out.println("comb: " + Arrays.toString(comb) + " & parallelRule: " + Arrays.toString(parallelRule) + 
						" = " + Arrays.toString(tempArray));
				
				if (!Arrays.equals(tempArray, blankArray)) {
					isInvolved = true;
				}
				if (Arrays.equals(tempArray, parallelRule)) {
					isFoundMatchRule = true;
					break;
				}
			}
			if (isInvolved && !isFoundMatchRule) {
				return false;
			}
			
			
		}
		/* !isInvolved */
		return true;
	}
	
	public boolean isValidBranchPathes(int[] comb) {
		for (int i=0; i<this.conflictPolicy.size(); i++) {
			int[] conflictRule = this.conflictPolicy.get(i);
			int[] tempArray = new int[comb.length];
			
			for (int j=0; j<comb.length; j++) {
				tempArray[j] = comb[j] & conflictRule[j];
			}
			
			/* For example: 
			 * Assume this scenario is {1, 0, 0, 0}, indicating only path0 in it, 
			 * while one of the branch path combination is {0, 1, 1, 0}, it means path1 and path2 must NOT in the same scenario
			 * So {1, 0, 0, 0} & {0, 1, 1, 0} = {0, 0, 0, 0}, this scenario MIGHT be valid
			 * if this scenario is {1, 1, 1, 0}, then {1, 1, 1, 0} & {0, 1, 1, 0} = {0, 1, 1, 0}
			 * this scenario MUST be INVALID  */
			
			System.out.println("comb: " + Arrays.toString(comb) + " & conflictRule: " + Arrays.toString(conflictRule) + 
					" = " + Arrays.toString(tempArray));
			
			if (Arrays.equals(tempArray, conflictRule)) {
				System.out.println("Not comply with conflictRule, invalid path combination");
				return false;
			}
		}
			
		return true;
	}


	public void getPathCombinations(int[] pathIdArray) {
		Permutations permu = new Permutations();
		for (int i=1; i<=pathIdArray.length; i++) {
			ArrayList<int[]> combinationList = permu.combine(pathIdArray, i);
			for (int j=0; j<combinationList.size(); j++) {
				int[] comb = new int[pathIdArray.length];
				for (int k=0; k<combinationList.get(j).length; k++) {
					comb[combinationList.get(j)[k]] = 1;
				}
				this.pathCombinations.add(comb);
			}
			
		}
	}
	
	public void displayScenarios() {
		for (int i=0; i<scenarios.size(); i++) {
			System.out.println("************************************************************************");
			System.out.println("Scenario " + i + ": ");
			scenarios.get(i).display();
		}
	}
	
	public void displayPaths() {
		for (int i=0; i<this.services.get(0).paths.size(); i++) {
			this.services.get(0).paths.get(i).buildComposition();
			this.services.get(0).paths.get(i).display();
		}
	}
	public void displayPathArrays(ArrayList<int[]> list) {
		
		for (int i=0; i<list.size(); i++) {
			System.out.println(Arrays.toString(list.get(i)));
		}
	}
}
