/**
 * 
 */
package composition;

import ilog.concert.IloNumExpr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;

import preprocessing.QoSConstraints;
import preprocessing.Users;
import log.LogInfo;
import services.AggregateService;
import services.Permutations;
import services.Service;
import services.ServiceClass;
import config.Config;
import edge.Edge;

/**
 * @author Yanchun Wang
 *
 */
public class ServiceComposition {

	/**
	 * 
	 */
	public CompositionScheme compScheme;
	public ArrayList<CompositionScheme> atomicCompSchemes;
	public ArrayList<Edge> edges;
	public ArrayList<ExecutionPath> executionPaths;
	public ServiceClass sc;
	public int aggregateServiceNumPerClass = 0;
	public QoSConstraints constraints;
	public Users users;
	public int[] failServices = new int[Config.NUM_SERVICE_CLASSES];
	public int[] penalty = new int[Config.NUM_SERVICE_CLASSES];
	public double[][] minAndMaxAggQoS = new double[Config.NUM_QOS][Config.QOS_MIN_MAX_BOUND];
	
	public double[] originalQoS = new double[Config.NUM_QOS];
	public double maxEpResponsetime = 0;
	public double minEpResponsetime = 0;
	public double maxThroughput = 0;
	public double minThroughput = 0;
	public double minRtSa = 0;
	public double maxRtSa = 0;
	public double minTpSa = 0;
	public double maxTpSa = 0;
	
	

	public ServiceComposition() {
		atomicCompSchemes = new ArrayList<CompositionScheme>();
		edges = new ArrayList<Edge>();
		executionPaths = new ArrayList<ExecutionPath>();
		initMinAndMaxQoS();
	}
	
	public CompositionScheme findSchemebyId(int id) {
		CompositionScheme sche = null;
		for (int i=0; i<atomicCompSchemes.size(); i++) {
			if (atomicCompSchemes.get(i).id == id) {
				sche = atomicCompSchemes.get(i);
				return sche;
			}
		}
		return sche;
	}
	
	public void calculateV() {
		atomicCompSchemes.get(0).V = 1.0;
		for (int i=1; i<atomicCompSchemes.size(); i++) {
			double imp = 0;
			for (int j=0; j<edges.size(); j++) {
				if (edges.get(j).target == atomicCompSchemes.get(i).id) {

					CompositionScheme sche = findSchemebyId(edges.get(j).source);
					//System.out.println("calculateV: edges.get("+j+").source is " + edges.get(j).source + ", weight is " +
				//edges.get(j).weight + ", source V is " + sche.V);
					imp+= (sche.V * edges.get(j).weight);
				}
			}
			atomicCompSchemes.get(i).V = 0.15/Config.NUM_SERVICE_CLASSES + 0.85 * imp;
			
			//System.out.println("S" + atomicCompSchemes.get(i).getId() + " V is " + atomicCompSchemes.get(i).V);
		}
	}
	
	Comparator<CompositionScheme> comparatorV = new Comparator<CompositionScheme>(){
		   @Override
		public int compare(CompositionScheme cs1, CompositionScheme cs2) {
			   if (cs1.V < cs2.V) {
				   return 1;
			   } else {
				   return -1;
			   }
		   }
	};	
	
	public void sortServicesByV() {
		Collections.sort(atomicCompSchemes,comparatorV);
//		for (int i=0; i<atomicCompSchemes.size(); i++) {
//			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "S" + atomicCompSchemes.get(i).getId() + ", criticality = " + atomicCompSchemes.get(i).overallCriticality);
//		}
		return;
	}
	
	public void printV() {
		for (int i=0; i<atomicCompSchemes.size(); i++) {
			System.out.println("V of S" + atomicCompSchemes.get(i).getId() + ": V = " + atomicCompSchemes.get(i).V);
		}
	}
 	public void initMinAndMaxQoS() {
		for (int i=0; i<Config.NUM_QOS; i++) {
			minAndMaxAggQoS[i][Config.QOS_MIN_INDEX] = Config.QOS_UPPER_BOUND;
			minAndMaxAggQoS[i][Config.QOS_MAX_INDEX] = Config.QOS_LOWER_BOUND;
		}
	}
	public void createCompScheme() {
		compScheme = new CompositionScheme(CompositionPattern.SEQUENCE, Config.NUM_TASKS, 0);
		compScheme.setName("root");
		compScheme.genSubCompositionSchema();
		compScheme.extractAtomicCompositionSchemes(atomicCompSchemes);
		compScheme.extractEdges(edges);
	}
	
	public void generateTenantsSharing() {
		
		return;
	}
	
	
	public QoSConstraints getConstraints() {
		return constraints;
	}

	public void setOriginalQoS(double[] qos) {
		for (int i=0; i<Config.NUM_QOS; i++) {
			this.originalQoS[i] = qos[i];
		}
	}
	public void setConstraints(QoSConstraints constraints) {
		this.constraints = constraints;
	}

	public void instantiate(Service[] instanceServices) {
		if (instanceServices.length != atomicCompSchemes.size()) {
			LogInfo.logInfo(LogInfo.LOGLEVEL_WARNNING, "Invalid candidate services array: Length error");
			return;
		}
		
		for (int i=0; i<instanceServices.length; i++) {
			atomicCompSchemes.get(i).setServiceInstance(instanceServices[i]);
			atomicCompSchemes.get(i).setCompServiceInstance(instanceServices[i]);
			for (int k=0; k<Config.NUM_QOS; k++) {
				if (minAndMaxAggQoS[k][Config.QOS_MIN_INDEX] > instanceServices[i].getQos()[k]) {
					minAndMaxAggQoS[k][Config.QOS_MIN_INDEX] = instanceServices[i].getQos()[k];
				} else if (minAndMaxAggQoS[k][Config.QOS_MAX_INDEX] < instanceServices[i].getQos()[k]) {
					minAndMaxAggQoS[k][Config.QOS_MAX_INDEX] = instanceServices[i].getQos()[k];
				}
				
			}
		}
		
		return;
	}
	
	public void setServiceClasses(ServiceClass[] serviceClasses) {
		for (int i=0; i<Config.NUM_SERVICE_CLASSES; i++) {
			atomicCompSchemes.get(i).setSc(serviceClasses[i]);
		}
	}
	
	public void generateAggBackupServicesByTopk(int k) {
		//sorting the candidate services by utility first
		//Aggregating the top k services for fault tolerance strategies
		for (int i=0; i<atomicCompSchemes.size(); i++) {
			atomicCompSchemes.get(i).getSc().generateAggregateServicesByTopk(atomicCompSchemes.get(i).getServiceInstance(), minAndMaxAggQoS, k);
		}
		setAggregateServiceNumPerClass(atomicCompSchemes.get(0).getSc().aggServiceNum);		
		//System.out.println("Inspection: Number of generated aggregated services by topk is " + atomicCompSchemes.get(0).getSc().aggServiceNum);
	}
	
	public void printAllAggServices() {
		for (int j=0; j<atomicCompSchemes.size(); j++) {
			System.out.println("Service class " + atomicCompSchemes.get(j).id);
			for (int i=0; i<atomicCompSchemes.get(j).getSc().aggServiceNum; i++) {
				System.out.println("Service " + atomicCompSchemes.get(j).sc.aggServiceList.get(i).servicdId +
						", qos=" + Arrays.toString(atomicCompSchemes.get(j).sc.aggServiceList.get(i).qos) +
						", utility=" + atomicCompSchemes.get(j).sc.aggServiceList.get(i).utility);
			}			
		}

	}
	public void generateAggBackupServices() {
		for (int i=0; i<atomicCompSchemes.size(); i++) {
			atomicCompSchemes.get(i).getSc().generateAggregateServices(atomicCompSchemes.get(i).getServiceInstance(), minAndMaxAggQoS);
		}
		setAggregateServiceNumPerClass(atomicCompSchemes.get(0).getSc().aggServiceNum);
		System.out.println("Inspection: Number of generated aggregated services without topk is " + atomicCompSchemes.get(0).getSc().aggServiceNum);

		
//		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Max and Min QOS: ");
//		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Cost: Max(" + minAndMaxQoS[Config.QOS_INDEX_COST][Config.QOS_MAX_INDEX] + "), Min(" + + minAndMaxQoS[Config.QOS_INDEX_COST][Config.QOS_MIN_INDEX] + ")");
//		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Reliability: Max(" + minAndMaxQoS[Config.QOS_INDEX_RELIABLITY][Config.QOS_MAX_INDEX] + "), Min(" + + minAndMaxQoS[Config.QOS_INDEX_RELIABLITY][Config.QOS_MIN_INDEX] + ")");
//		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Throughput: Max(" + minAndMaxQoS[Config.QOS_INDEX_THROUGHPUT][Config.QOS_MAX_INDEX] + "), Min(" + + minAndMaxQoS[Config.QOS_INDEX_THROUGHPUT][Config.QOS_MIN_INDEX] + ")");
//		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "ResponseTime: Max(" + minAndMaxQoS[Config.QOS_INDEX_RESPONSETIME][Config.QOS_MAX_INDEX] + "), Min(" + + minAndMaxQoS[Config.QOS_INDEX_RESPONSETIME][Config.QOS_MIN_INDEX] + ")");
	}
	
	public void calculateUtility() {
		double normalisedCt;
		double normalisedRe;
		double normalisedTp;
		double normalisedRt;
		
		for (int i=0; i<this.atomicCompSchemes.size(); i++) {
			//calculate instance service utility
			normalisedCt = (double)(this.minAndMaxAggQoS[Config.QOS_INDEX_COST][Config.QOS_MAX_INDEX] - this.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_COST])
					/ (this.minAndMaxAggQoS[Config.QOS_INDEX_COST][Config.QOS_MAX_INDEX] - minAndMaxAggQoS[Config.QOS_INDEX_COST][Config.QOS_MIN_INDEX]);
			normalisedRe = (double)(this.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RELIABLITY] - this.minAndMaxAggQoS[Config.QOS_INDEX_RELIABLITY][Config.QOS_MIN_INDEX])
					/ (this.minAndMaxAggQoS[Config.QOS_INDEX_RELIABLITY][Config.QOS_MAX_INDEX] - minAndMaxAggQoS[Config.QOS_INDEX_RELIABLITY][Config.QOS_MIN_INDEX]);
			normalisedTp = (double)(this.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_THROUGHPUT] - this.minAndMaxAggQoS[Config.QOS_INDEX_THROUGHPUT][Config.QOS_MIN_INDEX])
					/ (this.minAndMaxAggQoS[Config.QOS_INDEX_THROUGHPUT][Config.QOS_MAX_INDEX] - minAndMaxAggQoS[Config.QOS_INDEX_THROUGHPUT][Config.QOS_MIN_INDEX]);
			normalisedRt = (double)(this.minAndMaxAggQoS[Config.QOS_INDEX_RESPONSETIME][Config.QOS_MAX_INDEX] - this.atomicCompSchemes.get(i).getServiceInstance().qos[Config.QOS_INDEX_RESPONSETIME])
					/ (this.minAndMaxAggQoS[Config.QOS_INDEX_RESPONSETIME][Config.QOS_MAX_INDEX] - minAndMaxAggQoS[Config.QOS_INDEX_RESPONSETIME][Config.QOS_MIN_INDEX]);
			for (int j=0; j<this.atomicCompSchemes.get(i).getTenantsNum(); j++) {
				this.atomicCompSchemes.get(i).getServiceInstance().utility += 
						normalisedCt * this.atomicCompSchemes.get(i).tenantQoSPreferences[j][Config.QOS_INDEX_COST]
					    + normalisedRe * this.atomicCompSchemes.get(i).tenantQoSPreferences[j][Config.QOS_INDEX_RELIABLITY]
					    + normalisedTp * this.atomicCompSchemes.get(i).tenantQoSPreferences[j][Config.QOS_INDEX_THROUGHPUT]
					    + normalisedRt * this.atomicCompSchemes.get(i).tenantQoSPreferences[j][Config.QOS_INDEX_RESPONSETIME];
				
			}
			
			this.atomicCompSchemes.get(i).getServiceInstance().utility = this.atomicCompSchemes.get(i).getServiceInstance().utility / Config.NUM_TENANTS;
			
//			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Composition Scheme " + i + " instance service: " +
//					" normalisedCt: " + normalisedCt +
//					" normalisedRe: " + normalisedRe +
//					" normalisedTp: " + normalisedTp +
//					" normalisedRt: " + normalisedRt +
//					" utility: " + this.atomicCompSchemes.get(i).getServiceInstance().utility);
			
			//calculate aggregate backup services utility
			for (int k=0; k<this.atomicCompSchemes.get(i).getSc().aggServiceNum; k++) {
				normalisedCt = (double)(this.minAndMaxAggQoS[Config.QOS_INDEX_COST][Config.QOS_MAX_INDEX] - this.atomicCompSchemes.get(i).getSc().aggServiceList.get(k).qos[Config.QOS_INDEX_COST])
						/ (this.minAndMaxAggQoS[Config.QOS_INDEX_COST][Config.QOS_MAX_INDEX] - minAndMaxAggQoS[Config.QOS_INDEX_COST][Config.QOS_MIN_INDEX]);
				normalisedRe = (double)(this.atomicCompSchemes.get(i).getSc().aggServiceList.get(k).qos[Config.QOS_INDEX_RELIABLITY] - this.minAndMaxAggQoS[Config.QOS_INDEX_RELIABLITY][Config.QOS_MIN_INDEX])
						/ (this.minAndMaxAggQoS[Config.QOS_INDEX_RELIABLITY][Config.QOS_MAX_INDEX] - minAndMaxAggQoS[Config.QOS_INDEX_RELIABLITY][Config.QOS_MIN_INDEX]);
				normalisedTp = (double)(this.atomicCompSchemes.get(i).getSc().aggServiceList.get(k).qos[Config.QOS_INDEX_THROUGHPUT] - this.minAndMaxAggQoS[Config.QOS_INDEX_THROUGHPUT][Config.QOS_MIN_INDEX])
						/ (this.minAndMaxAggQoS[Config.QOS_INDEX_THROUGHPUT][Config.QOS_MAX_INDEX] - minAndMaxAggQoS[Config.QOS_INDEX_THROUGHPUT][Config.QOS_MIN_INDEX]);
				normalisedRt = (double)(this.minAndMaxAggQoS[Config.QOS_INDEX_RESPONSETIME][Config.QOS_MAX_INDEX] - this.atomicCompSchemes.get(i).getSc().aggServiceList.get(k).qos[Config.QOS_INDEX_RESPONSETIME])
						/ (this.minAndMaxAggQoS[Config.QOS_INDEX_RESPONSETIME][Config.QOS_MAX_INDEX] - minAndMaxAggQoS[Config.QOS_INDEX_RESPONSETIME][Config.QOS_MIN_INDEX]);
				for (int j=0; j<this.atomicCompSchemes.get(i).getTenantsNum(); j++) {
					this.atomicCompSchemes.get(i).getSc().aggServiceList.get(k).utility += 
							normalisedCt * this.atomicCompSchemes.get(i).tenantQoSPreferences[j][Config.QOS_INDEX_COST]
						    + normalisedRe * this.atomicCompSchemes.get(i).tenantQoSPreferences[j][Config.QOS_INDEX_RELIABLITY]
						    + normalisedTp * this.atomicCompSchemes.get(i).tenantQoSPreferences[j][Config.QOS_INDEX_THROUGHPUT]
						    + normalisedRt * this.atomicCompSchemes.get(i).tenantQoSPreferences[j][Config.QOS_INDEX_RESPONSETIME];
					
				}
				
				this.atomicCompSchemes.get(i).getSc().aggServiceList.get(k).utility  = 
						this.atomicCompSchemes.get(i).getSc().aggServiceList.get(k).utility  / this.atomicCompSchemes.get(i).getTenantsNum();
//				
//				LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Composition Scheme " + i + " aggregate service " + 
//						this.atomicCompSchemes.get(i).getSc().aggServiceList.get(k).servicdId + ": " +
//						" normalisedCt: " + normalisedCt +
//						" normalisedRe: " + normalisedRe +
//						" normalisedTp: " + normalisedTp +
//						" normalisedRt: " + normalisedRt +
//						" utility: " + this.atomicCompSchemes.get(i).getSc().aggServiceList.get(k).utility);

			}
		}		
	}
	public void calculateCandidateServicesUtility() {

		for (int i=0; i<this.atomicCompSchemes.size(); i++) {
			
			for (int k=0; k<Config.NUM_SERVICES_PER_CLASS; k++) {
				for (int j=0; j<this.atomicCompSchemes.get(i).getTenantsNum(); j++) {
					this.atomicCompSchemes.get(i).getSc().services[k].utility += 
							this.atomicCompSchemes.get(i).getSc().services[k].nqos[Config.QOS_INDEX_COST] * this.atomicCompSchemes.get(i).tenantQoSPreferences[j][Config.QOS_INDEX_COST]
						    + this.atomicCompSchemes.get(i).getSc().services[k].nqos[Config.QOS_INDEX_RELIABLITY] * this.atomicCompSchemes.get(i).tenantQoSPreferences[j][Config.QOS_INDEX_RELIABLITY]
						    + this.atomicCompSchemes.get(i).getSc().services[k].nqos[Config.QOS_INDEX_THROUGHPUT] * this.atomicCompSchemes.get(i).tenantQoSPreferences[j][Config.QOS_INDEX_THROUGHPUT]
						    + this.atomicCompSchemes.get(i).getSc().services[k].nqos[Config.QOS_INDEX_RESPONSETIME] * this.atomicCompSchemes.get(i).tenantQoSPreferences[j][Config.QOS_INDEX_RESPONSETIME];
					
				}				
				this.atomicCompSchemes.get(i).getSc().services[k].utility = this.atomicCompSchemes.get(i).getSc().services[k].utility / Config.NUM_TENANTS;				
			}

		}		
	}	
	Comparator<CompositionScheme> comparatorId = new Comparator<CompositionScheme>(){
		   @Override
		public int compare(CompositionScheme c1, CompositionScheme c2) {
			   if (c1.id > c2.id) {
				   return 1;
			   } else {
				   return -1;
			   }
		   }
	};
	
	public void sortCompSchemesById() {
		Collections.sort(this.atomicCompSchemes,comparatorId);
		for (int i=0; i<atomicCompSchemes.size(); i++) {
			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Atom composition scheme " + atomicCompSchemes.get(i).id);
		}
		return;
	}
	
	public void calEpResponseTime() {
		for (int i=0; i<executionPaths.size(); i++) {
			ExecutionPath ep = executionPaths.get(i);
			ep.responeTime = 0;
			for (int j=0; j<ep.compSchemes.size(); j++) {
				double weight = 1.0;
				for (int k=0; k<ep.edges.size(); k++) {
					if (edges.get(k).getTarget() == ep.compSchemes.get(j).getId()) {
						weight = edges.get(k).getWeight();
						break;
					}
				}
				//ep.responeTime += (weight * ep.compSchemes.get(j).getServiceInstance().getQos()[Config.QOS_INDEX_RESPONSETIME]);
				ep.responeTime += ep.compSchemes.get(j).getServiceInstance().getQos()[Config.QOS_INDEX_RESPONSETIME];
			}
			if (i == 0) {
				minEpResponsetime = ep.responeTime;
			}
			if (ep.responeTime > maxEpResponsetime) {
				maxEpResponsetime = ep.responeTime;
			}
			if (ep.responeTime < minEpResponsetime) {
				minEpResponsetime = ep.responeTime;
			}
		}
	}
	
	Comparator<ExecutionPath> comparatorRT = new Comparator<ExecutionPath>(){
		   @Override
		public int compare(ExecutionPath ep1, ExecutionPath ep2) {
			   if (ep1.responeTime < ep2.responeTime) {
				   return 1;
			   } else {
				   return -1;
			   }
		   }
	};
	
	public void sortExecutionPathsByRt() {
		Collections.sort(executionPaths,comparatorRT);
		for (int i=0; i<executionPaths.size(); i++) {
			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "EP" + executionPaths.get(i).epId + ", response time is " + executionPaths.get(i).responeTime);
		}
		return;
	}
	
	public void setRankOfSchemeInEp() {
		for (int i=0; i<executionPaths.size(); i++) {
			ExecutionPath ep = executionPaths.get(i);
			for (int j=0; j<ep.compSchemes.size(); j++) {
				CompositionScheme sch = ep.compSchemes.get(j);
				if (sch.rank[Config.QOS_INDEX_RESPONSETIME] == 0) {
					sch.rank[Config.QOS_INDEX_RESPONSETIME] = i+1;
				}
			}
		}		
	}

	public void normaliseCriticalityByRt() {
		for (int i=0; i<executionPaths.size(); i++) {
			double epCri = (double)(executionPaths.get(i).responeTime - this.minEpResponsetime) / (this.maxEpResponsetime - this.minEpResponsetime);
			for (int j=0; j<executionPaths.get(i).compSchemes.size(); j++) {
				if (executionPaths.size() == 1) {
					executionPaths.get(i).compSchemes.get(j).criticality[Config.QOS_INDEX_RESPONSETIME] = 1;
				} else if (this.maxEpResponsetime == this.minEpResponsetime) {
					executionPaths.get(i).compSchemes.get(j).criticality[Config.QOS_INDEX_RESPONSETIME] = 1;
				} else if (executionPaths.get(i).compSchemes.get(j).criticality[Config.QOS_INDEX_RESPONSETIME] == 0) {
					/* atomicCompSchemes.get(i).getTenantsWeight(); */			
					executionPaths.get(i).compSchemes.get(j).criticality[Config.QOS_INDEX_RESPONSETIME] = 
							executionPaths.get(i).compSchemes.get(j).getTenantsWeight() * epCri;
				}
			}
		}
	}
	
	public void calCriticalityByResponsetime() {
		
		/* Get all the execution paths */
		//generateExecutionPaths();
		/* Calculate the response time of each execution path */
		//calEpResponseTime();
		/* Sort execution paths by response time */
		//sortExecutionPathsByRt();
		/* Set the rank of execution paths */
		//setRankOfSchemeInEp();
		/* Get normalised criticality for each service in RT dimension */
		//normaliseCriticalityByRt();
		calRtSAforEachServiceByPercent();
		normaliseSaByRt();
		weightSaByRt();
		
		
		return;
	}
	public void calRtSAforEachServiceByPercent() {
		//calculate QoS of composition
		this.compScheme.calculateQos();
		double originalRT = compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];
		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "\r\nOriginal Response time of composition is " + originalRT);
		double degradation = 0;
		//double incrementOfSrcRt = 0; // Increment of response time of each service
		double incrementOfComRt = 0; // Increment of response time of composition
		double totalIncrOfSrc = 0;
		double totalIncrOfCom = 0;
		double totalSa = 0;
		
		for (int i=0; i<this.atomicCompSchemes.size(); i++) {
			degradation = 0;
			totalIncrOfSrc = 0;
			totalIncrOfCom = 0;
			totalSa = 0;
			
			double originalSrcRt = this.atomicCompSchemes.get(i).getQosValues()[Config.QOS_INDEX_RESPONSETIME];
//			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "S" + this.atomicCompSchemes.get(i).getId() + " original rt is " + originalSrcRt + 
//					", composition rt is " + originalRT);
			//incrementOfSrcRt = originalSrcRt * Config.DEGRADATION_SEVERITY_STEP;
			int round = 0;
			while((1 + degradation) <= Config.CURRENT_DEGRADATION_NEGATIVE_SEVERITY) {
				round++;
				degradation += Config.DEGRADATION_SEVERITY_STEP;
				this.atomicCompSchemes.get(i).qosValues[Config.QOS_INDEX_RESPONSETIME] = originalSrcRt * (1 + degradation);
				this.compScheme.calculateQos();
				incrementOfComRt = this.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME] - originalRT;
				
				totalSa += ((incrementOfComRt/originalRT)/degradation);
				
				//totalIncrOfSrc += degradation;
				//totalIncrOfCom += incrementOfComRt/originalRT;
				
//				LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "S" + this.atomicCompSchemes.get(i).getId() + " " + round + "th round: degradation is " + degradation
//						+ ", RT Increment of composition is " + (incrementOfComRt/originalRT));
			}
			
			this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RESPONSETIME] = (double)totalSa/round;
			
			if (i == 0) {
				this.minRtSa = this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RESPONSETIME];
			} else if (this.minRtSa > this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RESPONSETIME]) {
				this.minRtSa = this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RESPONSETIME];
			} 
			
			if (this.maxRtSa < this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RESPONSETIME]) {
				this.maxRtSa = this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RESPONSETIME];
			}
			
			//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "S" + this.atomicCompSchemes.get(i).getId() + " RTSA is " + this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RESPONSETIME]);
			
			//this.atomicCompSchemes.get(i).criticality[Config.QOS_INDEX_RESPONSETIME] = this.atomicCompSchemes.get(i).getTenantsWeight() * this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RESPONSETIME];
			
			//this.atomicCompSchemes.get(i).criticality[Config.QOS_INDEX_RESPONSETIME] = this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RESPONSETIME];
			
			//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "S" + this.atomicCompSchemes.get(i).getId() + " RT criticality is " + this.atomicCompSchemes.get(i).criticality[Config.QOS_INDEX_RESPONSETIME]);
			
			incrementOfComRt = 0;
			//incrementOfSrcRt = 0;
			
			this.atomicCompSchemes.get(i).getQosValues()[Config.QOS_INDEX_RESPONSETIME] = originalSrcRt;
		}
	}
	
	public void normaliseSaByRt() {
		//System.out.println("MinRtSa is " + this.minRtSa + ", maxRtSa is " + this.maxRtSa);
		for (int i=0; i<atomicCompSchemes.size(); i++) {
			//System.out.println("S" + this.atomicCompSchemes.get(i).getId() + " original rt sa is " + atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RESPONSETIME]);
			if (atomicCompSchemes.size() == 1) {
				atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RESPONSETIME] = 1;
			} if (this.minRtSa == this.maxRtSa) {
				atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RESPONSETIME] = 1;
			} else {
				/* atomicCompSchemes.get(i).getTenantsWeight(); */	
				atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RESPONSETIME] = 
						((double)(atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RESPONSETIME] - this.minRtSa) / (this.maxRtSa - this.minRtSa));
			}
			
			//System.out.println("S" + this.atomicCompSchemes.get(i).getId() + " normalised rt sa is " + atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RESPONSETIME]);
		}
		return;
	}
	
	public void weightSaByRt() {
		for (int i=0; i<atomicCompSchemes.size(); i++) {
			atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RESPONSETIME] = atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RESPONSETIME] * atomicCompSchemes.get(i).getTenantsWeight();
			atomicCompSchemes.get(i).criticality[Config.QOS_INDEX_RESPONSETIME] = this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RESPONSETIME];
			
			//System.out.println("S" + this.atomicCompSchemes.get(i).getId() + " tenants weight is " + atomicCompSchemes.get(i).getTenantsWeight()
				//	+ ", rt criticality is " + this.atomicCompSchemes.get(i).criticality[Config.QOS_INDEX_RESPONSETIME]);

		}
	}

	public void calRtSAforEachService() {
		//calculate QoS of composition
		this.compScheme.calculateQos();
		double originalRT = compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME];
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Original Response time of composition is " + originalRT);
		double rtStep = 10; // 10 ms
		double incrementOfSrcRt = 0; // Increment of response time of each service
		double incrementOfComRt = 0; // Increment of response time of composition
		for (int i=0; i<this.atomicCompSchemes.size(); i++) {
			double originalSrcRt = this.atomicCompSchemes.get(i).getQosValues()[Config.QOS_INDEX_RESPONSETIME];
			while(incrementOfComRt == 0) {
				incrementOfSrcRt += rtStep;
				this.atomicCompSchemes.get(i).qosValues[Config.QOS_INDEX_RESPONSETIME] = originalSrcRt + incrementOfSrcRt;
				this.compScheme.calculateQos();
				incrementOfComRt = this.compScheme.getQosValues()[Config.QOS_INDEX_RESPONSETIME] - originalRT;
				LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "RT Increment of service S" + this.atomicCompSchemes.get(i).getId() + " is " + incrementOfSrcRt
						+ ", RT Increment of composition is " + incrementOfComRt);
			}
			
			this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RESPONSETIME] = (double)incrementOfComRt/incrementOfSrcRt;
			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "S" + this.atomicCompSchemes.get(i).getId() + " RTSA is " + this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RESPONSETIME]);
			
			this.atomicCompSchemes.get(i).criticality[Config.QOS_INDEX_RESPONSETIME] = this.atomicCompSchemes.get(i).getTenantsWeight() * this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RESPONSETIME];
			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "S" + this.atomicCompSchemes.get(i).getId() + " RT criticality is " + this.atomicCompSchemes.get(i).criticality[Config.QOS_INDEX_RESPONSETIME]);
			
			incrementOfComRt = 0;
			incrementOfSrcRt = 0;
			
			this.atomicCompSchemes.get(i).getQosValues()[Config.QOS_INDEX_RESPONSETIME] = originalSrcRt;
		}
	}
	public void calTpSAforEachServiceByPercent() {
		//calculate QoS of composition
		this.compScheme.calculateQos();
		double originalCompTP = compScheme.getQosValues()[Config.QOS_INDEX_THROUGHPUT];
		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "\r\nOriginal throughput of composition is " + originalCompTP);
		//double decrementOfSrcTp = 0; // Increment of response time of each service
		double decrementOfComTp = 0; // Increment of response time of composition
		double degradation = 0;
		//double totalDecOfSrcTp = 0;
		//double totalDecOfComTp = 0;
		
		for (int i=0; i<this.atomicCompSchemes.size(); i++) {
			degradation = 0;
			//totalDecOfSrcTp = 0;
			//totalDecOfComTp = 0;
			double totalSa = 0;
			
			double originalSrcTp = this.atomicCompSchemes.get(i).getQosValues()[Config.QOS_INDEX_THROUGHPUT];
			//System.out.println("S" + this.atomicCompSchemes.get(i).getId() + " original tp is " + originalSrcTp + 
			//		", composition tp is " + originalCompTP);
			//decrementOfSrcTp = originalSrcTp * Config.DEGRADATION_SEVERITY_STEP;
			int round = 0;
			while((1.0 - degradation) >= Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY) {
				round++;
				degradation += Config.DEGRADATION_SEVERITY_STEP;
				this.atomicCompSchemes.get(i).getQosValues()[Config.QOS_INDEX_THROUGHPUT] = originalSrcTp * (1 - degradation);
				this.compScheme.calculateQos();
				decrementOfComTp = originalCompTP - this.compScheme.getQosValues()[Config.QOS_INDEX_THROUGHPUT];

				totalSa += ((decrementOfComTp/originalCompTP)/degradation);
				//totalDecOfSrcTp += degradation;
				//totalDecOfComTp += decrementOfComTp/originalCompTP;
				
				//System.out.println("S" + this.atomicCompSchemes.get(i).getId() + " " + i + "th round: degradation is " + degradation
				//		+ ", TP Decrement of composition is " + decrementOfComTp/originalCompTP + ", totalSa is " + totalSa);
			}
			
			this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_THROUGHPUT] = (double)totalSa/round;
			
			if (i == 0) {
				this.minTpSa = this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_THROUGHPUT];
			} else if (this.minTpSa > this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_THROUGHPUT]) {
				this.minTpSa = this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_THROUGHPUT];
			} 		
			
			if (this.maxTpSa < this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_THROUGHPUT]) {
				this.maxTpSa = this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_THROUGHPUT];
			}
			
			//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "S" + this.atomicCompSchemes.get(i).getId() + " TPSA is " + this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_THROUGHPUT]);
			
			//this.atomicCompSchemes.get(i).criticality[Config.QOS_INDEX_THROUGHPUT] = this.atomicCompSchemes.get(i).getTenantsWeight() * this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_THROUGHPUT];
			
			//decrementOfSrcTp = 0;
			decrementOfComTp = 0;
			
			this.atomicCompSchemes.get(i).getQosValues()[Config.QOS_INDEX_THROUGHPUT] = originalSrcTp;
		}
	}

	public void calReSAforEachServiceByPercent() {
		//calculate QoS of composition
		this.compScheme.calculateQos();
		double originalCompRe = compScheme.getQosValues()[Config.QOS_INDEX_RELIABLITY];
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "\r\nOriginal reliability of composition is " + originalCompRe);
		double decrementOfSrcRe = 0; // Increment of response time of each service
		double decrementOfComRe = 0; // Increment of response time of composition
		double degradation = 0;
		double totalDecOfSrcRe = 0;
		double totalDecOfComRe = 0;
		
		for (int i=0; i<this.atomicCompSchemes.size(); i++) {
			degradation = 0;
			totalDecOfSrcRe = 0;
			totalDecOfComRe = 0;
			
			double originalSrcRe = this.atomicCompSchemes.get(i).getQosValues()[Config.QOS_INDEX_RELIABLITY];
			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "S" + this.atomicCompSchemes.get(i).getId() + " original re is " + originalSrcRe + 
					", composition re is " + originalCompRe);
			decrementOfSrcRe = originalSrcRe * Config.DEGRADATION_SEVERITY_STEP;
			int round = 0;		
			while((1.0 - degradation) >= Config.CURRENT_DEGRADATION_POSITIVE_SEVERITY) {
				round++;
				degradation += Config.DEGRADATION_SEVERITY_STEP;
				this.atomicCompSchemes.get(i).getQosValues()[Config.QOS_INDEX_RELIABLITY] = originalSrcRe * (1 - degradation);
				this.compScheme.calculateQos();
				decrementOfComRe = originalCompRe - this.compScheme.getQosValues()[Config.QOS_INDEX_RELIABLITY];

				
				totalDecOfSrcRe += degradation;
				totalDecOfComRe += decrementOfComRe/originalCompRe;
				LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "S" + this.atomicCompSchemes.get(i).getId() + " " + round + "th round: degradation is " + degradation + ", RE Decrement of service is " + totalDecOfSrcRe
						+ ", RE Decrement of composition is " + totalDecOfComRe);
			}
			
			this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RELIABLITY] = (double)totalDecOfComRe/totalDecOfSrcRe;

			
			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "S" + this.atomicCompSchemes.get(i).getId() + " RESA is " + this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RELIABLITY]);
			if (1.0 - this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RELIABLITY]  > 0.001) {
				this.printAllAtomicCompSchemes();
				this.printComposition();
				System.exit(0);
			}
			
			this.atomicCompSchemes.get(i).criticality[Config.QOS_INDEX_RELIABLITY] = this.atomicCompSchemes.get(i).getTenantsWeight() * this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_RELIABLITY];
			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "S" + this.atomicCompSchemes.get(i).getId() + " RE criticality is " + this.atomicCompSchemes.get(i).criticality[Config.QOS_INDEX_RELIABLITY]);
			
			decrementOfSrcRe = 0;
			decrementOfComRe = 0;
			
			this.atomicCompSchemes.get(i).getQosValues()[Config.QOS_INDEX_RELIABLITY] = originalSrcRe;
		}
	}

	public void calTpSAforEachService() {
		//calculate QoS of composition
		this.compScheme.calculateQos();
		double originalCompTP = compScheme.getQosValues()[Config.QOS_INDEX_THROUGHPUT];
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Original throughput of composition is " + originalCompTP);
		double tpStep = 10; // 10 ms
		double decrementOfSrcTp = 0; // Increment of response time of each service
		double decrementOfComTp = 0; // Increment of response time of composition
		
		for (int i=0; i<this.atomicCompSchemes.size(); i++) {
			double originalSrcTp = this.atomicCompSchemes.get(i).getQosValues()[Config.QOS_INDEX_THROUGHPUT];
			decrementOfSrcTp = originalSrcTp;
			this.atomicCompSchemes.get(i).getQosValues()[Config.QOS_INDEX_THROUGHPUT] = originalSrcTp - decrementOfSrcTp;
			this.compScheme.calculateQos();
			decrementOfComTp = originalCompTP - this.compScheme.getQosValues()[Config.QOS_INDEX_THROUGHPUT];

			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "TP Decrement of service S" + this.atomicCompSchemes.get(i).getId() + " is " + decrementOfSrcTp
					+ ", TP Decrement of composition is " + decrementOfComTp);
			
			this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_THROUGHPUT] = (double)decrementOfComTp/decrementOfSrcTp;
			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "S" + this.atomicCompSchemes.get(i).getId() + " TPSA is " + this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_THROUGHPUT]);
			
			this.atomicCompSchemes.get(i).criticality[Config.QOS_INDEX_THROUGHPUT] = this.atomicCompSchemes.get(i).getTenantsWeight() * this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_THROUGHPUT];
			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "S" + this.atomicCompSchemes.get(i).getId() + " TP criticality is " + this.atomicCompSchemes.get(i).criticality[Config.QOS_INDEX_THROUGHPUT]);
			
			decrementOfSrcTp = 0;
			decrementOfComTp = 0;
			
			this.atomicCompSchemes.get(i).getQosValues()[Config.QOS_INDEX_THROUGHPUT] = originalSrcTp;
		}
	}

	public void calRawOfCompSchemes() {
		double raw;
		double originalCompReliability;
		
		compScheme.calculateQos();
		
		originalCompReliability = compScheme.getQosValues()[Config.QOS_INDEX_RELIABLITY];
		
		for (int i=0; i<atomicCompSchemes.size(); i++) {
			double originalSchemeReliability = atomicCompSchemes.get(i).getQosValues()[Config.QOS_INDEX_RELIABLITY];
			/* Set to 1 */
			atomicCompSchemes.get(i).getQosValues()[Config.QOS_INDEX_RELIABLITY] = 1.0;
			compScheme.calculateQos();
			raw = compScheme.getQosValues()[Config.QOS_INDEX_RELIABLITY] / originalCompReliability;
			atomicCompSchemes.get(i).reliabilityRAW = raw;
			atomicCompSchemes.get(i).getQosValues()[Config.QOS_INDEX_RELIABLITY] = originalSchemeReliability;
		}
		return;
	}

	Comparator<CompositionScheme> comparatorRE = new Comparator<CompositionScheme>(){
		   @Override
		public int compare(CompositionScheme cs1, CompositionScheme cs2) {
			   if (cs1.reliabilityRAW < cs2.reliabilityRAW) {
				   return 1;
			   } else {
				   return -1;
			   }
		   }
	};
	
	public void sortCompSchemesByRe() {
		Collections.sort(atomicCompSchemes,comparatorRE);
		for (int i=0; i<atomicCompSchemes.size(); i++) {
			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "S" + atomicCompSchemes.get(i).getId() + ", raw = " + atomicCompSchemes.get(i).reliabilityRAW);
		}
		return;
	}
	
	public void setRankOfSchemeByRe() {
		for (int i=0; i<atomicCompSchemes.size(); i++) {
			CompositionScheme es = atomicCompSchemes.get(i);
			es.rank[Config.QOS_INDEX_RELIABLITY] = i+1;
		}	
		return;
	}

	public void normaliseCriticalityByRe() {
		for (int i=0; i<atomicCompSchemes.size(); i++) {
			if (atomicCompSchemes.size() == 1) {
				atomicCompSchemes.get(i).criticality[Config.QOS_INDEX_RELIABLITY] = 1;
			} else {
				/* atomicCompSchemes.get(i).getTenantsWeight(); */	
				atomicCompSchemes.get(i).criticality[Config.QOS_INDEX_RELIABLITY] = 
						atomicCompSchemes.get(i).getTenantsWeight() * ((double)(atomicCompSchemes.size() - atomicCompSchemes.get(i).rank[Config.QOS_INDEX_RELIABLITY]) / (atomicCompSchemes.size()-1));
			}
		}
		return;
	}
	

	public void calCriticalityByReliability() {
		/*  */
		calRawOfCompSchemes();
		sortCompSchemesByRe();
		setRankOfSchemeByRe();
		normaliseCriticalityByRe();
		
		//calReSAforEachServiceByPercent();
		
		return;
	}
	
	Comparator<CompositionScheme> comparatorTp = new Comparator<CompositionScheme>(){
		   @Override
		public int compare(CompositionScheme cs1, CompositionScheme cs2) {
			   if (cs1.qosValues[Config.QOS_INDEX_THROUGHPUT] > cs2.qosValues[Config.QOS_INDEX_THROUGHPUT]) {
				   return 1;
			   } else {
				   return -1;
			   }
		   }
	};
	
	public void sortCompSchemesByTp() {
		Collections.sort(atomicCompSchemes,comparatorTp);
		for (int i=0; i<atomicCompSchemes.size(); i++) {
			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "S" + atomicCompSchemes.get(i).getId() + ", tp = " + atomicCompSchemes.get(i).qosValues[Config.QOS_INDEX_THROUGHPUT]);
		}
		this.maxThroughput = atomicCompSchemes.get(atomicCompSchemes.size()-1).qosValues[Config.QOS_INDEX_THROUGHPUT];
		this.minThroughput = atomicCompSchemes.get(0).qosValues[Config.QOS_INDEX_THROUGHPUT];
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Max throughput is " + this.maxThroughput + ", Min throughput is " + this.minThroughput);
		
		return;
	}
	
	public void setRankOfSchemeByTp() {
		for (int i=0; i<atomicCompSchemes.size(); i++) {
			CompositionScheme es = atomicCompSchemes.get(i);
			es.rank[Config.QOS_INDEX_THROUGHPUT] = i+1;
		}	
		return;
	}

	public void normaliseSaByTp() {
		//System.out.println("MinTpSa is " + this.minTpSa + ", maxTpSa is " + this.maxTpSa);
		for (int i=0; i<atomicCompSchemes.size(); i++) {
			//System.out.println("S" + this.atomicCompSchemes.get(i).getId() + " original tp sa is " + atomicCompSchemes.get(i).sa[Config.QOS_INDEX_THROUGHPUT]);
			if (atomicCompSchemes.size() == 1) {
				atomicCompSchemes.get(i).sa[Config.QOS_INDEX_THROUGHPUT] = 1;
			} if (this.maxTpSa == this.minTpSa) {
				atomicCompSchemes.get(i).sa[Config.QOS_INDEX_THROUGHPUT] = 1;
			} else {
				/* atomicCompSchemes.get(i).getTenantsWeight(); */	
				atomicCompSchemes.get(i).sa[Config.QOS_INDEX_THROUGHPUT] = 
						((double)(atomicCompSchemes.get(i).sa[Config.QOS_INDEX_THROUGHPUT] - this.minTpSa) / (this.maxTpSa - this.minTpSa));
			}
			
			//System.out.println("S" + this.atomicCompSchemes.get(i).getId() + " normalised tp sa is " + atomicCompSchemes.get(i).sa[Config.QOS_INDEX_THROUGHPUT]);
		}
		return;
	}
	
	public void weightSaByTp() {
		for (int i=0; i<atomicCompSchemes.size(); i++) {
			atomicCompSchemes.get(i).sa[Config.QOS_INDEX_THROUGHPUT] = atomicCompSchemes.get(i).sa[Config.QOS_INDEX_THROUGHPUT] * atomicCompSchemes.get(i).getTenantsWeight();
			atomicCompSchemes.get(i).criticality[Config.QOS_INDEX_THROUGHPUT] = this.atomicCompSchemes.get(i).sa[Config.QOS_INDEX_THROUGHPUT];
			
			//System.out.println("S" + this.atomicCompSchemes.get(i).getId() + " tenants weight is " + atomicCompSchemes.get(i).getTenantsWeight()
			//		+ ", TP criticality is " + this.atomicCompSchemes.get(i).criticality[Config.QOS_INDEX_THROUGHPUT]);

		}
	}
	
	public void calCriticalityByThroughput() {
		
		/* Sort services by their throughput */
		//sortCompSchemesByTp();
		//setRankOfSchemeByTp();
		/* Get normalised criticality in throughput dimension */
		//normaliseCriticalityByTp();
		calTpSAforEachServiceByPercent();
		normaliseSaByTp();
		weightSaByTp();
		
		return;
	}
	
	
	public void calOverallCriticality() {
		for (int i=0; i<this.atomicCompSchemes.size(); i++) {
			atomicCompSchemes.get(i).calculateCriticality();
		}
//		for (int i=0; i<this.atomicCompSchemes.size(); i++) {
//			System.out.println("S" + atomicCompSchemes.get(i).id + " overall criticality is " + Arrays.toString(atomicCompSchemes.get(i).criticality));			
//		}
		//sortByCriticality();
	}
	
	Comparator<CompositionScheme> comparatorCri = new Comparator<CompositionScheme>(){
		   @Override
		public int compare(CompositionScheme cs1, CompositionScheme cs2) {
			   if (cs1.overallCriticality < cs2.overallCriticality) {
				   return 1;
			   } else {
				   return -1;
			   }
		   }
	};	
	
	public void sortServicesByCriticality() {
		Collections.sort(atomicCompSchemes,comparatorCri);
//		for (int i=0; i<atomicCompSchemes.size(); i++) {
//			System.out.println("Sorted S" + atomicCompSchemes.get(i).getId() + ", criticality = " + atomicCompSchemes.get(i).overallCriticality);
//		}
		return;
	}
	
	public CompositionScheme getCompSchemeById(int id) {
		CompositionScheme sch = null;
		for (int i=0; i<atomicCompSchemes.size(); i++) {
			if (atomicCompSchemes.get(i).getId() == id) {
				sch = atomicCompSchemes.get(i);
				break;
			}
		}
		return sch;
	}
	public void generateExecutionPaths() {
		ArrayList<ArrayList<ExecutionPath>> paths = new ArrayList<ArrayList<ExecutionPath>>();
		for (int i=0; i<Config.NUM_TASKS; i++) {
			paths.add(new ArrayList<ExecutionPath>());
		}
		
		CompositionScheme sourceSch = atomicCompSchemes.get(0);
		ExecutionPath ep0 = new ExecutionPath();
		ep0.addCompScheme(sourceSch);
		paths.get(0).add(ep0);
		
		for (int i=0; i<Config.NUM_TASKS; i++) {
			int sourceId = atomicCompSchemes.get(i).getId();
			for (int j=0; j<edges.size(); j++) {
				Edge edge = edges.get(j);
				if (edge.getSource() == sourceId) {
					int targetId = edge.getTarget();
					CompositionScheme targetSch = getCompSchemeById(targetId);
					ArrayList<ExecutionPath> targetEpList = paths.get(targetId);
					ArrayList<ExecutionPath> sourceEpList = paths.get(sourceId);
					
					for (int k=0; k<sourceEpList.size(); k++) {	
						int epId = targetEpList.size();
						ExecutionPath ep = new ExecutionPath();
						ep.setEpId(epId);
						for (int sch=0; sch<sourceEpList.get(k).compSchemes.size(); sch++) {
							ep.addCompScheme(sourceEpList.get(k).compSchemes.get(sch));
							LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Add S" + sourceEpList.get(k).compSchemes.get(sch).getId() + 
									" to S" + targetSch.getId() + " EP" + epId);
						}
						for (int e=0; e<sourceEpList.get(k).edges.size(); e++) {
							ep.addEdge(sourceEpList.get(k).edges.get(e));
							LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Add Edge " + sourceEpList.get(k).edges.get(e).getSource() + "--->" +
									sourceEpList.get(k).edges.get(e).getTarget() +
									" to S" + targetSch.getId() + " EP" + epId);
						}
						
						ep.addCompScheme(targetSch);
						LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Add S" + targetSch.getId() + 
								" to S" + targetSch.getId() + " EP" + epId);
						ep.addEdge(edge);
						LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Add Edge " + edge.getSource() + "--->" +
								edge.getTarget() +
								" to S" + targetSch.getId() + " EP" + epId);
						targetEpList.add(ep);
					}					
				}
			}			
		}
		
		executionPaths = paths.get(Config.NUM_TASKS - 1);
	}
	
	
	/* Generate virtual candidate services by permutation of current services */
	public ServiceClass getSc() {
		return sc;
	}

	public void setSc(ServiceClass sc) {
		this.sc = sc;
	}

//	public void generateAggregateServices(ServiceClass sc) {	
//		for (int i=0; i<this.atomicCompSchemes.size(); i++) {
//			int aggServiceNum = 0;
//			AggregateService aggService = new AggregateService();
//			aggService.servicdId = aggServiceNum++;
//			aggService.addMember(atomicCompSchemes.get(i).serviceInstance);
//			aggService.calculateQoS();
//			aggService.qos[Config.QOS_INDEX_RESPONSETIME] = atomicCompSchemes.get(i).serviceInstance.qos[Config.QOS_INDEX_RESPONSETIME];
//			aggService.qos[Config.QOS_INDEX_THROUGHPUT] = atomicCompSchemes.get(i).serviceInstance.qos[Config.QOS_INDEX_THROUGHPUT];
//			sc.aggServiceList.add(aggService);
//			
//			for (int j=1; j<=Config.NUM_SERVICES_PER_CLASS; j++) {
//				/* Create permutation of current candidate services with the specified instantiated service */
//				Permutations per = new Permutations();
//				ArrayList<Service[]> aggSrvList = per.combine(sc.getServices(), j);
//				for (int k=0; k<aggSrvList.size(); k++) {
//					AggregateService aggService1 = new AggregateService();
//					aggService1.servicdId = aggServiceNum++;
//					aggService1.addMember(atomicCompSchemes.get(i).serviceInstance);
//					for (int l=0; l<aggSrvList.get(k).length; l++) {
//						aggService1.addMember(aggSrvList.get(k)[l]);
//					}
//					/* Calculate the aggregate QoS values for aggregate services */
//					aggService1.calculateQoS();
//					aggService1.qos[Config.QOS_INDEX_RESPONSETIME] = atomicCompSchemes.get(i).serviceInstance.qos[Config.QOS_INDEX_RESPONSETIME];
//					aggService1.qos[Config.QOS_INDEX_THROUGHPUT] = atomicCompSchemes.get(i).serviceInstance.qos[Config.QOS_INDEX_THROUGHPUT];					
//					sc.aggServiceList.add(aggService1);
//				}		
//			}
//			sc.aggServiceNum = aggServiceNum;
//			
//			this.aggregateServiceNumPerClass = aggServiceNum;
//			
//			sc.printAggregateServices();
//		}
//		
//	}
	
	public void printComposition() {
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "All atomic composition schemes: ");
		for (int i=0; i<atomicCompSchemes.size(); i++) {
			LogInfo.logInfo(LogInfo.LOGLEVEL_INFO, "S" + atomicCompSchemes.get(i).getId());
		}
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "All edges: ");
		for (int j=0; j<edges.size(); j++) {
			LogInfo.logInfo(LogInfo.LOGLEVEL_INFO, edges.get(j).toString());
		}
		return;
	}
	
	public Users getUsers() {
		return users;
	}

	public void setUsers(Users users) {
		this.users = users;
	}

	public int getAggregateServiceNumPerClass() {
		return aggregateServiceNumPerClass;
	}

	public void setAggregateServiceNumPerClass(int aggregateServiceNumPerClass) {
		this.aggregateServiceNumPerClass = aggregateServiceNumPerClass;
	}

	public void printAllEp() {
		for (int i=0; i<executionPaths.size(); i++) {
			executionPaths.get(i).printEp();
		}
		return;
	}
	
	public void printAllAtomicCompSchemes() {
		System.out.println("CCCCCCCCCCCCCCCCCCCCCC");
		System.out.println("All atomic composition schemes: ");
		System.out.println("---------------------------------");
		for (int i=0; i<atomicCompSchemes.size(); i++) {
			System.out.println("S" + atomicCompSchemes.get(i).getId());
			System.out.println("QoS: " + Arrays.toString(atomicCompSchemes.get(i).getServiceInstance().getQos()));
			System.out.println("Rank: " + Arrays.toString(atomicCompSchemes.get(i).rank));
			System.out.println("Criticality: " + Arrays.toString(atomicCompSchemes.get(i).criticality));
			System.out.println("tenants ratio: " + (double)atomicCompSchemes.get(i).tenantsNum/100);
			System.out.println("Overall Criticality: " + atomicCompSchemes.get(i).overallCriticality);
			System.out.println("isFailed: " + atomicCompSchemes.get(i).isFailed);
			System.out.println("isRedundant: " + atomicCompSchemes.get(i).isRedundant);
			System.out.println("Penalty: " + atomicCompSchemes.get(i).failPenalty);
		}
		System.out.println("---------------------------------");
		return;
	}
	
	public void randomPenalty() {
		Random rand = new Random();
		for (int i=0; i<Config.NUM_SERVICE_CLASSES; i++) {
			this.penalty[i] = rand.nextInt(Config.QOS_UPPER_BOUND);
		}
		
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Penalty: " + Arrays.toString(this.penalty));
		
		for (int i=0; i<Config.NUM_SERVICE_CLASSES; i++) {
			this.atomicCompSchemes.get(i).setFailPenalty(this.penalty[i]);
		}
	}
	public void clearFailureFlag() {
		for (int i=0; i<this.atomicCompSchemes.size(); i++) {
			this.atomicCompSchemes.get(i).setFailed(false);
		}
	}
	public void clearRedundantFlag() {
		for (int i=0; i<this.atomicCompSchemes.size(); i++) {
			this.atomicCompSchemes.get(i).setRedundant(false);
			for (int j=0; j<3; j++) {
				this.atomicCompSchemes.get(i).isRedundantArray[j] = false;
			}
		}
	}
	
	Comparator<CompositionScheme> comparatorFN = new Comparator<CompositionScheme>(){
		   @Override
		public int compare(CompositionScheme cs1, CompositionScheme cs2) {
			   if (cs1.failureNum < cs2.failureNum) {
				   return 1;
			   } else {
				   return -1;
			   }
		   }
	};
	
	public void randomFailure(int failNum) {
		Collections.sort(atomicCompSchemes,comparatorFN);
		for (int i=0; i<failNum; i++) {
			this.atomicCompSchemes.get(i).setFailed(true);
		}
		Collections.sort(this.atomicCompSchemes,comparatorId);
		
//		Random rand = new Random();
//		ArrayList<Integer> array = new ArrayList<Integer>();
//		//MyFileWriter writer = new MyFileWriter("output.txt");
//		
//		for (int i=0; i<Config.NUM_SERVICE_CLASSES; i++) {
//			array.add(i);
//			this.failServices[i] = 0;
//		}
//				
//		for (int i=0; i<failNum; i++) {
//			int failIdx = rand.nextInt(array.size());
//			this.failServices[array.get(failIdx).intValue()] = 1;
//			array.remove(failIdx);
//		} 
//		
//		for (int i=0; i<Config.NUM_SERVICE_CLASSES; i++) {
//			if (this.failServices[i] == 1) {
//				this.atomicCompSchemes.get(i).setFailed(true);
//			}
//		}
//		
//		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Failure Services: " + Arrays.toString(this.failServices));
		//writer.writeFile2("Failure Services: " + Arrays.toString(this.failServices));
	}
	
	public void allocateFailures(int failureNumber) {
		int total = 0;
		for (int i=0; i<this.atomicCompSchemes.size(); i++) {
			total += this.atomicCompSchemes.get(i).tenantsNum;
		}
		
		for (int i=0; i<this.atomicCompSchemes.size(); i++) {
			this.atomicCompSchemes.get(i).failureNum = (int) Math.round(failureNumber * ((double)this.atomicCompSchemes.get(i).tenantsNum / total));
			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "AtomicCompSchemes " + this.atomicCompSchemes.get(i).id + " failure number is " + this.atomicCompSchemes.get(i).failureNum);
		}
		
	}
}
