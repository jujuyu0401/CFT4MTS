package composition;

import java.util.ArrayList;

import log.LogInfo;
import config.Config;
import edge.Edge;

public class ExecutionPath {
	int epId;
	public ArrayList<CompositionScheme> compSchemes;
	public ArrayList<Edge> edges;
	public double responeTime;
	
	public ExecutionPath() {
		compSchemes = new ArrayList<CompositionScheme>();
		edges = new ArrayList<Edge>();
	}
	
	public int getEpId() {
		return epId;
	}

	public void setEpId(int epId) {
		this.epId = epId;
	}

	public void addCompScheme(CompositionScheme scheme) {
		compSchemes.add(scheme);
		return;
	}
	
	public void addEdge(Edge edge) {
		edges.add(edge);
		return;
	}
	
	public double getResponseTime() {
		double rt = 0;
		for (int i=0; i<compSchemes.size(); i++) {
			rt += compSchemes.get(i).getServiceInstance().getQos()[Config.QOS_INDEX_RESPONSETIME];
		}
		this.responeTime = rt;
		return rt;
	}

	@Override
	public String toString() {
		return "ExecutionPath [compSchemes=" + compSchemes + ", edges=" + edges
				+ ", responeTime=" + responeTime + "]";
	}
	
	public void printEp() {
		System.out.println("bbbbbbbbbbbbb");
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "ExecutionPath " + epId);
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "--------------------------------------");
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Response Time: " + this.responeTime);
		for (int i=0; i<compSchemes.size(); i++) {
			System.out.print("S" + compSchemes.get(i).getId() + " ");
		}
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "\r\n");
		
		for (int i=0; i<edges.size(); i++) {
			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Edge: " + edges.get(i).getSource() + "--->" + edges.get(i).getTarget() + ", weight " + edges.get(i).getWeight());
		}
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "--------------------------------------");
	}
	
}
