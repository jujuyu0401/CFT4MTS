package composition;

import ilog.concert.IloException;
import ilog.concert.IloMPModeler;
import ilog.concert.IloNumExpr;
import ilog.concert.IloNumVar;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import log.LogInfo;
import config.Config;
import edge.Edge;
import services.Service;
import services.ServiceClass;

/*
 * Composition Scheme Generator
 * Generate service composition randomly with specified number of service class, like a tree
 * Calculating the aggregate QoS of service composition after Service instantiated
 * Generate numeric expression for calculating the QoS of service composition
 * Extract the ServiceComposition, which is the basic class of Execution Scenario and Execution Path
 * */
public class CompositionScheme {
	int id;
	String name;
	CompositionPattern pattern;
	double probability;
	public double[] qosValues;
	public double utility;
	int availableServiceNum;
	int serviceIdBase;
	boolean isAtomicComposition;
	Service serviceInstance;	
	Service compServiceInstance;
	public Service getCompServiceInstance() {
		return compServiceInstance;
	}

	public void setCompServiceInstance(Service compServiceInstance) {
		this.compServiceInstance = compServiceInstance;
	}

	Service ftStrategy;
	public Service getFtStrategy() {
		return ftStrategy;
	}

	public void setFtStrategy(Service ftStrategy) {
		this.ftStrategy = ftStrategy;
	}

	ServiceClass sc;
	ArrayList<CompositionScheme> subCompSchemes;
	public int tenantsNum;
	public int failureNum;
	public double[][] tenantQoSPreferences;
	double reliabilityRAW;
	public int[] rank;
	public double[] sa;
	public double[] criticality;
	double overallCriticality;
	double failPenalty;
	public boolean isFailed;
	public boolean isRedundant;
	public boolean[] isRedundantArray;
	
	public double V = 0;
	
	public CompositionScheme(CompositionPattern pattern, int availableServiceNum, int idBase) {
		this.pattern = pattern;
		this.availableServiceNum = availableServiceNum;
		this.serviceIdBase = idBase;
		if (Config.MIN_SERVICE_NUM_FOR_SEQUENCE == availableServiceNum) {
			this.isAtomicComposition = true;
			this.name = "s" + idBase;
			this.id = idBase;
		} else {
			this.isAtomicComposition = false;
		}

		this.subCompSchemes = new ArrayList<CompositionScheme>();
		qosValues = new double[Config.NUM_QOS];
		rank = new int[Config.NUM_QOS];
		sa = new double[Config.NUM_QOS];
		criticality = new double[Config.NUM_QOS];
		isRedundantArray = new boolean[3];
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public CompositionPattern getPattern() {
		return pattern;
	}

	public void setPattern(CompositionPattern pattern) {
		this.pattern = pattern;
	}

	public double getProbability() {
		return probability;
	}

	public void setProbability(double probability) {
		this.probability = probability;
	}

	public double[] getQosValues() {
		return qosValues;
	}

	public void setQosValues(double[] qosValues) {
		this.qosValues = qosValues;
	}

	public int getAvailableServiceNum() {
		return availableServiceNum;
	}

	public void setAvailableServiceNum(int availableServiceNum) {
		this.availableServiceNum = availableServiceNum;
	}

	public int getServiceIdBase() {
		return serviceIdBase;
	}

	public void setServiceIdBase(int serviceIdBase) {
		this.serviceIdBase = serviceIdBase;
	}

	public boolean isAtomicComposition() {
		return isAtomicComposition;
	}

	public void setAtomicComposition(boolean isAtomicComposition) {
		this.isAtomicComposition = isAtomicComposition;
	}

	public Service getServiceInstance() {
		return serviceInstance;
	}
	/* Used for atomic service composition scheme */
	public void setServiceInstance(Service serviceInstance) {
		this.serviceInstance = serviceInstance;
		this.qosValues = serviceInstance.qos;
	}

	public ArrayList<CompositionScheme> getSubCompScheme() {
		return subCompSchemes;
	}

	public void setSubCompScheme(ArrayList<CompositionScheme> subCompScheme) {
		this.subCompSchemes = subCompScheme;
	}
	
	public int getTenantsNum() {
		return tenantsNum;
	}

	public void setTenantsNum(int tanantsNum) {
		this.tenantsNum = tanantsNum;
	}

	public double getFailPenalty() {
		return failPenalty;
	}

	public int getFailureNum() {
		return failureNum;
	}

	public void setFailureNum(int failureNum) {
		this.failureNum = failureNum;
	}

	public void setFailPenalty(double failPenalty) {
		this.failPenalty = failPenalty;
	}

	public boolean isFailed() {
		return isFailed;
	}

	public void setFailed(boolean isFailed) {
		this.isFailed = isFailed;
	}

	public boolean isRedundant() {
		return isRedundant;
	}

	public void setRedundant(boolean isRedundant) {
		this.isRedundant = isRedundant;
	}

	public void allocateTenants() {
		if (isAtomicComposition) {
			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, this.name + ": Atomic service found, tenant number is " + this.tenantsNum);
			return;
		}
		/* Set the tenants number */
		if (this.pattern == CompositionPattern.SEQUENCE ||
				this.pattern == CompositionPattern.PARALLEL) {
			for (int i=0; i<subCompSchemes.size(); i++) {
				subCompSchemes.get(i).setTenantsNum(this.tenantsNum);
			}
			
		} else {
			//Random rand = new Random();
			subCompSchemes.get(0).setTenantsNum(this.tenantsNum);
			subCompSchemes.get(subCompSchemes.size()-1).setTenantsNum(this.tenantsNum);
			//int totalTenants = 0;
			for (int i=1; i<subCompSchemes.size()-1; i++) {		
				int te = 0; 
				te = (int)Math.round((float)this.tenantsNum * subCompSchemes.get(i).probability);
				//有误差
				if (te == 0) {
					te = 1;
				}
				subCompSchemes.get(i).setTenantsNum(te);
				
				/*
				if (i != subCompSchemes.size()-2 || (i == subCompSchemes.size()-2 && totalTenants > this.tenantsNum)) {
					while (0 == te) {
						te = rand.nextInt(this.tenantsNum);
					}					
				} else {
					while (0 == te) {
						te = rand.nextInt(totalTenants+1) + (this.tenantsNum - totalTenants);
					}
				}

				subCompSchemes.get(i).setTenantsNum(te);
				totalTenants += te;
				*/
			}
		}
		
		/* allocate tenants for sub composition schemes */
		for (int i=0; i<subCompSchemes.size(); i++) {
			subCompSchemes.get(i).allocateTenants();
		}
		return;
	}
	
	public void allocateFailures() {
		if (isAtomicComposition) {
			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, this.name + ": Atomic service found, failure number is " + this.failureNum);
			return;
		}
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Begin: Toatal failure number is " + this.failureNum + ", sub schemes number is " + subCompSchemes.size());
		/* Set the tenants number */
		if (this.pattern == CompositionPattern.SEQUENCE ||
				this.pattern == CompositionPattern.PARALLEL) {
			int totalFailure = 0;
			for (int i=0; i<subCompSchemes.size()-1; i++) {
				subCompSchemes.get(i).failureNum = this.failureNum/subCompSchemes.size();
				if (subCompSchemes.get(i).failureNum == 0) {
					subCompSchemes.get(i).failureNum = 1;
				}
				totalFailure += subCompSchemes.get(i).failureNum;
				LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Sub Comp Schems " + i + " failure number is " + subCompSchemes.get(i).failureNum);
			}
			
			subCompSchemes.get(subCompSchemes.size()-1).failureNum = this.failureNum - totalFailure;
			
			if (subCompSchemes.get(subCompSchemes.size()-1).failureNum <= 0) {
				LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Error in allocate failure number while this.failureNum is " + this.failureNum);
				System.exit(0);
			}
			
		} else {
			subCompSchemes.get(0).failureNum = this.failureNum / 3;
			subCompSchemes.get(subCompSchemes.size()-1).failureNum = this.failureNum / 3;
			int failureNumForChoice = this.failureNum - (this.failureNum * 2 / 3);
			int allocatedFailure = 0;
			for (int i=1; i<subCompSchemes.size()-1; i++) {
				if (i == subCompSchemes.size()-2) {
					subCompSchemes.get(i).failureNum = failureNumForChoice - allocatedFailure;
				} else {
					LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "SubCompScheme " + i + " tenants number is " + subCompSchemes.get(i).tenantsNum);
					LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "This.tenants Number is " + this.tenantsNum);
					subCompSchemes.get(i).failureNum = failureNumForChoice * (subCompSchemes.get(i).tenantsNum / this.tenantsNum);
					allocatedFailure += subCompSchemes.get(i).failureNum; 					
				}
			}
		}
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "End failure number allocation, begin sub schemes allocation...");
		/* allocate tenants for sub composition schemes */
		for (int i=0; i<subCompSchemes.size(); i++) {
			subCompSchemes.get(i).allocateFailures();
		}
		
		return;
	}

	public double getTenantsWeight() {
		return (double)this.tenantsNum / Config.NUM_TENANTS;
	}
	
	public void generateTenantQoSPrferences(double rt, double tp) {
		if (isAtomicComposition) {
			tenantQoSPreferences = new double[this.tenantsNum][Config.NUM_QOS];
			for (int i=0; i<this.tenantsNum; i++) {
				tenantQoSPreferences[i][Config.QOS_INDEX_COST] = 0.25;
				tenantQoSPreferences[i][Config.QOS_INDEX_RELIABLITY] = 0.25;
				tenantQoSPreferences[i][Config.QOS_INDEX_RESPONSETIME] = rt;
				tenantQoSPreferences[i][Config.QOS_INDEX_THROUGHPUT] = tp;			
			}

//			Random rand = new Random();
//			
//			for (int i=0; i<this.tenantsNum; i++) {
//				double left = 1.0;
//				//no cost preferences
//				for (int j=0; j<Config.NUM_QOS; j++) {
//					tenantQoSPreferences[i][j]  = 0;
//					if (j == Config.NUM_QOS - 1) {
//						tenantQoSPreferences[i][j] = left;
//					} else {
//						if (j == Config.QOS_INDEX_COST ||  j == Config.QOS_INDEX_RELIABLITY) {
//							tenantQoSPreferences[i][j] = 0;
//						} else if (j == Config.QOS_INDEX_RESPONSETIME) {
//							double rtp = rand.nextDouble();
//							while (rtp < 0.8) {
//								rtp = rand.nextDouble();
//							}
//							tenantQoSPreferences[i][j] = rtp;
//							//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Response time preference: " + rtp);
//							
//						} else { //useless now
//							while (0 >= tenantQoSPreferences[i][j] || tenantQoSPreferences[i][j] > 0.2) {
//								tenantQoSPreferences[i][j] = rand.nextDouble() * left;
//							}							
//						}
//					}
//					left = left - tenantQoSPreferences[i][j];	
//
//				}
//			}
		
		} else {
			for (int i=0; i<this.subCompSchemes.size(); i++) {
				this.subCompSchemes.get(i).generateTenantQoSPrferences(rt, tp);
			}
		}
		
	}
	
	public void calculateCriticality() {
		double cri = 0;
//		System.out.println("S" + this.id + " RT Criticality is " + this.criticality[Config.QOS_INDEX_RESPONSETIME]);
//		System.out.println("S" + this.id + " RE Criticality is " + this.criticality[Config.QOS_INDEX_RELIABLITY]);
//		System.out.println("S" + this.id + " TP Criticality is " + this.criticality[Config.QOS_INDEX_THROUGHPUT]);
//		System.out.println("S" + this.id + " tenants number is " + this.tenantsNum);
		
		for (int i=0; i<this.tenantsNum; i++) {
			//System.out.println("S" + this.id + " preference of tenants " + i + ": " + Arrays.toString(tenantQoSPreferences[i]));
			for (int j=0; j<Config.NUM_QOS; j++) {
				cri += criticality[j] * tenantQoSPreferences[i][j];
			}			
		}
		cri = cri/this.tenantsNum;
		this.overallCriticality = cri;
		//LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Composition Scheme " + id + " Criticality is " + cri);
		
		//System.out.println("S" + this.id + " criticality: " + Arrays.toString(this.criticality) + ", overall criticality is: " + cri);
	}
	/*  */
	public void genSubCompositionSchema() {
		int subSchemeNum = 0;
		int[] subAvailableServiceNum;
		int leftServiceNum = 0;
		double[] prob;
		double totalProb = 0;
		CompositionPattern[] cptn;
		CompositionScheme subScheme = null;
		
		/* if is atomic service no need to generate sub composition schemes */
		if (isAtomicComposition) {
			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, this.name + ": Atomic service found, sub compositions cannot be generated");
			return;
		}
		
		/* Generate sub composition scheme number, including the entry and exit points,
		 * and sub composition schemes in the sequence (at least 1 and at most 1) */
		Random rand = new Random();
		if (CompositionPattern.SEQUENCE == pattern) {
			while (Config.MIN_SUB_COMPOSITION_SCHEME_NUM_FOR_SEQUENCE > subSchemeNum 
					||  Config.MAX_SUB_COMPOSITION_SCHEME_NUM_FOR_SEQUENCE < subSchemeNum) {
				subSchemeNum = rand.nextInt(this.availableServiceNum + 1);
			}
		} else {
			/* The minimum number of sub composition schemes for CHOICE and PARALLEL
			 * pattern is Config.MIN_SUB_COMPOSITION_SCHEME_NUM_FOR_CHOICE_PARALLEL (4 fow now),
			 * and the maximum number is Config.MAX_SUB_COMPOSITION_SCHEME_NUM_FOR_CHOICE_PARALLEL (6 for now)
			 * including an entry point and an exit point, and branches (at least 2, at most 3) 
			 * These parameters should come from user-defined parameters */
			while (Config.MIN_SUB_COMPOSITION_SCHEME_NUM_FOR_CHOICE_PARALLEL > subSchemeNum 
					|| Config.MAX_SUB_COMPOSITION_SCHEME_NUM_FOR_CHOICE_PARALLEL < subSchemeNum) {
				subSchemeNum = rand.nextInt(this.availableServiceNum + 1);
			}			
		}
		
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, this.name + ": Generated sub composition number is " + subSchemeNum + 
				", available service number is " + this.availableServiceNum);
		
		/* Distribute available services among sub composition schemes */
		subAvailableServiceNum = new int[subSchemeNum];
		leftServiceNum = this.availableServiceNum;
		for (int i=0; i<subSchemeNum - 1; i++) {
			while (0 >= subAvailableServiceNum[i]) {
				subAvailableServiceNum[i] = rand.nextInt(leftServiceNum - (subSchemeNum - i) + 1) + 1;
				LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, this.name + ": Got available service number for sub scheme " + i + " : " + subAvailableServiceNum[i]);
			}
			
			leftServiceNum -= subAvailableServiceNum[i];
		}
		subAvailableServiceNum[subSchemeNum-1] = leftServiceNum;
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, this.name + ": Got available service number for sub scheme " + (subSchemeNum-1) + " : " + leftServiceNum);
		
		/* Generate composition patterns of all sub composition schemes */
		cptn = new CompositionPattern[subSchemeNum];
		for (int i=0; i<subSchemeNum; i++) {

			if (Config.MIN_SERVICE_NUM_FOR_CHOICE_PARALLEL > subAvailableServiceNum[i]) {
				cptn[i] = CompositionPattern.SEQUENCE;
			} else {
				int pattern = CompositionPattern.CHOICE.nCode;
				int randomp = rand.nextInt(6);
				if (randomp == 0) {
					pattern = CompositionPattern.SEQUENCE.nCode;
				} else {
					pattern = rand.nextInt(CompositionPattern.MAXPATTERN.nCode);
					while (pattern == CompositionPattern.SEQUENCE.nCode) {
						pattern = rand.nextInt(CompositionPattern.MAXPATTERN.nCode);
					}
				}
				/* Generate pattern randomly with the amount of the services left */
				//int pattern = rand.nextInt(CompositionPattern.MAXPATTERN.nCode);
				/*
				while (pattern == CompositionPattern.PARALLEL.nCode) {
					pattern = rand.nextInt(CompositionPattern.MAXPATTERN.nCode);
				}
				*/
				cptn[i] = CompositionPattern.valueOf(pattern);
			}
			/* For simple purpose, use SEQUENCE pattern temporarily */
			//cptn[i] = CompositionPattern.SEQUENCE;
			
		}
		
		/* Generate the probability of branches */
		prob = new double[subSchemeNum];
		prob[0] = 1;
		prob[subSchemeNum-1] = 1;
		for (int i=1; i<subSchemeNum-1; i++) {
			if (this.pattern == CompositionPattern.SEQUENCE || 
					this.pattern == CompositionPattern.PARALLEL) {
				prob[i] = 1;
			} else {
				/* Here 2 is the nubmer of entry point and exit point
				 * only generate probability randomly for the branches */
				if (i == subSchemeNum - 2) {
					prob[i] = 1 - totalProb;
				} else {
					while (0 >= prob[i]) {
						prob[i] = rand.nextDouble() * (1 - totalProb);
					}
				}
				totalProb += prob[i];
			}
		}
		
		int serviceId = this.serviceIdBase;
		for (int i=0; i<subSchemeNum; i++) {			
			
			subScheme = new CompositionScheme(cptn[i], subAvailableServiceNum[i], serviceId);
			serviceId += subAvailableServiceNum[i];
			if (!subScheme.isAtomicComposition) {
				subScheme.setName(this.name + "->SubScheme " + i);
			}
			subScheme.setProbability(prob[i]);
			this.subCompSchemes.add(subScheme);
			//subScheme.genSubCompositionSchema();		
		}
		
		for (int i=0; i<subSchemeNum; i++) {
			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, this.name + ": Generated pattern for sub composition scheme " + i + " is " 
					+ cptn[i].name() + ", available service number is " + subAvailableServiceNum[i] 
							+ ", probability is " + prob[i]);
		}
		
		for (int i=0; i<subSchemeNum; i++) {			
			this.subCompSchemes.get(i).genSubCompositionSchema();
		}
	}
	public void genSubCompositionSchemaTMP() {
		int subSchemeNum = 0;
		int[] subAvailableServiceNum;
		int leftServiceNum = 0;
		double[] prob;
		double totalProb = 0;
		CompositionPattern[] cptn;
		CompositionScheme subScheme = null;
		
		/* if is atomic service no need to generate sub composition schemes */
		if (isAtomicComposition) {
			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, this.name + ": Atomic service found, sub compositions cannot be generated");
			return;
		}
		
		/* Generate sub composition scheme number, including the entry and exit points,
		 * and sub composition schemes in the sequence (at least 1 and at most 1) */
		Random rand = new Random();
		if (CompositionPattern.SEQUENCE == pattern) {
			subSchemeNum = 1;

		} else {
			/* The minimum number of sub composition schemes for CHOICE and PARALLEL
			 * pattern is Config.MIN_SUB_COMPOSITION_SCHEME_NUM_FOR_CHOICE_PARALLEL (4 fow now),
			 * and the maximum number is Config.MAX_SUB_COMPOSITION_SCHEME_NUM_FOR_CHOICE_PARALLEL (6 for now)
			 * including an entry point and an exit point, and branches (at least 2, at most 3) 
			 * These parameters should come from user-defined parameters */
			if (this.availableServiceNum == 9) {
				subSchemeNum = 5;	
			} else {
				subSchemeNum = 5;	
			}
				
		}
		
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, this.name + ": Generated sub composition number is " + subSchemeNum + 
				", available service number is " + this.availableServiceNum);
		
		/* Distribute available services among sub composition schemes */
		subAvailableServiceNum = new int[subSchemeNum];
		leftServiceNum = this.availableServiceNum;
		subAvailableServiceNum[0] = 1;
		subAvailableServiceNum[1] = 1;
		if (this.availableServiceNum == 9) {
			subAvailableServiceNum[2] = 5;
		} else {
			subAvailableServiceNum[2] = 1;
		}
		
		subAvailableServiceNum[3] = 1;
		subAvailableServiceNum[4] = 1;
		
		/* Generate composition patterns of all sub composition schemes */
		cptn = new CompositionPattern[subSchemeNum];
		for (int i=0; i<subSchemeNum; i++) {

			if (Config.MIN_SERVICE_NUM_FOR_CHOICE_PARALLEL > subAvailableServiceNum[i]) {
				cptn[i] = CompositionPattern.SEQUENCE;
			} else {
				/* Generate pattern randomly with the amount of the services left */
				int pattern = rand.nextInt(CompositionPattern.MAXPATTERN.nCode);
				/*
				while (pattern == CompositionPattern.PARALLEL.nCode) {
					pattern = rand.nextInt(CompositionPattern.MAXPATTERN.nCode);
				}
				*/
				cptn[i] = CompositionPattern.PARALLEL;
			}
			/* For simple purpose, use SEQUENCE pattern temporarily */
			//cptn[i] = CompositionPattern.SEQUENCE;
			
		}
		
		/* Generate the probability of branches */
		prob = new double[subSchemeNum];
		prob[0] = 1;
		prob[subSchemeNum-1] = 1;
		for (int i=1; i<subSchemeNum-1; i++) {
			if (this.pattern == CompositionPattern.SEQUENCE || 
					this.pattern == CompositionPattern.PARALLEL) {
				prob[i] = 1;
			} else {
				/* Here 2 is the nubmer of entry point and exit point
				 * only generate probability randomly for the branches */
				if (i == subSchemeNum - 2) {
					prob[i] = 1 - totalProb;
				} else {
					while (0 >= prob[i]) {
						prob[i] = rand.nextDouble() * (1 - totalProb);
					}
				}
				totalProb += prob[i];
			}
		}
		
		int serviceId = this.serviceIdBase;
		for (int i=0; i<subSchemeNum; i++) {			
			
			subScheme = new CompositionScheme(cptn[i], subAvailableServiceNum[i], serviceId);
			serviceId += subAvailableServiceNum[i];
			if (!subScheme.isAtomicComposition) {
				subScheme.setName(this.name + "->SubScheme " + i);
			}
			subScheme.setProbability(prob[i]);
			this.subCompSchemes.add(subScheme);
			//subScheme.genSubCompositionSchema();		
		}
		
		for (int i=0; i<subSchemeNum; i++) {
			LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, this.name + ": Generated pattern for sub composition scheme " + i + " is " 
					+ cptn[i].name() + ", available service number is " + subAvailableServiceNum[i] 
							+ ", probability is " + prob[i]);
		}
		
		for (int i=0; i<subSchemeNum; i++) {			
			this.subCompSchemes.get(i).genSubCompositionSchemaTMP();
		}
	}
	
	public void outputSubCompoList(int level) {
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "------------------------------------------------------");
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Level" + level + " " + this.name);
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "pattern is " + this.pattern.name() + ", probability is " + this.probability + 
				", available service number is " + this.availableServiceNum + ", sub composition scheme number is " +
				this.subCompSchemes.size());
		for (int i=0; i<subCompSchemes.size(); i++) {
			subCompSchemes.get(i).outputSubCompoList(level + 1);
		}
		LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "------------------------------------------------------");
	}

	public void extractAtomicCompositionSchemes(ArrayList<CompositionScheme> atomicCompSchemes) {
		for (int i=0; i<subCompSchemes.size(); i++) {
			if (true == subCompSchemes.get(i).isAtomicComposition()) {
				LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "Extract atomic composition scheme " + subCompSchemes.get(i).getName());
				atomicCompSchemes.add(subCompSchemes.get(i));
			} else {
				subCompSchemes.get(i).extractAtomicCompositionSchemes(atomicCompSchemes);
			}
		}
	}
	
	public CompositionScheme findLeftMost() {
		if (true == isAtomicComposition()) {
			return this;
		}
		return subCompSchemes.get(0).findLeftMost();
	}
	
	public CompositionScheme findRightMost() {
		if (true == isAtomicComposition()) {
			return this;
		}
		return subCompSchemes.get(subCompSchemes.size()-1).findRightMost();
	}
	
	public void extractEdges(ArrayList<Edge> edges) {
		/* find leftmost and rightmost iteratively */
		CompositionScheme leftMost = findLeftMost(); 
		CompositionScheme rightMost = findRightMost();
		if (pattern == CompositionPattern.SEQUENCE) {
			for (int i=0; i<subCompSchemes.size()-1; i++) {
				rightMost = subCompSchemes.get(i).findRightMost();
				leftMost = subCompSchemes.get(i+1).findLeftMost();
				edges.add(new Edge(rightMost.getId(), leftMost.getId(), leftMost.getProbability()));
			}
		} else {
			rightMost = subCompSchemes.get(0).findRightMost();
			for (int i=1; i<subCompSchemes.size()-1; i++) {
				leftMost = subCompSchemes.get(i).findLeftMost();
				edges.add(new Edge(rightMost.getId(), leftMost.getId(), subCompSchemes.get(i).getProbability()));
				edges.add(new Edge(subCompSchemes.get(i).findRightMost().getId(), 
						subCompSchemes.get(subCompSchemes.size()-1).findLeftMost().getId(), 1.0));
			}
		}
		
		for (int i=0; i<subCompSchemes.size(); i++) {
			subCompSchemes.get(i).extractEdges(edges);
		}
	}
	
	public void caclulateQosForSequence() {
		this.utility = 0;
		for (int j=0; j<subCompSchemes.size(); j++) {
			this.utility += subCompSchemes.get(j).utility;
		}
		for (int i=0; i<Config.NUM_QOS; i++) {
			
			qosValues[i] = 0;
			
			if (Config.QOS_INDEX_THROUGHPUT == i) {
				qosValues[i] = subCompSchemes.get(0).getQosValues()[i];
				for (int j=0; j<subCompSchemes.size(); j++) {
					if (qosValues[i] > subCompSchemes.get(j).getQosValues()[i]) {
						qosValues[i] = subCompSchemes.get(j).getQosValues()[i];
					}
				}	
				
			} else if (Config.QOS_INDEX_RELIABLITY == i) {
				qosValues[i] = subCompSchemes.get(0).getQosValues()[i];
				for (int j=1; j<subCompSchemes.size(); j++) {
					qosValues[i] *= subCompSchemes.get(j).getQosValues()[i];
				} 
			} else if (Config.QOS_INDEX_RESPONSETIME == i || 
					Config.QOS_INDEX_COST == i) {
				for (int j=0; j<subCompSchemes.size(); j++) {
					qosValues[i] += subCompSchemes.get(j).getQosValues()[i];
					// if is a failed atomic service without redundancy
					/*
					if (Config.QOS_INDEX_RESPONSETIME == i 
							&& subCompSchemes.get(j).isAtomicComposition == true 
							&& subCompSchemes.get(j).isFailed == true
							&& subCompSchemes.get(j).isRedundant == false) {
						qosValues[i] += subCompSchemes.get(j).getFailPenalty();
						LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, "S" + subCompSchemes.get(j).getId() + " failed, penalty " + subCompSchemes.get(j).getFailPenalty() + " added");
					}
					*/
				}
			} 
		}
	}
	
	public void caclulateQosForParallel() {
		this.utility = 0;
		for (int j=0; j<subCompSchemes.size(); j++) {
			this.utility += subCompSchemes.get(j).utility;
		}
		
		for (int i=0; i<Config.NUM_QOS; i++) {
			qosValues[i] = 0;
			if (Config.QOS_INDEX_THROUGHPUT == i) {
				qosValues[i] = subCompSchemes.get(0).getQosValues()[i];
				for (int j=0; j<subCompSchemes.size(); j++) {
					if (qosValues[i] > subCompSchemes.get(j).getQosValues()[i]) {
						qosValues[i] = subCompSchemes.get(j).getQosValues()[i];
					}
				}
				
			} else if (Config.QOS_INDEX_RELIABLITY == i) {
				double qosBranchSum = 1.0;
				qosValues[i] = subCompSchemes.get(0).getQosValues()[i];
				for (int j=1; j<subCompSchemes.size()-1; j++) {
					qosBranchSum *= (subCompSchemes.get(j).getQosValues()[i]);
				}
				qosValues[i] = qosValues[i] * qosBranchSum * subCompSchemes.get(subCompSchemes.size()-1).getQosValues()[i];
				
			} else if (Config.QOS_INDEX_COST == i) {
				for (int j=0; j<subCompSchemes.size(); j++) {
					qosValues[i] += subCompSchemes.get(j).getQosValues()[i];
				}
			} else if (Config.QOS_INDEX_RESPONSETIME == i) {
				qosValues[i] = subCompSchemes.get(0).getQosValues()[i];
				double qosBranchSum = 0;
				for (int j=1; j< subCompSchemes.size()-1; j++) {
					if (qosBranchSum < subCompSchemes.get(j).getQosValues()[i]) {
						qosBranchSum = subCompSchemes.get(j).getQosValues()[i];
					}
				}
				qosValues[i] += (qosBranchSum + subCompSchemes.get(subCompSchemes.size()-1).getQosValues()[i]);
			}
		}
	}

	public void caclulateQosForChoice() {
		this.utility = 0;
		
		double utiBranchSum = 0;
		this.utility = subCompSchemes.get(0).utility;
		for (int j=1; j<subCompSchemes.size()-1; j++) {
			utiBranchSum += (subCompSchemes.get(j).utility * subCompSchemes.get(j).getProbability());
		}
		this.utility = this.utility + utiBranchSum + subCompSchemes.get(subCompSchemes.size()-1).utility;

		
		for (int i=0; i<Config.NUM_QOS; i++) {
			qosValues[i] = 0;
			if (Config.QOS_INDEX_THROUGHPUT == i) {
				double qosBranchSum = 0;
				qosValues[i] = subCompSchemes.get(0).getQosValues()[i];
				for (int j=1; j<subCompSchemes.size()-1; j++) {
					qosBranchSum += (subCompSchemes.get(j).getQosValues()[i] * subCompSchemes.get(j).getProbability());
				}
				if (qosValues[i] > qosBranchSum) {
					qosValues[i] = qosBranchSum;
				}
				if (qosValues[i] > subCompSchemes.get(subCompSchemes.size()-1).getQosValues()[i]) {
					qosValues[i] = subCompSchemes.get(subCompSchemes.size()-1).getQosValues()[i];
				}	
				
			} else if (Config.QOS_INDEX_COST == i && Config.SUM_COST_WO_PROB == true) {
				for (int j=0; j<subCompSchemes.size(); j++) {
					qosValues[i] += subCompSchemes.get(j).getQosValues()[i];
				}
			} else if (Config.QOS_INDEX_RELIABLITY == i) {
				double qosBranchSum = 1.0;
				qosValues[i] = subCompSchemes.get(0).getQosValues()[i];
				for (int j=1; j<subCompSchemes.size()-1; j++) {
					qosBranchSum *= (subCompSchemes.get(j).getQosValues()[i]);
				}
				qosValues[i] = qosValues[i] * qosBranchSum * subCompSchemes.get(subCompSchemes.size()-1).getQosValues()[i];
				
			} else if ((Config.QOS_INDEX_COST == i && Config.SUM_COST_WO_PROB == false) || Config.QOS_INDEX_RESPONSETIME == i) {
				double qosBranchSum = 0;
				qosValues[i] = subCompSchemes.get(0).getQosValues()[i];
				for (int j=1; j<subCompSchemes.size()-1; j++) {
					qosBranchSum += (subCompSchemes.get(j).getQosValues()[i] * subCompSchemes.get(j).getProbability());
				}
				qosValues[i] = qosValues[i] + qosBranchSum + subCompSchemes.get(subCompSchemes.size()-1).getQosValues()[i];
			}
		}
	}

	public void calculateQos() {
		
		/* if is atomic service, no need to calculate qos */
		if (isAtomicComposition) {
			this.qosValues = this.serviceInstance.qos;
			return;
		}
		
		/* calculate qos for each sub composition */
		for (int i=0; i<subCompSchemes.size(); i++) {
			subCompSchemes.get(i).calculateQos();
		}
		/* calculate qos for this composition according to pattern and qos type */
		if (pattern == CompositionPattern.SEQUENCE) {
			caclulateQosForSequence();
		} else if (pattern == CompositionPattern.PARALLEL) {
			caclulateQosForParallel();
		} else if (pattern == CompositionPattern.CHOICE) {
			caclulateQosForChoice();
		}
	}
	
	public ServiceClass getSc() {
		return sc;
	}

	public void setSc(ServiceClass sc) {
		this.sc = sc;
	}

	public IloNumExpr getNumExprOfUtility(IloMPModeler  model, IloNumVar[][] varX, IloNumVar[] varY) throws IloException {
		if (isAtomicComposition) {
			IloNumExpr[] exprArray = new IloNumExpr[this.sc.aggServiceList.size()+1];
			exprArray[0] = model.prod(this.getServiceInstance().utility, model.sum(1.0, model.prod(-1.0, varY[id])));
			for (int j=1; j<=this.sc.aggServiceList.size(); j++) {
				exprArray[j] = model.prod(this.sc.aggServiceList.get(j-1).utility, varX[id][j-1]);
			}
			return model.sum(exprArray);
		}
		
		IloNumExpr[] exprArrayForSubComp = new IloNumExpr[this.subCompSchemes.size()];
		
		for (int i=0; i<this.subCompSchemes.size(); i++) {						
			exprArrayForSubComp[i] = this.subCompSchemes.get(i).getNumExprOfUtility(model, varX, varY);			
		}
		return model.sum(exprArrayForSubComp);
	}
	
	public IloNumExpr getNumExprOfQoS(int qosIndex, IloMPModeler  model, IloNumVar[][] varX, IloNumVar[] varY) throws IloException {
		if (isAtomicComposition) {
			IloNumExpr[] exprArray = new IloNumExpr[this.sc.aggServiceList.size()+1];
			if (Config.QOS_INDEX_RELIABLITY == qosIndex) {
				exprArray[0] = model.prod(Math.log(this.getServiceInstance().qos[qosIndex]), model.sum(1.0, model.prod(-1.0, varY[id])));
			} else if (Config.QOS_INDEX_FB == qosIndex) {
				exprArray[0] = model.prod(Math.log(this.getServiceInstance().failureProbability), model.sum(1.0, model.prod(-1.0, varY[id])));
			} else if (qosIndex != Config.QOS_INDEX_UTILITY && qosIndex != Config.QOS_INDEX_FTCOST){
				exprArray[0] = model.prod(this.getServiceInstance().qos[qosIndex], model.sum(1.0, model.prod(-1.0, varY[id])));
			} else if (qosIndex == Config.QOS_INDEX_UTILITY) {
				exprArray[0] = model.prod(this.getServiceInstance().utility, model.sum(1.0, model.prod(-1.0, varY[id])));
			} else if (qosIndex == Config.QOS_INDEX_FTCOST) {
				exprArray[0] = model.prod(0.0, model.sum(1.0, model.prod(-1.0, varY[id])));
			}
			
			for (int j=1; j<=this.sc.aggServiceList.size(); j++) {
				if (Config.QOS_INDEX_RELIABLITY == qosIndex) {
					exprArray[j] = model.prod(Math.log(this.sc.aggServiceList.get(j-1).qos[qosIndex]), varX[id][j-1]);
				} else if (Config.QOS_INDEX_FB == qosIndex) {
					exprArray[j] = model.prod(Math.log(this.sc.aggServiceList.get(j-1).failureProbability), varX[id][j-1]);
				} else if (qosIndex == Config.QOS_INDEX_FTCOST) {
					exprArray[j] = model.prod(this.sc.aggServiceList.get(j-1).qos[Config.QOS_INDEX_COST] - this.getServiceInstance().qos[Config.QOS_INDEX_COST], 
							varX[id][j-1]);
				} else if (qosIndex == Config.QOS_INDEX_UTILITY){
					exprArray[j] = model.prod(this.sc.aggServiceList.get(j-1).utility, varX[id][j-1]);
				} else {
					exprArray[j] = model.prod(this.sc.aggServiceList.get(j-1).qos[qosIndex], varX[id][j-1]);
				}
			}
			return model.sum(exprArray);
		}
		/* get num expr for this composition according to pattern and qos type */
		if (pattern == CompositionPattern.SEQUENCE) {
			return getNumExprOfQoSForSequence(qosIndex, model, varX, varY);
		} else if (pattern == CompositionPattern.PARALLEL) {
			return getNumExprOfQoSForParallel(qosIndex, model, varX, varY);
		} else if (pattern == CompositionPattern.CHOICE) {
			return getNumExprOfQoSForChoice(qosIndex, model, varX, varY);
		}
		return null;
	}

	public IloNumExpr getNumExprOfQoSForSequence(int qosIndex, IloMPModeler  model, IloNumVar[][] varX, IloNumVar[] varY) throws IloException {
		/* return the num expr array of all sub compositions
		 * OR the minimized one
		 * OR the product of all sub compositions
		 * according to the type of QoS */
		//LogInfo.logInfo("getNumExprOfQoSForSequence");
		IloNumExpr expr = null;
		if (Config.QOS_INDEX_THROUGHPUT == qosIndex) {
			
			/* NumExpr: get the minimum QoS of all sub compositions */
			IloNumExpr[] exprArray = new IloNumExpr[this.subCompSchemes.size()];
			for (int i=0; i<this.subCompSchemes.size(); i++) {
				exprArray[i] = this.subCompSchemes.get(i).getNumExprOfQoS(qosIndex, model, varX, varY);			
			}
			expr = model.min(exprArray);

		} else if (Config.QOS_INDEX_COST == qosIndex 
				|| Config.QOS_INDEX_FTCOST == qosIndex 
				|| Config.QOS_INDEX_RESPONSETIME == qosIndex
				|| Config.QOS_INDEX_RELIABLITY == qosIndex 
				|| Config.QOS_INDEX_FB == qosIndex
				|| Config.QOS_INDEX_UTILITY == qosIndex) {
			
			/* NumExpr: sum the array of expr of all sub compositions  */
			
			IloNumExpr[] exprArray = new IloNumExpr[this.subCompSchemes.size()];
			for (int i=0; i<this.subCompSchemes.size(); i++) {
				exprArray[i] = this.subCompSchemes.get(i).getNumExprOfQoS(qosIndex, model, varX, varY);			
			}
			expr = model.sum(exprArray);	
		} else {
			//LogInfo.logInfo("Unrecongnized qos type");
		}
		return expr;
		
	}
	
	public IloNumExpr getNumExprOfQoSForParallel(int qosIndex, IloMPModeler  model, IloNumVar[][] varX, IloNumVar[] varY) throws IloException {
		/* get the num expr of parallel pattern
		 * with all the expr of sub compositions */
		IloNumExpr expr = null;

		if (Config.QOS_INDEX_THROUGHPUT == qosIndex) {
			/* NumExpr: get the minimum QoS of all sub compositions */
			IloNumExpr[] exprArray = new IloNumExpr[this.subCompSchemes.size()];
			for (int i=0; i<this.subCompSchemes.size(); i++) {
				exprArray[i] = this.subCompSchemes.get(i).getNumExprOfQoS(qosIndex, model, varX, varY);			
				LogInfo.logInfo(exprArray[i].toString());
			}
			expr = model.min(exprArray);			
		} else if (Config.QOS_INDEX_COST == qosIndex
				|| Config.QOS_INDEX_FTCOST == qosIndex 
				|| Config.QOS_INDEX_RELIABLITY == qosIndex
				|| Config.QOS_INDEX_FB == qosIndex
				|| Config.QOS_INDEX_UTILITY == qosIndex) {
			/* NumExpr: sum the array of expr of all sub compositions */
			IloNumExpr[] exprArray = new IloNumExpr[this.subCompSchemes.size()];
			for (int i=0; i<this.subCompSchemes.size(); i++) {
				exprArray[i] = this.subCompSchemes.get(i).getNumExprOfQoS(qosIndex, model, varX, varY);			
				//LogInfo.logInfo(exprArray[i].toString());
			}
			expr = model.sum(exprArray);

		} else if (Config.QOS_INDEX_RESPONSETIME == qosIndex) {
			/* NumExpr: get the maximum QoS of all sub compositions */
			IloNumExpr[] exprArray = new IloNumExpr[3];
			IloNumExpr[] exprBranch = new IloNumExpr[this.subCompSchemes.size()-2];
			exprArray[0] = this.subCompSchemes.get(0).getNumExprOfQoS(qosIndex, model, varX, varY);
			exprArray[2] = this.subCompSchemes.get(this.subCompSchemes.size()-1).getNumExprOfQoS(qosIndex, model, varX, varY);
			for (int i=1; i<this.subCompSchemes.size()-1; i++) {
				exprBranch[i-1] = this.subCompSchemes.get(i).getNumExprOfQoS(qosIndex, model, varX, varY);			
				LogInfo.logInfo(exprBranch[i-1].toString());
			}
			exprArray[1] = model.max(exprBranch);
			expr = model.sum(exprArray);
		}
		return expr;
		
	}
	
	public IloNumExpr getNumExprOfQoSForChoice(int qosIndex, IloMPModeler  model, IloNumVar[][] varX, IloNumVar[] varY) throws IloException {
		IloNumExpr expr = null;
		if (Config.QOS_INDEX_THROUGHPUT == qosIndex) {
			/* NumExpr: get the minimum QoS of all sub compositions
			 * with probability */
			IloNumExpr[] exprArray = new IloNumExpr[this.subCompSchemes.size()];
			for (int i=0; i<this.subCompSchemes.size(); i++) {
				exprArray[i] = model.prod(this.subCompSchemes.get(i).getProbability(), this.subCompSchemes.get(i).getNumExprOfQoS(qosIndex, model, varX, varY));			
				//LogInfo.logInfo(exprArray[i].toString());
			}
			expr = model.min(exprArray);

		} else if ((Config.QOS_INDEX_COST == qosIndex && Config.SUM_COST_WO_PROB == false) 
				|| Config.QOS_INDEX_UTILITY == qosIndex
				|| Config.QOS_INDEX_RESPONSETIME == qosIndex) {
			/* NumExpr: sum the array of expr of all sub compositions
			 * with probability */
			IloNumExpr[] exprArray = new IloNumExpr[this.subCompSchemes.size()];
			for (int i=0; i<this.subCompSchemes.size(); i++) {
				exprArray[i] = model.prod(this.subCompSchemes.get(i).getProbability(), this.subCompSchemes.get(i).getNumExprOfQoS(qosIndex, model, varX, varY));		
				//LogInfo.logInfo(exprArray[i].toString());
			}
			expr = model.sum(exprArray);

		} else if (Config.QOS_INDEX_RELIABLITY == qosIndex
				|| Config.QOS_INDEX_FTCOST == qosIndex
				|| Config.QOS_INDEX_FB == qosIndex
				|| (Config.QOS_INDEX_COST == qosIndex && Config.SUM_COST_WO_PROB == true)) {
			/* NumExpr: sum the array of expr of all sub compositions
			 * with probability */
			IloNumExpr[] exprArray = new IloNumExpr[this.subCompSchemes.size()];
			for (int i=0; i<this.subCompSchemes.size(); i++) {
				exprArray[i] = this.subCompSchemes.get(i).getNumExprOfQoS(qosIndex, model, varX, varY);
			}
			expr = model.sum(exprArray);

		} 
//		else if (Config.QOS_INDEX_RESPONSETIME == qosIndex) {
//			/* NumExpr: get the maximum QoS of all sub compositions
//			 * max (QoS * Probability) */
//			IloNumExpr[] exprArray = new IloNumExpr[3];
//			IloNumExpr[] exprBranch = new IloNumExpr[this.subCompSchemes.size()-2];
//			exprArray[0] = this.subCompSchemes.get(0).getNumExprOfQoS(qosIndex, model, varX, varY);
//			exprArray[2] = this.subCompSchemes.get(this.subCompSchemes.size()-1).getNumExprOfQoS(qosIndex, model, varX, varY);
//			for (int i=1; i<this.subCompSchemes.size()-1; i++) {
//				exprBranch[i-1] = model.prod(this.subCompSchemes.get(i).getProbability(), this.subCompSchemes.get(i).getNumExprOfQoS(qosIndex, model, varX, varY));			
//				//LogInfo.logInfo(exprBranch[i-1].toString());
//			}
//			exprArray[1] = model.max(exprBranch);
//			expr = model.sum(exprArray);
//
//		}
		return expr;
			
	}
	public IloNumExpr getNumExprOfUtility2(IloMPModeler  model, IloNumVar[][] varX) throws IloException {
		if (isAtomicComposition) {
			IloNumExpr[] exprArray = new IloNumExpr[this.sc.aggServiceList.size()+1];
			exprArray[0] = model.prod(this.getServiceInstance().utility, varX[id][0]);
			for (int j=1; j<=this.sc.aggServiceList.size(); j++) {
				exprArray[j] = model.prod(this.sc.aggServiceList.get(j-1).utility, varX[id][j]);
			}
			return model.sum(exprArray);
		}
		
		IloNumExpr[] exprArrayForSubComp = new IloNumExpr[this.subCompSchemes.size()];
		
		for (int i=0; i<this.subCompSchemes.size(); i++) {						
			exprArrayForSubComp[i] = this.subCompSchemes.get(i).getNumExprOfUtility2(model, varX);			
		}
		return model.sum(exprArrayForSubComp);
	}
	public IloNumExpr getNumExprOfQoS2(int qosIndex, IloMPModeler  model, IloNumVar[][] varX) throws IloException {
		if (isAtomicComposition) {
			IloNumExpr[] exprArray = new IloNumExpr[this.sc.aggServiceList.size()+1];
			if (Config.QOS_INDEX_RELIABLITY == qosIndex) {
				exprArray[0] = model.prod(Math.log(this.getServiceInstance().qos[qosIndex]), varX[id][0]);
			} else if (Config.QOS_INDEX_UTILITY == qosIndex) {
				exprArray[0] = model.prod(this.getServiceInstance().utility, varX[id][0]);
			} else if (Config.QOS_INDEX_FTCOST != qosIndex) {
				exprArray[0] = model.prod(this.getServiceInstance().qos[qosIndex], varX[id][0]);
			} else if (Config.QOS_INDEX_FTCOST == qosIndex) {
				exprArray[0] = model.prod(0.0, varX[id][0]);
			}
			
			for (int j=1; j<=this.sc.aggServiceList.size(); j++) {
				if (Config.QOS_INDEX_RELIABLITY == qosIndex) {
					exprArray[j] = model.prod(Math.log(this.sc.aggServiceList.get(j-1).qos[qosIndex]), varX[id][j]);
				} else if (Config.QOS_INDEX_FTCOST == qosIndex) {
					exprArray[j] = model.prod(this.sc.aggServiceList.get(j-1).qos[Config.QOS_INDEX_COST] - this.getServiceInstance().qos[Config.QOS_INDEX_COST], 
							varX[id][j]);
				} else if (Config.QOS_INDEX_UTILITY == qosIndex) {
					exprArray[j] = model.prod(this.sc.aggServiceList.get(j-1).utility, varX[id][j]);
				} else {
					exprArray[j] = model.prod(this.sc.aggServiceList.get(j-1).qos[qosIndex], varX[id][j]);
				}
			}
			return model.sum(exprArray);
		}
		/* get num expr for this composition according to pattern and qos type */
		if (pattern == CompositionPattern.SEQUENCE) {
			return getNumExprOfQoSForSequence2(qosIndex, model, varX);
		} else if (pattern == CompositionPattern.PARALLEL) {
			return getNumExprOfQoSForParallel2(qosIndex, model, varX);
		} else if (pattern == CompositionPattern.CHOICE) {
			return getNumExprOfQoSForChoice2(qosIndex, model, varX);
		}
		return null;
	}
	public IloNumExpr getNumExprOfQoSForSequence2(int qosIndex, IloMPModeler  model, IloNumVar[][] varX) throws IloException {
		/* return the num expr array of all sub compositions
		 * OR the minimized one
		 * OR the product of all sub compositions
		 * according to the type of QoS */
		//LogInfo.logInfo("getNumExprOfQoSForSequence");
		IloNumExpr expr = null;
		if (Config.QOS_INDEX_THROUGHPUT == qosIndex) {
			
			/* NumExpr: get the minimum QoS of all sub compositions */
			IloNumExpr[] exprArray = new IloNumExpr[this.subCompSchemes.size()];
			for (int i=0; i<this.subCompSchemes.size(); i++) {
				exprArray[i] = this.subCompSchemes.get(i).getNumExprOfQoS2(qosIndex, model, varX);			
			}
			expr = model.min(exprArray);

		} else if (Config.QOS_INDEX_COST == qosIndex
				|| Config.QOS_INDEX_FTCOST == qosIndex
				|| Config.QOS_INDEX_RESPONSETIME == qosIndex
				|| Config.QOS_INDEX_RELIABLITY == qosIndex
				|| Config.QOS_INDEX_UTILITY == qosIndex) {
			
			/* NumExpr: sum the array of expr of all sub compositions  */
			
			IloNumExpr[] exprArray = new IloNumExpr[this.subCompSchemes.size()];
			for (int i=0; i<this.subCompSchemes.size(); i++) {
				exprArray[i] = this.subCompSchemes.get(i).getNumExprOfQoS2(qosIndex, model, varX);			
			}
			expr = model.sum(exprArray);	
		} else {
			//LogInfo.logInfo("Unrecongnized qos type");
		}
		return expr;
		
	}
	
	public IloNumExpr getNumExprOfQoSForParallel2(int qosIndex, IloMPModeler  model, IloNumVar[][] varX) throws IloException {
		/* get the num expr of parallel pattern
		 * with all the expr of sub compositions */
		IloNumExpr expr = null;

		if (Config.QOS_INDEX_THROUGHPUT == qosIndex) {
			/* NumExpr: get the minimum QoS of all sub compositions */
			IloNumExpr[] exprArray = new IloNumExpr[this.subCompSchemes.size()];
			for (int i=0; i<this.subCompSchemes.size(); i++) {
				exprArray[i] = this.subCompSchemes.get(i).getNumExprOfQoS2(qosIndex, model, varX);			
				LogInfo.logInfo(exprArray[i].toString());
			}
			expr = model.min(exprArray);			
		} else if (Config.QOS_INDEX_COST == qosIndex
				|| Config.QOS_INDEX_FTCOST == qosIndex
				|| Config.QOS_INDEX_RELIABLITY == qosIndex
				|| Config.QOS_INDEX_UTILITY == qosIndex) {
			/* NumExpr: sum the array of expr of all sub compositions */
			IloNumExpr[] exprArray = new IloNumExpr[this.subCompSchemes.size()];
			for (int i=0; i<this.subCompSchemes.size(); i++) {
				exprArray[i] = this.subCompSchemes.get(i).getNumExprOfQoS2(qosIndex, model, varX);			
				//LogInfo.logInfo(exprArray[i].toString());
			}
			expr = model.sum(exprArray);

		} else if (Config.QOS_INDEX_RESPONSETIME == qosIndex) {
			/* NumExpr: get the maximum QoS of all sub compositions */
			IloNumExpr[] exprArray = new IloNumExpr[3];
			IloNumExpr[] exprBranch = new IloNumExpr[this.subCompSchemes.size()-2];
			exprArray[0] = this.subCompSchemes.get(0).getNumExprOfQoS2(qosIndex, model, varX);
			exprArray[2] = this.subCompSchemes.get(this.subCompSchemes.size()-1).getNumExprOfQoS2(qosIndex, model, varX);
			for (int i=1; i<this.subCompSchemes.size()-1; i++) {
				exprBranch[i-1] = this.subCompSchemes.get(i).getNumExprOfQoS2(qosIndex, model, varX);			
				LogInfo.logInfo(exprBranch[i-1].toString());
			}
			exprArray[1] = model.max(exprBranch);
			expr = model.sum(exprArray);
		}
		return expr;
		
	}
	
	public IloNumExpr getNumExprOfQoSForChoice2(int qosIndex, IloMPModeler  model, IloNumVar[][] varX) throws IloException {
		IloNumExpr expr = null;
		if (Config.QOS_INDEX_THROUGHPUT == qosIndex) {
			/* NumExpr: get the minimum QoS of all sub compositions
			 * with probability */
			IloNumExpr[] exprArray = new IloNumExpr[this.subCompSchemes.size()];
			for (int i=0; i<this.subCompSchemes.size(); i++) {
				exprArray[i] = model.prod(this.subCompSchemes.get(i).getProbability(), this.subCompSchemes.get(i).getNumExprOfQoS2(qosIndex, model, varX));			
				//LogInfo.logInfo(exprArray[i].toString());
			}
			expr = model.min(exprArray);

		} else if ((Config.QOS_INDEX_COST == qosIndex && Config.SUM_COST_WO_PROB == false) 
				|| Config.QOS_INDEX_UTILITY == qosIndex
				|| Config.QOS_INDEX_RESPONSETIME == qosIndex) {
			/* NumExpr: sum the array of expr of all sub compositions
			 * with probability */
			IloNumExpr[] exprArray = new IloNumExpr[this.subCompSchemes.size()];
			for (int i=0; i<this.subCompSchemes.size(); i++) {
				exprArray[i] = model.prod(this.subCompSchemes.get(i).getProbability(), this.subCompSchemes.get(i).getNumExprOfQoS2(qosIndex, model, varX));		
				//LogInfo.logInfo(exprArray[i].toString());
			}
			expr = model.sum(exprArray);

		} else if (Config.QOS_INDEX_RELIABLITY == qosIndex
				|| Config.QOS_INDEX_FTCOST == qosIndex
				|| (Config.QOS_INDEX_COST == qosIndex && Config.SUM_COST_WO_PROB == true)) {
			/* NumExpr: sum the array of expr of all sub compositions
			 * with probability */
			IloNumExpr[] exprArray = new IloNumExpr[this.subCompSchemes.size()];
			for (int i=0; i<this.subCompSchemes.size(); i++) {
				exprArray[i] = this.subCompSchemes.get(i).getNumExprOfQoS2(qosIndex, model, varX);
			}
			expr = model.sum(exprArray);

		}
//		else if (Config.QOS_INDEX_RESPONSETIME == qosIndex) {
//			/* NumExpr: get the maximum QoS of all sub compositions
//			 * max (QoS * Probability) */
//			IloNumExpr[] exprArray = new IloNumExpr[3];
//			IloNumExpr[] exprBranch = new IloNumExpr[this.subCompSchemes.size()-2];
//			exprArray[0] = this.subCompSchemes.get(0).getNumExprOfQoS2(qosIndex, model, varX);
//			exprArray[2] = this.subCompSchemes.get(this.subCompSchemes.size()-1).getNumExprOfQoS2(qosIndex, model, varX);
//			for (int i=1; i<this.subCompSchemes.size()-1; i++) {
//				exprBranch[i-1] = model.prod(this.subCompSchemes.get(i).getProbability(), this.subCompSchemes.get(i).getNumExprOfQoS2(qosIndex, model, varX));			
//				//LogInfo.logInfo(exprBranch[i-1].toString());
//			}
//			exprArray[1] = model.max(exprBranch);
//			expr = model.sum(exprArray);
//
//		}
		return expr;
			
	}

}
