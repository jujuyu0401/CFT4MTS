/**
 * 
 */
package composition;

/**
 * @author YanchunWang
 *
 */
public enum CompositionPattern {
	SEQUENCE(0), CHOICE(1),	PARALLEL(2), MAXPATTERN(3);
	
	int nCode = 0;
	
	private CompositionPattern(int nCode) {
		this.nCode = nCode;
	}
    public static CompositionPattern valueOf(int pattern) {
        if (pattern < 0 || pattern >= values().length) {
            throw new IndexOutOfBoundsException("Invalid pattern");
        }
        return values()[pattern];
    }	
    @Override
    public String toString() {
        return String.valueOf ( this.nCode );
    }
}
