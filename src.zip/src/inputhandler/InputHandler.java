package inputhandler;

public class InputHandler {

	public InputHandler() {
		// TODO Auto-generated constructor stub
	}

}
