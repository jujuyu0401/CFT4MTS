package output;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import log.LogInfo;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelWriter {
	XSSFWorkbook workbook;
	XSSFWorkbook summaryBook;
	
	XSSFSheet srSummary;
	XSSFSheet rtSummary;
	XSSFSheet tpSummary;
	XSSFSheet reSummary;
	XSSFSheet utSummary;
	XSSFSheet teSummary; //Affected tenant percentage
	XSSFSheet sgoSummary; //Time overhead of formulating aggregation services
	XSSFSheet ssoSummary; //Time overhead of selecting FT strategies
	
	XSSFSheet rstTimeSheet;
	XSSFSheet successRateSheet;
	XSSFSheet utilitySheet;
	XSSFSheet throughputSheet;
	XSSFSheet reliabilitySheet;
	XSSFSheet affectTenantSheet;
	XSSFSheet sgoSheet;
	XSSFSheet ssoSheet;
	
	String fileName;
	int recordNum = 0;
	double aveCriSR = 0;
	double aveWcriSR = 0;
	double aveRandomSR = 0;
	double aveFtcSR = 0;
	
	double aveCriRTIncrP = 0;
	double aveWcriRTIncrP = 0;
	double aveRandomRTIncrP = 0;
	double aveFtcRTIncrP = 0;
	
	double aveCriU = 0;
	double aveWcriU = 0;
	double aveRandomU = 0;
	double aveFtcU = 0;
	
	double aveCriTP = 0;
	double aveWcriTP = 0;
	double aveRandomTP = 0;
	double aveFtcTP = 0;
	
	double aveCriTPDecr = 0;
	double aveWcriTPDecr = 0;
	double aveRandomTPDecr = 0;
	double aveFtcTPDecr = 0;
	
	double aveCriTPDecrP = 0;
	double aveWcriTPDecrP = 0;
	double aveRandomTPDecrP = 0;
	double aveFtcTPDecrP = 0;
	
	double aveCriRE = 0;
	double aveWcriRE = 0;
	double aveRandomRE = 0;
	double aveFtcRE = 0;
	
	double aveCriREDecr = 0;
	double aveWcriREDecr = 0;
	double aveRandomREDecr = 0;
	double aveFtcREDecr = 0;
	
	double aveCriREDecrP = 0;
	double aveWcriREDecrP = 0;
	double aveRandomREDecrP = 0;
	double aveFtcREDecrP = 0;
	
	double aveCriAfTenantP = 0;
	double aveWcriAfTenantP = 0;
	double aveFtcAfTenantP = 0;
	double aveRandomAfTenantP = 0;
	
	double aveSgo = 0; // for all approaches
	
	double aveCriSso = 0;
	double aveWcriSso = 0;
	double aveFtcSso = 0;
	double aveRandomSso = 0;
	
	int budget = 0; 
	int totalTaskNum = 0;
	
	public ExcelWriter() {
		//rstTimeSheet = workbook.createSheet("ResponseTime");
		//initModelTitle(rstTimeSheet, new Object[] {"ORIGINAL", "WITH-C", "WITHOUT-C", "RANDOM"});
		FileInputStream summary;
		try {
			summary = new FileInputStream(new File("Summary.xlsx"));
			try {
				summaryBook = new XSSFWorkbook(summary);
				srSummary = summaryBook.getSheetAt(0);		
				rtSummary = summaryBook.getSheetAt(1);
				reSummary = summaryBook.getSheetAt(2);
				tpSummary = summaryBook.getSheetAt(3);
				utSummary = summaryBook.getSheetAt(4);
				teSummary = summaryBook.getSheetAt(5);
				sgoSummary = summaryBook.getSheetAt(6);
				ssoSummary = summaryBook.getSheetAt(7);

				summary.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		} catch (FileNotFoundException e) {
			summaryBook = new XSSFWorkbook();
			srSummary = summaryBook.createSheet("Success Rate");
			rtSummary = summaryBook.createSheet("Response Time Increment");
			reSummary = summaryBook.createSheet("Reliability Decrement");
			tpSummary = summaryBook.createSheet("Throughput Decrement");
			utSummary = summaryBook.createSheet("Utiltiy");
			teSummary = summaryBook.createSheet("Affected Tenants");
			sgoSummary = summaryBook.createSheet("Strategy Generation Overhead");
			ssoSummary = summaryBook.createSheet("Strategy Selection Overhead");
			
			initModelTitle(srSummary, new Object[] {"REDADUNT POLICY", "W-CRITICALITY", "W/O-CRITICALITY", "RANDOM", "FTCloud"});
			initModelTitle(rtSummary, new Object[] {"REDADUNT POLICY", "W-CRITICALITY", "W/O-CRITICALITY", "RANDOM", "FTCloud"});
			initModelTitle(reSummary, new Object[] {"REDADUNT POLICY", "W-CRITICALITY", "W/O-CRITICALITY", "RANDOM", "FTCloud"});
			initModelTitle(tpSummary, new Object[] {"REDADUNT POLICY", "W-CRITICALITY", "W/O-CRITICALITY", "RANDOM", "FTCloud"});
			initModelTitle(utSummary, new Object[] {"REDADUNT POLICY", "W-CRITICALITY", "W/O-CRITICALITY", "RANDOM", "FTCloud"});
			initModelTitle(teSummary, new Object[] {"REDADUNT POLICY", "W-CRITICALITY", "W/O-CRITICALITY", "RANDOM", "FTCloud"});
			initModelTitle(sgoSummary, new Object[] {"REDADUNT POLICY", "Overhead"});
			initModelTitle(ssoSummary, new Object[] {"REDADUNT POLICY", "W-CRITICALITY", "W/O-CRITICALITY", "RANDOM", "FTCloud"});
		}

	}
	public void newTestCase(String fileName, int budget, int totalNum) {
		this.fileName = fileName;
		workbook = new XSSFWorkbook();	
		this.budget = budget;
		this.totalTaskNum = totalNum;
		this.recordNum = 0;
		aveCriSR = 0;
		aveWcriSR = 0;
		aveRandomSR = 0;
		aveFtcSR = 0;
		
		aveCriRTIncrP = 0;
		aveWcriRTIncrP = 0;
		aveRandomRTIncrP = 0;
		aveFtcRTIncrP = 0;
		
		aveCriU = 0;
		aveWcriU = 0;
		aveRandomU = 0;
		aveFtcU = 0;
		
		aveCriTP = 0;
		aveWcriTP = 0;
		aveRandomTP = 0;
		aveFtcTP = 0;
		
		aveCriTPDecr = 0;
		aveWcriTPDecr = 0;
		aveRandomTPDecr = 0;
		aveFtcTPDecr = 0;
		
		aveCriTPDecrP = 0;
		aveWcriTPDecrP = 0;
		aveRandomTPDecrP = 0;
		aveFtcTPDecrP = 0;
		
		aveCriRE = 0;
		aveWcriRE = 0;
		aveRandomRE = 0;
		aveCriREDecr = 0;
		aveWcriREDecr = 0;
		aveRandomREDecr = 0;
		aveCriREDecrP = 0;
		aveWcriREDecrP = 0;
		aveRandomREDecrP = 0;
		
		aveCriAfTenantP = 0;
		aveWcriAfTenantP = 0;
		aveFtcAfTenantP = 0;
		aveRandomAfTenantP = 0;
		
		aveSgo = 0; // for all approaches
		
		aveCriSso = 0;
		aveWcriSso = 0;
		aveFtcSso = 0;
		aveRandomSso = 0;
	}
	public void createSheet(int testcase, int failureNum, int budget) {
		rstTimeSheet = workbook.createSheet("ResponseTime-T" + testcase + "-F" + failureNum + "-B" + budget);
		successRateSheet = workbook.createSheet("SuccessRate-T" + testcase + "-F" + failureNum + "-B" + budget);
		utilitySheet = workbook.createSheet("Utility-T" + testcase + "-F" + failureNum + "-B" + budget);
		throughputSheet = workbook.createSheet("Throughput-T" + testcase + "-F" + failureNum + "-B" + budget);
		reliabilitySheet = workbook.createSheet("Reliability-T" + testcase + "-F" + failureNum + "-B" + budget);
		affectTenantSheet = workbook.createSheet("AffectedTenant-T" + testcase + "-F" + failureNum + "-B" + budget);
		sgoSheet = workbook.createSheet("StrategyGeneration-T" + testcase + "-F" + failureNum + "-B" + budget);
		ssoSheet = workbook.createSheet("StrategySelection-T" + testcase + "-F" + failureNum + "-B" + budget);
		
		initModelTitle(rstTimeSheet, new Object[] {"FAILEDID", "ORIGINAL-RT", "DELAY", "W-C", "WO-C", "RANDOM", "FTCloud", 
				"ORIGINALRT", "W-C-FINALRT", "WO-C-FINALRT", "RANDOM-FINALRT", "FTCloud-FINALRT",
				"W-C-FINALRT-INCR", "WO-C-FINALRT-INCR", "RANDOM-FINALRT-INCR", "FTCloud-FINALRT-INCR",
				"W-C-FINALRT-INCR-P", "WO-C-FINALRT-INCR-P", "RANDOM-FINALRT-INCR-P", "FTCloud-FINALRT-INCR-P"});
		
		initModelTitle(successRateSheet, new Object[] {"FAILEDID", "W-C", "WO-C", "RANDOM", "FTCloud", "W-C-S", "WO-C-S", "RANDOM-S"});
		initModelTitle(utilitySheet, new Object[] {"W-C", "WO-C", "RANDOM", "FTCloud"});
		initModelTitle(throughputSheet, new Object[] {"FAILEDID", "ORIGINAL-TP", "DECREMENT", "W-C", "WO-C", "RANDOM", "FTCloud", 
				"ORIGINALTP", "W-C-FINALTP", "WO-C-FINALTP", "RANDOM-FINALTP", "FTCloud-FINALTP",
				"W-C-FINALTP-DECR", "WO-C-FINALTP-DECR", "RANDOM-FINALTP-DECR", "FTCloud-FINALTP-DECR",
				"W-C-FINALTP-DECR-P", "WO-C-FINALTP-DECR-P", "RANDOM-FINALTP-DECR-P", "FTCloud-FINALTP-DECR-P"});
		initModelTitle(reliabilitySheet, new Object[] {"FAILEDID", "ORIGINAL-RE", "INCREMENT", "W-C", "WO-C", "RANDOM", "FTCloud",
				"ORIGINALRE", "W-C-FINALRE", "WO-C-FINALRE", "RANDOM-FINALRE", "FTCloud-FINALRE",
				"W-C-FINALRE-DECR", "WO-C-FINALRE-DECR", "RANDOM-FINALRE-DECR", "FTCloud-FINALRE-DECR",
				"W-C-FINALRE-DECR-P", "WO-C-FINALRE-DECR-P", "RANDOM-FINALRE-DECR-P", "FTCloud-FINALRE-DECR-P"});
		initModelTitle(affectTenantSheet, new Object[] {"W-C", "WO-C", "RANDOM", "FTCloud"});
		initModelTitle(sgoSheet, new Object[] {"Overhead"});
		initModelTitle(ssoSheet, new Object[] {"W-C", "WO-C", "RANDOM", "FTCloud"});
	}
	
    public void initModelTitle(XSSFSheet sheet, Object[] myObj) {
        Map<String, Object[]> data = new TreeMap<String, Object[]>();
        data.put("1", myObj);
        Set<String> keyset = data.keySet();
        int rownum = 0;
        for (String key : keyset)
        {
            Row row = sheet.createRow(rownum++);
            Object [] objArr = data.get(key);
            int cellnum = 0;
            for (Object obj : objArr)
            {
               Cell cell = row.createCell(cellnum++);

               if(obj instanceof String)
                    cell.setCellValue((String)obj);
                else if(obj instanceof Integer)
                    cell.setCellValue((Integer)obj);
                else if(obj instanceof Double)
                    cell.setCellValue((Double)obj);
            }
        }   	
    }
    
    public void addTitle(XSSFSheet sheet, Object[] myObj) {
        Map<String, Object[]> data = new TreeMap<String, Object[]>();
        data.put("1", myObj);
        Set<String> keyset = data.keySet();
        int rownum = sheet.getLastRowNum();
        for (String key : keyset)
        {
            Row row = sheet.createRow(rownum++);
            Object [] objArr = data.get(key);
            int cellnum = 0;
            for (Object obj : objArr)
            {
               Cell cell = row.createCell(cellnum++);

               if(obj instanceof String)
                    cell.setCellValue((String)obj);
                else if(obj instanceof Integer)
                    cell.setCellValue((Integer)obj);
                else if(obj instanceof Double)
                    cell.setCellValue((Double)obj);
            }
        }   	
    }
    
    public void addRecordOfResponseTime(String failedId, double oriSrcRt, double delay, 
    		int criSR, int wcriSR, int randomSR, double ftcSR,
    		double oriRT, double criRT, double wcriRT, double randomRT, double ftcRT,
    		double criIncr, double wcriIncr, double randomIncr, double ftcIncr,
    		double criIncrP, double wcriIncrP, double randomIncrP, double ftcIncrP) {
    	//recordNum++;
    	
		int lastRow = rstTimeSheet.getLastRowNum();
		Row row = rstTimeSheet.createRow(lastRow + 1);
		int cellNum = 0;
		Cell cell0 = row.createCell(cellNum++);
		cell0.setCellValue(failedId);
		Cell cell100 = row.createCell(cellNum++);
		cell100.setCellValue(oriSrcRt);
		
		Cell cell1 = row.createCell(cellNum++);
		cell1.setCellValue(delay);
		
		Cell cell2 = row.createCell(cellNum++);
		cell2.setCellValue(criSR);
		
		Cell cell3 = row.createCell(cellNum++);
		cell3.setCellValue(wcriSR); 
		
		Cell cell4 = row.createCell(cellNum++);
		cell4.setCellValue(randomSR);
		
		Cell cell5 = row.createCell(cellNum++);
		cell5.setCellValue(ftcSR);
		
		Cell cell15 = row.createCell(cellNum++);
		cell15.setCellValue(oriRT);
		
		Cell cell6 = row.createCell(cellNum++);
		cell6.setCellValue(criRT);
		
		Cell cell7 = row.createCell(cellNum++);
		cell7.setCellValue(wcriRT); 
		
		Cell cell8 = row.createCell(cellNum++);
		cell8.setCellValue(randomRT); 
		
		Cell cell16 = row.createCell(cellNum++);
		cell16.setCellValue(ftcRT); 
		
		Cell cell9 = row.createCell(cellNum++);
		cell9.setCellValue(criIncr);
		Cell cell10 = row.createCell(cellNum++);
		cell10.setCellValue(wcriIncr);
		Cell cell11 = row.createCell(cellNum++);
		cell11.setCellValue(randomIncr);
		Cell cell17 = row.createCell(cellNum++);
		cell17.setCellValue(ftcIncr); 
		
		Cell cell12 = row.createCell(cellNum++);
		cell12.setCellValue(criIncrP);
		aveCriRTIncrP += criIncrP;
		Cell cell13 = row.createCell(cellNum++);
		cell13.setCellValue(wcriIncrP);
		aveWcriRTIncrP += wcriIncrP;
		Cell cell14 = row.createCell(cellNum++);
		cell14.setCellValue(randomIncrP);
		aveRandomRTIncrP += randomIncrP;
		Cell cell18 = row.createCell(cellNum++);
		cell18.setCellValue(ftcIncrP);
		aveFtcRTIncrP += ftcIncrP;
    }
    
    public void addRecordOfSuccessRate(String failId, int criSR, int wcriSR, int ftcSR, int randomSR, String criSolution, String wcriSolution, String randomSolution) {
		int lastRow = successRateSheet.getLastRowNum();
		Row row = successRateSheet.createRow(lastRow + 1);
		int cellNum = 0;
		Cell cell0 = row.createCell(cellNum++);
		cell0.setCellValue(failId);
		Cell cell1 = row.createCell(cellNum++);
		cell1.setCellValue(criSR);
		aveCriSR += criSR;
		Cell cell2 = row.createCell(cellNum++);
		cell2.setCellValue(wcriSR);
		aveWcriSR += wcriSR;
		Cell cell3 = row.createCell(cellNum++);
		cell3.setCellValue(randomSR);  
		aveRandomSR += randomSR;
		Cell cell4 = row.createCell(cellNum++);
		cell4.setCellValue(ftcSR);
		aveFtcSR += ftcSR; 	   
		
		//System.out.println("Succress rates: current CRI: " + criSR + ", WCRI: " + wcriSR + ", FTC: " + ftcSR + ", Random: " + randomSR);
    }
    
    public void addRecordOfThroughput(String failedId, double oriSrcTP, double decrement, 
    		int criSR, int wcriSR, int randomSR, int ftcSR,
    		double oriTP, double criTP, double wcriTP, double randomTP, double ftcTP,
    		double criDecr, double wcriDecr, double randomDecr, double ftcDecr,
    		double criDecrP, double wcriDecrP, double randomDecrP, double ftcDecrP) {
		int lastRow = throughputSheet.getLastRowNum();
		Row row = throughputSheet.createRow(lastRow + 1);
		int cellNum = 0;
		Cell cell0 = row.createCell(cellNum++);
		cell0.setCellValue(failedId);
		Cell cell100 = row.createCell(cellNum++);
		cell100.setCellValue(oriSrcTP);
		
		Cell cell1 = row.createCell(cellNum++);
		cell1.setCellValue(decrement);
		Cell cell2 = row.createCell(cellNum++);
		cell2.setCellValue(criSR);
		
		Cell cell3 = row.createCell(cellNum++);
		cell3.setCellValue(wcriSR); 
		
		Cell cell4 = row.createCell(cellNum++);
		cell4.setCellValue(randomSR);
		
		Cell cell15 = row.createCell(cellNum++);
		cell15.setCellValue(ftcSR);
		
		Cell cell5 = row.createCell(cellNum++);
		cell5.setCellValue(oriTP);
		Cell cell6 = row.createCell(cellNum++);
		cell6.setCellValue(criTP);
		Cell cell7 = row.createCell(cellNum++);
		cell7.setCellValue(wcriTP); 
		Cell cell8 = row.createCell(cellNum++);
		cell8.setCellValue(randomTP); 
		Cell cell16 = row.createCell(cellNum++);
		cell16.setCellValue(ftcTP);
		
		Cell cell9 = row.createCell(cellNum++);
		cell9.setCellValue(criDecr);
		Cell cell10 = row.createCell(cellNum++);
		cell10.setCellValue(wcriDecr);
		Cell cell11 = row.createCell(cellNum++);
		cell11.setCellValue(randomDecr);
		Cell cell17 = row.createCell(cellNum++);
		cell17.setCellValue(ftcDecr);
		
		Cell cell12 = row.createCell(cellNum++);
		cell12.setCellValue(criDecrP);
		aveCriTPDecrP += criDecrP;
		Cell cell13 = row.createCell(cellNum++);
		cell13.setCellValue(wcriDecrP);
		aveWcriTPDecrP += wcriDecrP;
		Cell cell14 = row.createCell(cellNum++);
		cell14.setCellValue(randomDecrP);
		aveRandomTPDecrP += randomDecrP;   
		Cell cell18 = row.createCell(cellNum++);
		cell18.setCellValue(ftcDecrP);
		aveFtcTPDecrP += ftcDecrP;   
    }
    
    public void addRecordOfReliability(String failedId, double oriSrcRE, double increment, int criSR, int wcriSR, int randomSR,
    		double oriRE, double criRE, double wcriRE, double randomRE,
    		double criIncr, double wcriIncr, double randomIncr,
    		double criIncrP, double wcriIncrP, double randomIncrP) {
		int lastRow = reliabilitySheet.getLastRowNum();
		Row row = reliabilitySheet.createRow(lastRow + 1);
		int cellNum = 0;
		Cell cell0 = row.createCell(cellNum++);
		cell0.setCellValue(failedId);
		Cell cell100 = row.createCell(cellNum++);
		cell100.setCellValue(oriSrcRE);
		
		Cell cell1 = row.createCell(cellNum++);
		cell1.setCellValue(increment);
		Cell cell2 = row.createCell(cellNum++);
		cell2.setCellValue(criSR);
		
		Cell cell3 = row.createCell(cellNum++);
		cell3.setCellValue(wcriSR); 
		
		Cell cell4 = row.createCell(cellNum++);
		cell4.setCellValue(randomSR);
		
		Cell cell5 = row.createCell(cellNum++);
		cell5.setCellValue(oriRE);
		Cell cell6 = row.createCell(cellNum++);
		cell6.setCellValue(criRE);
		Cell cell7 = row.createCell(cellNum++);
		cell7.setCellValue(wcriRE); 
		Cell cell8 = row.createCell(cellNum++);
		cell8.setCellValue(randomRE); 
		Cell cell9 = row.createCell(cellNum++);
		cell9.setCellValue(criIncr);
		Cell cell10 = row.createCell(cellNum++);
		cell10.setCellValue(wcriIncr);
		Cell cell11 = row.createCell(cellNum++);
		cell11.setCellValue(randomIncr);
		Cell cell12 = row.createCell(cellNum++);
		cell12.setCellValue(criIncrP);
		aveCriREDecrP += criIncrP;
		Cell cell13 = row.createCell(cellNum++);
		cell13.setCellValue(wcriIncrP);
		aveWcriREDecrP += wcriIncrP;
		Cell cell14 = row.createCell(cellNum++);
		cell14.setCellValue(randomIncrP);
		aveRandomREDecrP += randomIncrP;   	
    }

    public void addRecordOfUtility(double criUtility, double wcriUtility, double randomUtility, double ftcUtility) {
 		int lastRow = utilitySheet.getLastRowNum();
 		Row row = utilitySheet.createRow(lastRow + 1);
 		int cellNum = 0;
 		Cell cell0 = row.createCell(cellNum++);
 		cell0.setCellValue(criUtility);
 		aveCriU += criUtility;
 		Cell cell1 = row.createCell(cellNum++);
 		cell1.setCellValue(wcriUtility);
 		aveWcriU += wcriUtility;
 		Cell cell2 = row.createCell(cellNum++);
 		cell2.setCellValue(randomUtility);
 		aveRandomU += randomUtility;
 		Cell cell3 = row.createCell(cellNum++);
 		cell3.setCellValue(ftcUtility);
 		aveFtcU += ftcUtility;
 		
 		recordNum++;
     }

    public void addRecordOfAffectedTenant(double criAt, double wcriAt, double randomAt, double ftcAt) {
 		int lastRow = affectTenantSheet.getLastRowNum();
 		Row row = affectTenantSheet.createRow(lastRow + 1);
 		int cellNum = 0;
 		Cell cell0 = row.createCell(cellNum++);
 		cell0.setCellValue(criAt);
 		this.aveCriAfTenantP += criAt;
 		Cell cell1 = row.createCell(cellNum++);
 		cell1.setCellValue(wcriAt);
 		this.aveWcriAfTenantP += wcriAt;
 		Cell cell2 = row.createCell(cellNum++);
 		cell2.setCellValue(randomAt);
 		this.aveRandomAfTenantP += randomAt;
 		Cell cell3 = row.createCell(cellNum++);
 		cell3.setCellValue(ftcAt);
 		this.aveFtcAfTenantP += ftcAt;
     }

    public void addRecordOfStrategyGenerationOverhead(double sgo) {
 		int lastRow = sgoSheet.getLastRowNum();
 		Row row = sgoSheet.createRow(lastRow + 1);
 		int cellNum = 0;
 		Cell cell0 = row.createCell(cellNum++);
 		cell0.setCellValue(sgo);
 		this.aveSgo += sgo;
      }
    
    public void addRecordOfStrategySelectionOverhead(double criSso, double wcriSso, double randomSso, double ftcSso) {
 		int lastRow = ssoSheet.getLastRowNum();
 		Row row = ssoSheet.createRow(lastRow + 1);
 		int cellNum = 0;
 		Cell cell0 = row.createCell(cellNum++);
 		cell0.setCellValue(criSso);
 		this.aveCriSso += criSso;
 		Cell cell1 = row.createCell(cellNum++);
 		cell1.setCellValue(wcriSso);
 		this.aveWcriSso += wcriSso;
 		Cell cell2 = row.createCell(cellNum++);
 		cell2.setCellValue(randomSso);
 		this.aveRandomSso += randomSso;
 		Cell cell3 = row.createCell(cellNum++);
 		cell3.setCellValue(ftcSso);
 		this.aveFtcSso += ftcSso;
     }
    
     public void addAveRecord() {
  		int lastRow = utilitySheet.getLastRowNum();
  		Row row = utilitySheet.createRow(lastRow + 1);
  		int cellNum = 0;
  		Cell cell0 = row.createCell(cellNum++);
  		cell0.setCellValue(aveCriU/recordNum);

  		Cell cell1 = row.createCell(cellNum++);
  		cell1.setCellValue(aveWcriU/recordNum);

  		Cell cell2 = row.createCell(cellNum++);
  		cell2.setCellValue(aveRandomU/recordNum);
  		
  		Cell cell30 = row.createCell(cellNum++);
  		cell30.setCellValue(aveFtcU/recordNum);
  		
  		addSummary(utSummary, aveCriU/recordNum, aveWcriU/recordNum, aveRandomU/recordNum, aveFtcU/recordNum);
  		
		lastRow = rstTimeSheet.getLastRowNum();
		row = rstTimeSheet.createRow(lastRow + 1);
		cellNum = 0;
		cell0 = row.createCell(cellNum++);
		cell0.setCellValue("");
		cell1 = row.createCell(cellNum++);
		cell1.setCellValue("");
		
		Cell cell99 = row.createCell(cellNum++);
		cell99.setCellValue("");
		
		cell2 = row.createCell(cellNum++);
		cell2.setCellValue(aveCriSR/recordNum);
		
		Cell cell3 = row.createCell(cellNum++);
		cell3.setCellValue(aveWcriSR/recordNum); 
		
		Cell cell4 = row.createCell(cellNum++);
		cell4.setCellValue(aveRandomSR/recordNum);

		Cell cell31 = row.createCell(cellNum++);
		cell31.setCellValue(aveFtcSR/recordNum);
		
		Cell cell5 = row.createCell(cellNum++);
		cell5.setCellValue("");
		Cell cell6 = row.createCell(cellNum++);
		cell6.setCellValue("");
		Cell cell7 = row.createCell(cellNum++);
		cell7.setCellValue(""); 
		Cell cell8 = row.createCell(cellNum++);
		cell8.setCellValue(""); 
		Cell cell9 = row.createCell(cellNum++);
		cell9.setCellValue("");
		Cell cell10 = row.createCell(cellNum++);
		cell10.setCellValue("");
		Cell cell11 = row.createCell(cellNum++);
		cell11.setCellValue("");
		Cell cell12 = row.createCell(cellNum++);
		cell12.setCellValue(aveCriRTIncrP/recordNum);
		Cell cell13 = row.createCell(cellNum++);
		cell13.setCellValue(aveWcriRTIncrP/recordNum);
		Cell cell14 = row.createCell(cellNum++);
		cell14.setCellValue(aveRandomRTIncrP/recordNum);
		Cell cell32 = row.createCell(cellNum++);
		cell32.setCellValue(aveFtcRTIncrP/recordNum);
		

		addSummary(rtSummary, aveCriRTIncrP/recordNum, aveWcriRTIncrP/recordNum, aveRandomRTIncrP/recordNum, aveFtcRTIncrP/recordNum);
		
  		lastRow = throughputSheet.getLastRowNum();
  		row = throughputSheet.createRow(lastRow + 1);
		cellNum = 0;
		cell0 = row.createCell(cellNum++);
		cell0.setCellValue("");
		cell1 = row.createCell(cellNum++);
		cell1.setCellValue("");
		
		cell99 = row.createCell(cellNum++);
		cell99.setCellValue("");
		
		cell2 = row.createCell(cellNum++);
		cell2.setCellValue(aveCriSR/recordNum);
		
		cell3 = row.createCell(cellNum++);
		cell3.setCellValue(aveWcriSR/recordNum); 
		
		cell4 = row.createCell(cellNum++);
		cell4.setCellValue(aveRandomSR/recordNum);

		Cell cell33 = row.createCell(cellNum++);
		cell33.setCellValue(aveFtcSR/recordNum);
		
		cell5 = row.createCell(cellNum++);
		cell5.setCellValue("");
		cell6 = row.createCell(cellNum++);
		cell6.setCellValue("");
		cell7 = row.createCell(cellNum++);
		cell7.setCellValue(""); 
		cell8 = row.createCell(cellNum++);
		cell8.setCellValue(""); 
		cell9 = row.createCell(cellNum++);
		cell9.setCellValue("");
		cell10 = row.createCell(cellNum++);
		cell10.setCellValue("");
		cell11 = row.createCell(cellNum++);
		cell11.setCellValue("");
		cell12 = row.createCell(cellNum++);
		cell12.setCellValue(aveCriTPDecrP/recordNum);
		cell13 = row.createCell(cellNum++);
		cell13.setCellValue(aveWcriTPDecrP/recordNum);
		cell14 = row.createCell(cellNum++);
		cell14.setCellValue(aveRandomTPDecrP/recordNum);
		Cell cell34 = row.createCell(cellNum++);
		cell34.setCellValue(aveFtcTPDecrP/recordNum);
		
		addSummary(tpSummary, aveCriTPDecrP/recordNum, aveWcriTPDecrP/recordNum, aveRandomTPDecrP/recordNum, aveFtcTPDecrP/recordNum);

		
 		lastRow = reliabilitySheet.getLastRowNum();
  		row = reliabilitySheet.createRow(lastRow + 1);
		cellNum = 0;
		cell0 = row.createCell(cellNum++);
		cell0.setCellValue("");
		cell1 = row.createCell(cellNum++);
		cell1.setCellValue("");
		
		cell99 = row.createCell(cellNum++);
		cell99.setCellValue("");
		
		cell2 = row.createCell(cellNum++);
		cell2.setCellValue(aveCriSR/recordNum);
		
		cell3 = row.createCell(cellNum++);
		cell3.setCellValue(aveWcriSR/recordNum); 
		
		cell4 = row.createCell(cellNum++);
		cell4.setCellValue(aveRandomSR/recordNum);

		cell4 = row.createCell(cellNum++);
		cell4.setCellValue("");
		
		cell5 = row.createCell(cellNum++);
		cell5.setCellValue("");
		cell6 = row.createCell(cellNum++);
		cell6.setCellValue("");
		cell7 = row.createCell(cellNum++);
		cell7.setCellValue(""); 
		cell8 = row.createCell(cellNum++);
		cell8.setCellValue(""); 
		cell9 = row.createCell(cellNum++);
		cell9.setCellValue("");
		cell10 = row.createCell(cellNum++);
		cell10.setCellValue("");
		cell11 = row.createCell(cellNum++);
		cell11.setCellValue("");
		cell12 = row.createCell(cellNum++);
		cell12.setCellValue(aveCriREDecrP/recordNum);
		cell13 = row.createCell(cellNum++);
		cell13.setCellValue(aveWcriREDecrP/recordNum);
		cell14 = row.createCell(cellNum++);
		cell14.setCellValue(aveRandomREDecrP/recordNum);
		cell14 = row.createCell(cellNum++);
		cell14.setCellValue("");
		
		addSummary(reSummary, aveCriREDecrP/recordNum, aveWcriREDecrP/recordNum, aveRandomREDecrP/recordNum, aveFtcREDecrP/recordNum);

		lastRow = successRateSheet.getLastRowNum();
		row = successRateSheet.createRow(lastRow + 1);
		cellNum = 0;
		cell0 = row.createCell(cellNum++);
		cell0.setCellValue("");
		cell1 = row.createCell(cellNum++);
		cell1.setCellValue(aveCriSR/recordNum);
		cell2 = row.createCell(cellNum++);
		cell2.setCellValue(aveWcriSR/recordNum);
	    cell3 = row.createCell(cellNum++);
		cell3.setCellValue(aveRandomSR/recordNum); 
	    cell4 = row.createCell(cellNum++);
		cell4.setCellValue(aveFtcSR/recordNum); 
		
		addSummary(srSummary, aveCriSR/recordNum, aveWcriSR/recordNum, aveRandomSR/recordNum, aveFtcSR/recordNum);
	
  		lastRow = affectTenantSheet.getLastRowNum();
  		row = affectTenantSheet.createRow(lastRow + 1);
  		cell0 = row.createCell(cellNum++);
  		cell0.setCellValue(this.aveCriAfTenantP/recordNum);

  		cell1 = row.createCell(cellNum++);
  		cell1.setCellValue(this.aveWcriAfTenantP/recordNum);

  		cell2 = row.createCell(cellNum++);
  		cell2.setCellValue(this.aveRandomAfTenantP/recordNum);
  		
  		cell3 = row.createCell(cellNum++);
  		cell3.setCellValue(this.aveFtcAfTenantP/recordNum);
  		
  		addSummary(teSummary, aveCriAfTenantP/recordNum, aveWcriAfTenantP/recordNum, aveRandomAfTenantP/recordNum, aveFtcAfTenantP/recordNum);

  		lastRow = sgoSheet.getLastRowNum();
  		row = sgoSheet.createRow(lastRow + 1);
  		cell0 = row.createCell(cellNum++);
  		cell0.setCellValue(this.aveSgo/recordNum);
  		
  		addSummary(sgoSummary, aveSgo/recordNum, 0, 0, 0);

  		lastRow = ssoSheet.getLastRowNum();
  		row = ssoSheet.createRow(lastRow + 1);
  		cell0 = row.createCell(cellNum++);
  		cell0.setCellValue(this.aveCriSso/recordNum);

  		cell1 = row.createCell(cellNum++);
  		cell1.setCellValue(this.aveWcriSso/recordNum);

  		cell2 = row.createCell(cellNum++);
  		cell2.setCellValue(this.aveRandomSso/recordNum);
  		
  		cell3 = row.createCell(cellNum++);
  		cell3.setCellValue(this.aveFtcSso/recordNum);
  		
  		addSummary(ssoSummary, aveCriSso/recordNum, aveWcriSso/recordNum, aveRandomSso/recordNum, aveFtcSso/recordNum);
     }
    
     public void addSummary(XSSFSheet sheet, double cri, double wcri, double random, double ftc) {
  		int lastRow = sheet.getLastRowNum();
  		Row row = sheet.createRow(lastRow + 1);
  		int cellNum = 0;
  		Cell cell0 = row.createCell(cellNum++);
  		cell0.setCellValue(""+this.budget);

  		Cell cell1 = row.createCell(cellNum++);
  		cell1.setCellValue(cri);

  		Cell cell2 = row.createCell(cellNum++);
  		cell2.setCellValue(wcri);

  		Cell cell3 = row.createCell(cellNum++);
  		cell3.setCellValue(random); 
  		
  		Cell cell4 = row.createCell(cellNum++);
  		cell4.setCellValue(ftc);   
  		
     }
     
	 public void outputResult() {
		addAveRecord();
        try
        {
            //Write the workbook in file system
            FileOutputStream out = new FileOutputStream(new File(fileName + ".xlsx"));
            this.workbook.write(out);
            out.close();
            LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, fileName + " written successfully on disk.");
            //System.exit(0);
            //outputSummary();
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }		
	}
   
	 public void outputSummary() {
        try
        {
            //Write the workbook in file system
            FileOutputStream out = new FileOutputStream(new File("Summary.xlsx"));
            this.summaryBook.write(out);
            out.close();
            LogInfo.logInfo(LogInfo.LOGLEVEL_DEBUG, fileName + " written successfully on disk.");
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }		
	}
}
