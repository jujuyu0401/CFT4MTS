package edge;

public class Edge {
	public int source;
	public int target;
	public double weight;
	
	public int getSource() {
		return source;
	}

	public void setSource(int startId) {
		this.source = startId;
	}

	public int getTarget() {
		return target;
	}

	public void setTarget(int endId) {
		this.target = endId;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public Edge(int start, int end, double weight) {
		this.source = start;
		this.target = end;
		this.weight = weight;
	}

	@Override
	public String toString() {
		return "Edge [source=" + source + ", target=" + target + ", weight="
				+ weight + "]";
	}
}
