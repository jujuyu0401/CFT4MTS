package testcases;

import java.util.ArrayList;

import services.Permutations;
import services.Service;


public class PermutationTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Service s1 = new Service();
		s1.servicdId = 1;
		Service s2 = new Service();
		s2.servicdId = 2;
		Service s3 = new Service();
		s3.servicdId = 3;
		Service s4 = new Service();
		s4.servicdId = 4;
		
		Service[] array = new Service[1];
		array[0] = s1;
		array[1] = s2;
		array[2] = s3;
		array[3] = s4;
		
		Permutations p = new Permutations();
		
		ArrayList<Service[]> result = p.permutate(array);
		System.out.println("Permutation number: " + result.size());
		for (int i=0; i<result.size(); i++) {
			for(int j=0; j<result.get(i).length; j++) {
				System.out.print(result.get(i)[j].servicdId + ", ");
			}
			System.out.println();
		}
		
	}

}
